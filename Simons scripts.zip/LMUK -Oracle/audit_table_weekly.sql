/************************************************************************************
   NAME:          audit_table_weekly.sql
   PURPOSE:       Reports Weekly Audit table statistics - how many changes and who did them. 
                  As per CR 10655 - Jaal 1.1 extended logging reporting
   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        10/09/2004  S.Osborne        Script created.
   3.0        15/10/2004  S.Osborne        Added virtual day and a table temp of AUDIT_TRACKER_PERMUTATIONS with a double outer joins so there all rows are always there, even if there are none for that day.

   USAGE :
   report_master.sh   audit_table_weekly csv 'S.Osborne@loyalty.co.uk'  "Audit table Weekly Report" SYSDATE  ATTACHED &
   
   OR
   
 if [ `date '+%a'` = Mon ] 
   then   
   
   ###############  3 ) audit_table_weekly - Monday - Takes 2 minutes ###############   
   
   	REPORT=audit_table_weekly
   	FILE_TYPE=csv
   	DISTR_LIST='S.Osborne@loyalty.co.uk a.schajer@loyalty.co.uk'
   	SUBJECT="Audit table Weekly Report"
   
   	report_master.sh   ${REPORT} ${FILE_TYPE}   "${DISTR_LIST}"  "${SUBJECT}"   SYSDATE   ATTACHED 
 fi
   
*************************************************************************************/

DEFINE process_date=&1
DEFINE Output_file1=&2
DEFINE REPORT_DAYS=7  

SET COLSEP ,
SET HEADS ,
SET TERMOUT OFF
SET LINESIZE 1000

COL "Online"  format 999999999
COL "Other"   format 999999999
COL "Total"	 format 999999999
COL "BATCH"	 format 999999999

SPOOL &&Output_File1

SET HEADING OFF FEEDBACK OFF

PROMPT Audit table Weekly Report
PROMPT =====================================================

SELECT 'Run Date : '||TO_CHAR(SYSDATE,'DD-MON-RR HH24:MI') ||CHR(10)||
       'Run Period : '||to_char(TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))-&&REPORT_DAYS,'DD-MON-RR HH24:MI') ||' to '
                      ||to_char(TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))- (1/86400),'DD-MON-RR HH24:MI') 
FROM DUAL;

prompt ------------------------------------------------------------------------------;
prompt  Report 1) DNP Changes  : ;
prompt ------------------------;

SET HEADING ON

PROMPT , ,DNP_1_Nectar , , ,DNP_2_Sponsor  , , , DNP_3_Email_Comm , , , DNP_4_Mkt_Res , , , DNP_5_SMS   ;

SELECT vday AS Day
      ,t2.CHANGE
      ,sum(CASE WHEN COLUMN_NAME = 'DNP_1_Nectar' THEN CASE WHEN cuser = 'ONLINE'        THEN 1 ELSE 0 END ELSE 0 END ) AS "Online"
      ,sum(CASE WHEN COLUMN_NAME = 'DNP_1_Nectar' THEN CASE WHEN substr(cuser,1,2) ='B_' THEN 1 ELSE 0 END ELSE 0 END ) AS  "Batch"
      ,sum(CASE WHEN COLUMN_NAME = 'DNP_1_Nectar' THEN CASE WHEN cuser != 'ONLINE' 
      THEN CASE WHEN substr(cuser,1,2) != 'B_' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS  "Other"
-----------------------------------------------
      ,sum(CASE WHEN COLUMN_NAME = 'DNP_2_Sponsor' THEN CASE WHEN cuser = 'ONLINE'        THEN 1 ELSE 0 END ELSE 0 END ) AS "Online"
      ,sum(CASE WHEN COLUMN_NAME = 'DNP_2_Sponsor' THEN CASE WHEN substr(cuser,1,2) ='B_' THEN 1 ELSE 0 END ELSE 0 END ) AS  "Batch"
      ,sum(CASE WHEN COLUMN_NAME = 'DNP_2_Sponsor' THEN CASE WHEN cuser != 'ONLINE' 
      THEN CASE WHEN substr(cuser,1,2) != 'B_' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS  "Other"
-----------------------------------------------
      ,sum(CASE WHEN COLUMN_NAME = 'DNP_3_Email_Comm' THEN CASE WHEN cuser = 'ONLINE'        THEN 1 ELSE 0 END ELSE 0 END ) AS "Online"
      ,sum(CASE WHEN COLUMN_NAME = 'DNP_3_Email_Comm' THEN CASE WHEN substr(cuser,1,2) ='B_' THEN 1 ELSE 0 END ELSE 0 END ) AS  "Batch"
      ,sum(CASE WHEN COLUMN_NAME = 'DNP_3_Email_Comm' THEN CASE WHEN cuser != 'ONLINE' 
      THEN CASE WHEN substr(cuser,1,2) != 'B_' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS  "Other"
-----------------------------------------------
      ,sum(CASE WHEN COLUMN_NAME = 'DNP_4_Mkt_Res' THEN CASE WHEN cuser = 'ONLINE'        THEN 1 ELSE 0 END ELSE 0 END ) AS "Online"
      ,sum(CASE WHEN COLUMN_NAME = 'DNP_4_Mkt_Res' THEN CASE WHEN substr(cuser,1,2) ='B_' THEN 1 ELSE 0 END ELSE 0 END ) AS  "Batch"
      ,sum(CASE WHEN COLUMN_NAME = 'DNP_4_Mkt_Res' THEN CASE WHEN cuser != 'ONLINE' 
      THEN CASE WHEN substr(cuser,1,2) != 'B_' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS  "Other"
-----------------------------------------------
      ,sum(CASE WHEN COLUMN_NAME = 'DNP_5_SMS' THEN CASE WHEN cuser = 'ONLINE'        THEN 1 ELSE 0 END ELSE 0 END ) AS "Online"
      ,sum(CASE WHEN COLUMN_NAME = 'DNP_5_SMS' THEN CASE WHEN substr(cuser,1,2) ='B_' THEN 1 ELSE 0 END ELSE 0 END ) AS  "Batch"
      ,sum(CASE WHEN COLUMN_NAME = 'DNP_5_SMS' THEN CASE WHEN cuser != 'ONLINE' 
      THEN CASE WHEN substr(cuser,1,2) != 'B_' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS  "Other"
-----------------------------------------------
FROM  (  SELECT DECODE ( AUT_V_COLUMN_NAME
	,'COL_C_RECEIVE_MKT_COMM'         , 'DNP_1_Nectar'    
	,'COL_C_RECEIVE_STMNT_BY_EMAIL'	  , 'DNP_2_Sponsor'
	,'COL_C_RECEIVE_MKTCOM_BY_EMAIL'  , 'DNP_3_Email_Comm'
	,'COL_C_RECEIVE_MKT_RES_COMM'	  , 'DNP_4_Mkt_Res'
	,'COL_C_PLACE_HOLDER_14'          , 'DNP_5_SMS'  ) AS  COLUMN_NAME 
	,AUT_V_COLUMN_OLD_VALUE || ' -> ' || AUT_V_COLUMN_NEW_VALUE AS OLD_NEW
	,TRUNC(AUT_D_CREATION_DATE_TIME) AS day 
	,UPPER(RTRIM(AUT_C_CREATION_USER)) AS  cuser
	FROM  AUDIT_TRAIL
	WHERE AUT_D_CREATION_DATE_TIME BETWEEN TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - &&REPORT_DAYS
						   AND TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - (1/86400) 
	AND   AUT_V_COLUMN_NAME IN  ('COL_C_PLACE_HOLDER_14','COL_C_RECEIVE_STMNT_BY_EMAIL','COL_C_RECEIVE_MKT_RES_COMM','COL_C_RECEIVE_MKT_COMM','COL_C_RECEIVE_MKTCOM_BY_EMAIL' )
	)  t1
,	(SELECT * 
	 FROM  (SELECT TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - &&REPORT_DAYS + (ROWNUM -1) AS vday
			FROM   TABLE(CAST(virtual_table(&&REPORT_DAYS) AS virtual_table_type )) )  
			,	ops$reports.AUDIT_TRACKER_PERMUTATIONS ) t2		 
WHERE  t1.OLD_NEW(+) = t2.CHANGE
AND    t1.day(+) = t2.vday
GROUP BY  vday
,         SEQ
,         t2.CHANGE
ORDER BY  vday, SEQ
;


prompt ------------------------------------------------------------------------------;
prompt  Report 2) Misc Column Changes : ;
prompt ------------------------;

PROMPT ,PREFIX , , ,F_NAME  , , , L_NAME , , , LOCN , , , DOB , , , MMM , , , W_PWD , , , FORGOT_Q  , , , FORGOT_A   ;

SELECT day
      ,sum(CASE WHEN COLUMN_NAME = 'PREFIX' THEN CASE WHEN cuser = 'ONLINE'        THEN 1 ELSE 0 END ELSE 0 END ) AS "Online"
      ,sum(CASE WHEN COLUMN_NAME = 'PREFIX' THEN CASE WHEN substr(cuser,1,2) ='B_' THEN 1 ELSE 0 END ELSE 0 END ) AS  "Batch"
      ,sum(CASE WHEN COLUMN_NAME = 'PREFIX' THEN CASE WHEN cuser != 'ONLINE' 
      THEN CASE WHEN substr(cuser,1,2) != 'B_' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS  "Other"
-----------------------------------------------
      ,sum(CASE WHEN COLUMN_NAME = 'F_NAME' THEN CASE WHEN cuser = 'ONLINE'        THEN 1 ELSE 0 END ELSE 0 END ) AS "Online"
      ,sum(CASE WHEN COLUMN_NAME = 'F_NAME' THEN CASE WHEN substr(cuser,1,2) ='B_' THEN 1 ELSE 0 END ELSE 0 END ) AS  "Batch"
      ,sum(CASE WHEN COLUMN_NAME = 'F_NAME' THEN CASE WHEN cuser != 'ONLINE' 
      THEN CASE WHEN substr(cuser,1,2) != 'B_' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS  "Other"
-----------------------------------------------
      ,sum(CASE WHEN COLUMN_NAME = 'L_NAME' THEN CASE WHEN cuser = 'ONLINE'        THEN 1 ELSE 0 END ELSE 0 END ) AS "Online"
      ,sum(CASE WHEN COLUMN_NAME = 'L_NAME' THEN CASE WHEN substr(cuser,1,2) ='B_' THEN 1 ELSE 0 END ELSE 0 END ) AS  "Batch"
      ,sum(CASE WHEN COLUMN_NAME = 'L_NAME' THEN CASE WHEN cuser != 'ONLINE' 
      THEN CASE WHEN substr(cuser,1,2) != 'B_' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS  "Other"
-----------------------------------------------
      ,sum(CASE WHEN COLUMN_NAME = 'LOCN' THEN CASE WHEN cuser = 'ONLINE'        THEN 1 ELSE 0 END ELSE 0 END ) AS "Online"
      ,sum(CASE WHEN COLUMN_NAME = 'LOCN' THEN CASE WHEN substr(cuser,1,2) ='B_' THEN 1 ELSE 0 END ELSE 0 END ) AS  "Batch"
      ,sum(CASE WHEN COLUMN_NAME = 'LOCN' THEN CASE WHEN cuser != 'ONLINE' 
      THEN CASE WHEN substr(cuser,1,2) != 'B_' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS  "Other"
-----------------------------------------------
      ,sum(CASE WHEN COLUMN_NAME = 'DOB' THEN CASE WHEN cuser = 'ONLINE'        THEN 1 ELSE 0 END ELSE 0 END ) AS "Online"
      ,sum(CASE WHEN COLUMN_NAME = 'DOB' THEN CASE WHEN substr(cuser,1,2) ='B_' THEN 1 ELSE 0 END ELSE 0 END ) AS  "Batch"
      ,sum(CASE WHEN COLUMN_NAME = 'DOB' THEN CASE WHEN cuser != 'ONLINE' 
      THEN CASE WHEN substr(cuser,1,2) != 'B_' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS  "Other"
-----------------------------------------------
      ,sum(CASE WHEN COLUMN_NAME = 'MMM' THEN CASE WHEN cuser = 'ONLINE'        THEN 1 ELSE 0 END ELSE 0 END ) AS "Online"
      ,sum(CASE WHEN COLUMN_NAME = 'MMM' THEN CASE WHEN substr(cuser,1,2) ='B_' THEN 1 ELSE 0 END ELSE 0 END ) AS  "Batch"
      ,sum(CASE WHEN COLUMN_NAME = 'MMM' THEN CASE WHEN cuser != 'ONLINE' 
      THEN CASE WHEN substr(cuser,1,2) != 'B_' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS  "Other"
-----------------------------------------------
      ,sum(CASE WHEN COLUMN_NAME = 'W_PWD' THEN CASE WHEN cuser = 'ONLINE'        THEN 1 ELSE 0 END ELSE 0 END ) AS "Online"
      ,sum(CASE WHEN COLUMN_NAME = 'W_PWD' THEN CASE WHEN substr(cuser,1,2) ='B_' THEN 1 ELSE 0 END ELSE 0 END ) AS  "Batch"
      ,sum(CASE WHEN COLUMN_NAME = 'W_PWD' THEN CASE WHEN cuser != 'ONLINE' 
      THEN CASE WHEN substr(cuser,1,2) != 'B_' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS  "Other"
-----------------------------------------------
      ,sum(CASE WHEN COLUMN_NAME = 'FORGOT_Q' THEN CASE WHEN cuser = 'ONLINE'        THEN 1 ELSE 0 END ELSE 0 END ) AS "Online"
      ,sum(CASE WHEN COLUMN_NAME = 'FORGOT_Q' THEN CASE WHEN substr(cuser,1,2) ='B_' THEN 1 ELSE 0 END ELSE 0 END ) AS  "Batch"
      ,sum(CASE WHEN COLUMN_NAME = 'FORGOT_Q' THEN CASE WHEN cuser != 'ONLINE' 
      THEN CASE WHEN substr(cuser,1,2) != 'B_' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS  "Other"
-----------------------------------------------
      ,sum(CASE WHEN COLUMN_NAME = 'FORGOT_A' THEN CASE WHEN cuser = 'ONLINE'        THEN 1 ELSE 0 END ELSE 0 END ) AS "Online"
      ,sum(CASE WHEN COLUMN_NAME = 'FORGOT_A' THEN CASE WHEN substr(cuser,1,2) ='B_' THEN 1 ELSE 0 END ELSE 0 END ) AS  "Batch"
      ,sum(CASE WHEN COLUMN_NAME = 'FORGOT_A' THEN CASE WHEN cuser != 'ONLINE' 
      THEN CASE WHEN substr(cuser,1,2) != 'B_' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS  "Other"
-----------------------------------------------
FROM  ( SELECT DECODE ( AUT_V_COLUMN_NAME
	,'COL_C_COLLECTOR_PREFIX'     ,   'PREFIX'
	,'COL_V_COLLECTOR_FIRST_NAME' ,   'F_NAME'
	,'COL_V_COLLECTOR_LAST_NAME'  ,   'L_NAME'
	,'ASH_V_LOCATION_ID'	      ,   'LOCN'
	,'CUS_D_DATE_OF_BIRTH'	      ,   'DOB'
	,'COL_V_SQ_SECRET_WORD'	      ,   'MMM'
	,'COL_V_WEB_PASSWORD'	      ,   'W_PWD'
	,'COL_V_PWD_FORGOT_QUESTION'  ,   'FORGOT_Q'
	,'COL_V_PWD_FORGOT_ANSWER'    ,   'FORGOT_A' ) AS  COLUMN_NAME 
	,TRUNC(AUT_D_CREATION_DATE_TIME) AS day 
	,UPPER(RTRIM(AUT_C_CREATION_USER)) AS  cuser
	FROM  AUDIT_TRAIL
	WHERE AUT_D_CREATION_DATE_TIME BETWEEN TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - &&REPORT_DAYS
						   AND TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - (1/86400)
	AND   AUT_V_COLUMN_NAME IN  ('COL_C_COLLECTOR_PREFIX','COL_V_COLLECTOR_FIRST_NAME','COL_V_COLLECTOR_LAST_NAME','ASH_V_LOCATION_ID','CUS_D_DATE_OF_BIRTH','COL_V_SQ_SECRET_WORD','COL_V_WEB_PASSWORD','COL_V_PWD_FORGOT_QUESTION','COL_V_PWD_FORGOT_ANSWER' ))
GROUP BY  day
;


SET HEADING OFF FEEDBACK OFF
prompt ;
prompt ------------------------------------------------------------------------------;
prompt  Report 3) Collector address changes   : ;
prompt ------------------------;

SET HEADING ON

SELECT trunc(add_d_modification_date_time) AS "Date"  
      ,SUM(DECODE(UPPER(RTRIM(add_c_modification_user)),'BATCH',1,0))  AS "BATCH"
      ,SUM(DECODE(UPPER(RTRIM(add_c_modification_user)),'ONLINE',1,0))  AS "Online"
      ,SUM(DECODE(UPPER(RTRIM(add_c_modification_user)),'IVR',1,0))     AS "IVR"
      ,SUM(DECODE(substr(add_c_modification_user,-4,1),'_',1,0))        AS "TCR"
      ,SUM(CASE WHEN UPPER(RTRIM(add_c_modification_user)) NOT IN ('ONLINE','IVR')  
         THEN CASE WHEN (substr(add_c_modification_user,-4,1)) != '_'  
         THEN CASE WHEN UPPER(RTRIM(add_c_modification_user))  != 'BATCH'  
         THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END )    AS "Other"
      ,COUNT(add_c_modification_user)                                   AS "Total"
FROM   address
WHERE  add_d_modification_date_time  BETWEEN TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - &&REPORT_DAYS                                           AND TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))- (1/86400)  
GROUP BY trunc(add_d_modification_date_time)                                       
;

SPOOL OFF
quit

/* 
--CREATE TABLE AUDIT_TRACKER_PERMUTATIONS (SEQ number(2),CHANGE varchar(8) ) ;
TRUNCATE TABLE AUDIT_TRACKER_PERMUTATIONS  ;
INSERT INTO AUDIT_TRACKER_PERMUTATIONS VALUES  (1,'  -> Y') ;
INSERT INTO AUDIT_TRACKER_PERMUTATIONS VALUES  (2,'N -> Y');
INSERT INTO AUDIT_TRACKER_PERMUTATIONS VALUES  (3,'Q -> Y');
INSERT INTO AUDIT_TRACKER_PERMUTATIONS VALUES  (4,'X -> Y');
INSERT INTO AUDIT_TRACKER_PERMUTATIONS VALUES  (5,'  -> N');
INSERT INTO AUDIT_TRACKER_PERMUTATIONS VALUES  (6,'Y -> N');
INSERT INTO AUDIT_TRACKER_PERMUTATIONS VALUES  (7,'Q -> N');
INSERT INTO AUDIT_TRACKER_PERMUTATIONS VALUES  (8,'X -> N');
INSERT INTO AUDIT_TRACKER_PERMUTATIONS VALUES  (9,'Y -> Q'); 
INSERT INTO AUDIT_TRACKER_PERMUTATIONS VALUES  (10,'Y -> X');
commit;
*/

