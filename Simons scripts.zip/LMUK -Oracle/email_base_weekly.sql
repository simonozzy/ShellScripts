/************************************************************************************
   NAME:          email_base_weekly.sql
   PURPOSE:       Reports on the size of the emailable base
   USAGE:         report_master.sh  email_base_weekly  csv "S.Osborne@loyalty.co.uk" 'Email Base Report' 'SYSDATE'  ATTACHED &
	          
   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        11/02/2004  S.Roope          Script created.
   2.0        01/04/2004  S Osborne         separated .sql file out  with parameters  
   3.0        07/07/2004  S Osborne         CR 10065 : "Extend the emailable base weekly report to include secondaries, expand the reason code to include all reason codes and also to append count the accounts that are 'web registered'"
   
   USAGE:
     
     if [ `date '+%a'` = Mon ] 
     then   
     	REPORT=email_base_weekly
     	FILE_TYPE=csv
     	DISTR_LIST='S.Osborne@loyalty.co.uk a.schajer@loyalty.co.uk' 
     	SUBJECT='Emailable Base Report'
    
     	report_master.sh   ${REPORT} ${FILE_TYPE}   "${DISTR_LIST}"  "${SUBJECT}"  'SYSDATE'  ATTACHED
     
  fi
  
*************************************************************************************/

SET COLSEP ","
SET HEADS ","
SET UND OFF
SET TRIMSPOOL ON
SET TERMOUT   OFF
SET LINESIZE  1000
SET PAGESIZE  9999

DEFINE process_date=&1
DEFINE Output_file1=&2

col Web_Status format a12
col dnp_Nectar format a12
col dnp_sponsor format a12
col Emailable  format a12
col House      format a12

SPOOL &&Output_File1

SET HEADING OFF FEEDBACK OFF

PROMPT Emailable / SMS-able Base Report Weekly Report
PROMPT =====================================================

SELECT 'Run Date : '||TO_CHAR(SYSDATE,'DD-MON-RR HH24:MI') ||CHR(10)||
       'Run Period : '||to_char(TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))-7,'DD-MON-RR HH24:MI') ||' to '
                      ||to_char(TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))- (1/86400),'DD-MON-RR HH24:MI') 
FROM DUAL;
SET HEADING ON

  
prompt ------------------------------------------------------------------------------;
prompt  Report 1) Emailable Base : ;
prompt ------------------------;

SELECT  hi AS  House
--       ,CASE WHEN stat = 'AC' THEN 'Active' WHEN stat = 'DE' THEN 'Deactive' ELSE 'Permanently Deactive' END Status
--       ,CASE WHEN reas = 'RY' THEN 'Registered Can Redeem' WHEN reas = 'RY' THEN 'Missing Data' ELSE reas END Reason
       ,stat AS  Status
       ,reas AS  Reason
       ,Web_Status
       ,CASE WHEN email_add = 'N' THEN 'NoEmail' ELSE (CASE WHEN email_add_issue = 'EM' THEN
            'InvalidEmail' ELSE 'ValidEmail' END) END EmailAddress
       ,dnp AS  dnp_Nectar
       ,dnp_email Emailable
--       ,dnp_sponsor 
       ,COUNT(*) Count
FROM (
  SELECT col_c_household_ind                  hi
        ,col_c_collector_status               stat
        ,col_c_collector_reason_code          reas
        ,col_c_web_status                     AS Web_Status
        ,CASE WHEN col_v_email IS NULL THEN 'N' ELSE 'Y' END email_add
        ,(SELECT DISTINCT(cli_c_reason_code)
          FROM   collector_issues
          WHERE  cli_c_reason_code           = 'EM'
          AND    cli_c_resolved_flag         = 'N'
          AND    cli_n_collector_account_num = col_n_collector_account_num
          AND    cli_n_collector_issue_num   = col_n_collector_issue_num) email_add_issue
        ,col_c_receive_mkt_comm               dnp
        ,col_c_receive_mktcom_by_email        dnp_email
--        ,col_c_receive_stmnt_by_email         dnp_sponsor
  FROM   collector
  WHERE  col_d_creation_date_time < TRUNC(SYSDATE) 
  --AND    col_c_household_ind <> 'S'
  --AND    col_c_collector_reason_code IN ('RY','MD')
)
GROUP BY  hi 
         ,stat 
         ,reas 
         ,Web_Status 
         ,CASE WHEN email_add = 'N' THEN 'NoEmail' ELSE (CASE WHEN email_add_issue = 'EM' THEN
                  'InvalidEmail' ELSE 'ValidEmail' END) END
         ,dnp
         ,dnp_email
;

prompt ------------------------------------------------------------------------------;
prompt  Report 2) SMS-able Base : ;
prompt ------------------------;

col House      format a12 
col Status     format a12 
col Reason     format a12 
col Web_Status format a12
col Mobile     format a12
col dnp_Nectar format a12
col dnp_SMS    format a12

SELECT   col_c_household_ind                  AS  House
        ,col_c_collector_status               AS  Status
        ,col_c_collector_reason_code          AS  Reason
        ,col_c_web_status                     AS  Web_Status
        ,CASE WHEN Length(RTrim(COL_V_MOBILE_PHONE)) <= 10 THEN 'N' ELSE 'Y' END AS Mobile
        ,col_c_receive_mkt_comm               dnp_Nectar
        ,col_c_place_holder_14                dnp_SMS
        ,COUNT(*) Count
FROM   collector
GROUP BY  col_c_household_ind               
        ,col_c_collector_status             
        ,col_c_collector_reason_code        
        ,col_c_web_status                   
        ,CASE WHEN Length(RTrim(COL_V_MOBILE_PHONE)) <= 10 THEN 'N' ELSE 'Y' END 
        ,col_c_receive_mkt_comm               
        ,col_c_place_holder_14                
;       

spool off
quit

