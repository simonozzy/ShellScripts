/************************************************************************************
   NAME:          Web_Activity_weekly.sql
   PURPOSE:       Reports Weekly online registration/enrolment statistics 
   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        07/11/2003  S.Roope          Script created.
   2.0        07/05/2004  S.Osborne        Added col_c_enrolment_mode = 'A' for Take One collectors as per CR 9610
   3.0        19/05/2004  S.Osborne        Included all enrollemtn modes and broke the report into two sections : 
                                           - Collectors and Accounts
   4.0        01/07/2004  S.Osborne        Changed col_d_creation_date_time to col_d_enrolment_date at verbal request from  Alex S
   5.0        01/07/2004  S.Osborne        CR 10327 : Added number of additional card/account requests 
   6.0        05/08/2004  S.OSborne        Changed name to Web_Activity_weekly

   USAGE :
   report_master.sh   Web_Activity_weekly csv 'S.Osborne@loyalty.co.uk'  "Web Activity Weekly Report"   SYSDATE   ATTACHED &
   
   OR
   
 if [ `date '+%a'` = Mon ] 
   then   
   
   ###############  3 ) Web_Activity_weekly - Monday - Takes 5 minutes ###############   
   
   	REPORT=Web_Activity_weekly
   	FILE_TYPE=csv
   	DISTR_LIST='S.Osborne@loyalty.co.uk a.schajer@loyalty.co.uk P.Atkinson'
   	SUBJECT="Web Activity Weekly Report"
   
   	report_master.sh   ${REPORT} ${FILE_TYPE}   "${DISTR_LIST}"  "${SUBJECT}"   SYSDATE   ATTACHED 
 fi
   
*************************************************************************************/

DEFINE process_date=&1
DEFINE Output_file1=&2
DEFINE REPORT_DAYS=7  

SET COLSEP ,
SET HEADS ,
SET TERMOUT OFF
SET LINESIZE 1000

ALTER SESSION SET NLS_DATE_FORMAT =  'DD-MM-YYYY';

COL "Date"  FORMAT a11     
COL P FORMAT 999999  
COL K FORMAT 999999  
COL W FORMAT 999999  
COL G FORMAT 999999  
COL C FORMAT 999999  
COL B FORMAT 999999  
COL A FORMAT 999999  
COL "Total" FORMAT 999999 

COL "TX_Online"   format 999999999
COL "TX_IVR"	  format 999999999
COL "TX_RTR"	  format 999999999
COL "TX_Batch"	  format 999999999
COL "TX_TCR"	  format 999999999
COL "TX_Other"	  format 999999999

COL "PTS_Online" format 999999999
COL "PTS_IVR"	 format 999999999
COL "PTS_RTR"	 format 999999999
COL "PTS_Batch"	 format 999999999
COL "PTS_TCR"	 format 999999999
COL "PTS_Other"	 format 999999999

SPOOL &&Output_File1

SET HEADING OFF FEEDBACK OFF

PROMPT Web Activity Weekly Report
PROMPT =====================================================

SELECT 'Run Date : '||TO_CHAR(SYSDATE,'DD-MON-RR HH24:MI') ||CHR(10)||
       'Run Period : '||to_char(TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))- &&REPORT_DAYS,'DD-MON-RR HH24:MI') ||' to '
                      ||to_char(TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))- (1/86400),'DD-MON-RR HH24:MI') 
FROM DUAL;
SET HEADING ON

prompt ------------------------------------------------------------------------------;
prompt  Report 1) Registrations  : ;
prompt ------------------------;

SET HEADING ON

SELECT ',' || 'Collectors' || ',,,,,,,,' || 'Collectors / DNP=N' || ',,,,,,,,'  || 'Accounts' || ',,,,,,,,' || 'Accounts / DNP=N'   FROM dual ;

SELECT TRUNC(col_d_enrolment_date) AS "Date" 
--Collectors ----------------------------------------------------------------------
      ,SUM(CASE WHEN E_MODE ='P' THEN 1 ELSE 0 END ) AS P
      ,SUM(CASE WHEN E_MODE ='K' THEN 1 ELSE 0 END ) AS K
      ,SUM(CASE WHEN E_MODE ='W' THEN 1 ELSE 0 END ) AS W
      ,SUM(CASE WHEN E_MODE ='G' THEN 1 ELSE 0 END ) AS G
      ,SUM(CASE WHEN E_MODE ='C' THEN 1 ELSE 0 END ) AS C
      ,SUM(CASE WHEN E_MODE ='B' THEN 1 ELSE 0 END ) AS B
      ,SUM(CASE WHEN E_MODE ='A' THEN 1 ELSE 0 END ) AS A
      ,COUNT(*)  AS "TOTAL"
      ,SUM(CASE WHEN MKT_COMM = 'N' THEN CASE WHEN E_MODE ='P' THEN 1 ELSE 0 END ELSE 0 END ) AS PN
      ,SUM(CASE WHEN MKT_COMM = 'N' THEN CASE WHEN E_MODE ='K' THEN 1 ELSE 0 END ELSE 0 END ) AS KN
      ,SUM(CASE WHEN MKT_COMM = 'N' THEN CASE WHEN E_MODE ='W' THEN 1 ELSE 0 END ELSE 0 END ) AS WN
      ,SUM(CASE WHEN MKT_COMM = 'N' THEN CASE WHEN E_MODE ='G' THEN 1 ELSE 0 END ELSE 0 END ) AS GN
      ,SUM(CASE WHEN MKT_COMM = 'N' THEN CASE WHEN E_MODE ='C' THEN 1 ELSE 0 END ELSE 0 END ) AS CN
      ,SUM(CASE WHEN MKT_COMM = 'N' THEN CASE WHEN E_MODE ='B' THEN 1 ELSE 0 END ELSE 0 END ) AS BN
      ,SUM(CASE WHEN MKT_COMM = 'N' THEN CASE WHEN E_MODE ='A' THEN 1 ELSE 0 END ELSE 0 END ) AS AN
      ,SUM(CASE WHEN MKT_COMM = 'N' THEN 1 ELSE 0 END ) AS "TOTAL"
--Accounts ----------------------------------------------------------------------
      ,SUM(CASE WHEN HI != 'S' THEN CASE WHEN E_MODE ='P' THEN 1 ELSE 0 END ELSE 0 END ) AS P
      ,SUM(CASE WHEN HI != 'S' THEN CASE WHEN E_MODE ='K' THEN 1 ELSE 0 END ELSE 0 END ) AS K
      ,SUM(CASE WHEN HI != 'S' THEN CASE WHEN E_MODE ='W' THEN 1 ELSE 0 END ELSE 0 END ) AS W
      ,SUM(CASE WHEN HI != 'S' THEN CASE WHEN E_MODE ='G' THEN 1 ELSE 0 END ELSE 0 END ) AS G
      ,SUM(CASE WHEN HI != 'S' THEN CASE WHEN E_MODE ='C' THEN 1 ELSE 0 END ELSE 0 END ) AS C
      ,SUM(CASE WHEN HI != 'S' THEN CASE WHEN E_MODE ='B' THEN 1 ELSE 0 END ELSE 0 END ) AS B
      ,SUM(CASE WHEN HI != 'S' THEN CASE WHEN E_MODE ='A' THEN 1 ELSE 0 END ELSE 0 END ) AS A
      ,SUM(CASE WHEN HI != 'S' THEN 1 ELSE 0 END)  AS "TOTAL"
      ,SUM(CASE WHEN HI != 'S' THEN CASE WHEN MKT_COMM = 'N' THEN CASE WHEN E_MODE ='P' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS PN
      ,SUM(CASE WHEN HI != 'S' THEN CASE WHEN MKT_COMM = 'N' THEN CASE WHEN E_MODE ='K' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS KN
      ,SUM(CASE WHEN HI != 'S' THEN CASE WHEN MKT_COMM = 'N' THEN CASE WHEN E_MODE ='W' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS WN
      ,SUM(CASE WHEN HI != 'S' THEN CASE WHEN MKT_COMM = 'N' THEN CASE WHEN E_MODE ='G' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS GN
      ,SUM(CASE WHEN HI != 'S' THEN CASE WHEN MKT_COMM = 'N' THEN CASE WHEN E_MODE ='C' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS CN
      ,SUM(CASE WHEN HI != 'S' THEN CASE WHEN MKT_COMM = 'N' THEN CASE WHEN E_MODE ='B' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS BN
      ,SUM(CASE WHEN HI != 'S' THEN CASE WHEN MKT_COMM = 'N' THEN CASE WHEN E_MODE ='A' THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END ) AS AN
      ,SUM(CASE WHEN HI != 'S' THEN CASE WHEN MKT_COMM = 'N' THEN 1 ELSE 0 END ELSE 0 END) AS "TOTAL"
FROM   (SELECT col_d_enrolment_date , col_c_enrolment_mode AS E_MODE, col_c_household_ind AS HI, COL_C_RECEIVE_MKT_COMM  AS MKT_COMM
        FROM collector
	WHERE  col_d_enrolment_date BETWEEN  TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - &&REPORT_DAYS
                              AND   TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))- (1/86400)
        )
GROUP BY TRUNC(col_d_enrolment_date)
;

prompt ;
prompt ------------------------------------------------------------------------------;
prompt Reg Mode Codes  ;
prompt ------------------------;
prompt P  Pack (Batch)   ;
prompt K  Web (Partial) ;
prompt W  Web (Full);
prompt G  Points Accrual  ;
prompt C  HelpLine (CSR) ;
prompt B  Take One Online ;
prompt A  Take One Batch ;
prompt ------------------------------------------------------------------------------;


SET HEADING OFF 
prompt ;
prompt ------------------------------------------------------------------------------;
prompt  Report 2) Voucher Orders : ;
prompt ------------------------;
SET HEADING ON

ALTER SESSION SET NLS_DATE_FORMAT =  'DD-MM-YYYY';
BREAK ON voucher_type SKIP 1

SELECT DECODE  (rdm_v_reward_id
        ,'ROM0005871', 'Debs Voucher'
	,'ROM0000120', 'Adams Voucher'
	,'ROM0000131', 'anon. voucher' ) AS voucher_type
      ,day
      ,SUM(DECODE(UPPER(RTRIM(ruser)),'ONLINE',1,0))              AS "TX_Online"
      ,SUM(DECODE(UPPER(RTRIM(ruser)),'IVR',1,0))                 AS "TX_IVR"
      ,SUM(DECODE(UPPER(RTRIM(ruser)),'ARGOS',1,'TUSSAUDS',1,'LUNNPOLY',1,0))  AS "TX_RTR"
      ,SUM(DECODE(UPPER(substr(ruser,1,2)),'B_',1,0))             AS "TX_Batch"
      ,SUM(DECODE(substr(ruser,-4,1),'_',1,0))                    AS "TX_TCR"
      ,SUM(CASE WHEN UPPER(RTRIM(ruser)) NOT IN ('ONLINE','IVR','ARGOS','TUSSAUDS','LUNNPOLY')  
	 THEN CASE WHEN (substr(ruser,-4,1)) != '_'  
	 THEN CASE WHEN (substr(ruser,1,2))  != 'B_'  
	 THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END )                AS "TX_Other"
------ -----------------------------------------------
      ,SUM(DECODE(UPPER(RTRIM(ruser)),'ONLINE',rpoints,0))        AS "PTS_Online"
      ,SUM(DECODE(UPPER(RTRIM(ruser)),'IVR',rpoints,0))           AS "PTS_IVR"
      ,SUM(DECODE(UPPER(RTRIM(ruser)),'ARGOS',rpoints,'TUSSAUDS',rpoints,'LUNNPOLY',rpoints,0))  AS "PTS_RTR"
      ,SUM(DECODE(UPPER(substr(ruser,1,2)),'B_',rpoints,0))       AS "PTS_Batch"
      ,SUM(DECODE(substr(ruser,-4,1),'_',rpoints,0))              AS "PTS_TCR"
      ,SUM(CASE WHEN UPPER(RTRIM(ruser)) NOT IN ('ONLINE','IVR')  
	   THEN CASE WHEN (substr(ruser,-4,1)) != '_'  
	   THEN CASE WHEN (substr(ruser,1,2))  != 'B_'  
	   THEN rpoints ELSE 0 END ELSE 0 END ELSE 0 END )        AS "PTS_Other"
FROM  (SELECT TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - &&REPORT_DAYS + (ROWNUM -1) AS day
       FROM   TABLE(CAST(virtual_table(&&REPORT_DAYS) AS virtual_table_type )) )
     ,(SELECT rdm_v_reward_id
             ,rdm_c_creation_user                    ruser
	     ,rdm_n_points                           rpoints
	     ,TRUNC(rdm_d_creation_date_time) rday
       FROM   redemption_details
       WHERE  rdm_d_creation_date_time BETWEEN TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - &&REPORT_DAYS
					   AND TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - (1/86400)
       AND  rdm_v_reward_id IN ('ROM0000120','ROM0005871','ROM0000131') 
		)
WHERE day = rday(+) 
GROUP BY DECODE  (rdm_v_reward_id
        ,'ROM0005871', 'Debs Voucher'
	,'ROM0000120', 'Adams Voucher'
	,'ROM0000131', 'anon. voucher' ) 
      ,day
;      

SPOOL OFF
quit
