/************************************************************************************
   NAME:          batch_processing_daily.sql
   PURPOSE:       Reports on last nights batch process 
   USAGE :        report_master.sh  batch_processing_daily '' 'S.Osborne@loyalty.co.uk' 'Testing batch_processing_daily' 'SYSDATE' UNATTACHED

   REVISIONS:      
      Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        01/12/2003   S.Osborne       Script created.
*************************************************************************************/

SET feedback off
SET lines 132
SET und ON
COL Minutes format  999,999
COL Finished format a10
COL Seq_no format a6
COL  Records  format   9,999,999

DEFINE process_date=&1
DEFINE Output_file1=&2
 
SPOOL &&Output_File1

prompt ;
prompt ------------------------------------------------------------------------------;
prompt  Batch processing - last nights  files: ;
prompt ------------------------;

SELECT  FIL_C_FILE_TYPE as  Batch
,            FIL_V_ORIGINATOR_ID   as Originator
,              lpad(to_char(FIL_N_FILE_SEQ_NUM),6,'0')  as Seq_no
 --,            FIL_V_FILE_NAME    as File_name
--,            FIL_C_STATUS       as Status
--,            TO_CHAR(FIL_D_FILE_ARRIVAL_DATETIME,  'DD-MM-YYYY  HH24:MI' )  as  Arrived
,             TO_CHAR(FIL_D_CREATION_DATE_TIME,  'DD-MM-YYYY  HH24:MI' )  as Start_time
,             ' - ' || TO_CHAR(FIL_D_PROCESS_DATE, 'HH24:MI' )  as Finished
,            24*60*(FIL_D_PROCESS_DATE- FIL_D_CREATION_DATE_TIME)  as Minutes
--,         TRUNC(FIL_D_PROCESS_DATE- FIL_D_CREATION_DATE_TIME),   'HH24:MI' )  "Process_time"
,             FIL_N_RECORDS_PROCESSED   as Records
--,            FIL_N_RECORDS_REJECTED    as  Rejected
FROM    lmholtp.FILE_TRACK
WHERE  FIL_D_CREATION_DATE_TIME >  (sysdate -1)
AND FIL_C_STATUS   =  'PS'
ORDER BY FIL_D_CREATION_DATE_TIME
;

prompt ;
prompt ------------------------------------------------------------------------------;
prompt  Failed (or high failure rate) batch files - in the last 24h : ;
prompt ------------------------;

SELECT  FIL_C_FILE_TYPE as  Batch
,            FIL_V_ORIGINATOR_ID   as Originator
,              lpad(to_char(FIL_N_FILE_SEQ_NUM),6,'0')  as Seq_no
,             TO_CHAR(FIL_D_CREATION_DATE_TIME,  'DD-MM-YYYY  HH24:MI' )  as Start_time
,             FIL_N_RECORDS_PROCESSED   as Records
--,            FIL_N_RECORDS_REJECTED    as  Rejected
FROM    lmholtp.FILE_TRACK
WHERE  FIL_D_CREATION_DATE_TIME >  (sysdate -1)
AND ( FIL_C_STATUS   =  'FL' OR  (FIL_N_RECORDS_REJECTED/ (FIL_N_RECORDS_PROCESSED+0.01) > 0.5    ))
ORDER BY FIL_D_CREATION_DATE_TIME
;

prompt ;
prompt ------------------------------------------------------------------------------;
prompt  PNTSACCL performance over the last 7 days : ;
prompt ------------------------;

COL Process_day format a12
COL Records    format 999,999,999
COL Records/Sec  format 999,999,999
COL "AM/PM" format a6
BREAK ON Originator  SKIP 1

SELECT  FIL_V_ORIGINATOR_ID   as Originator
,              TO_CHAR(FIL_D_CREATION_DATE_TIME,  'YYYY-MM-DD' )  as Process_day
,              INITCAP(TO_CHAR(FIL_D_CREATION_DATE_TIME,  'DY' ))  AS Weekday
,              (CASE WHEN TO_NUMBER(TO_CHAR(FIL_D_CREATION_DATE_TIME,  'HH24' ))  >= 12 THEN 'PM'  ELSE 'AM' END)  AS "AM/PM"  
,              sum(FIL_N_RECORDS_PROCESSED)  as Records
--,              sum(FIL_N_RECORDS_REJECTED)     as  Rejected
,              sum(FIL_N_RECORDS_PROCESSED)/avg(24*60*60*(FIL_D_PROCESS_DATE-FIL_D_CREATION_DATE_TIME))  as "Records/Sec"
FROM    FILE_TRACK
WHERE FIL_C_FILE_TYPE  =  'PNTSACCL'
AND substr(FIL_V_ORIGINATOR_ID,1,2) in ( 'DE' , 'JS', 'BA', 'BP')
AND   FIL_D_CREATION_DATE_TIME >  (sysdate -7)
GROUP BY   FIL_V_ORIGINATOR_ID   
,              TO_CHAR(FIL_D_CREATION_DATE_TIME,  'YYYY-MM-DD' ) 
,              INITCAP(TO_CHAR(FIL_D_CREATION_DATE_TIME,  'DY' ))  
,              (CASE WHEN TO_NUMBER(TO_CHAR(FIL_D_CREATION_DATE_TIME,  'HH24' ))  >= 12 THEN 'PM'  ELSE 'AM' END)  
;

spool off 
quit

