/************************************************************************************
   NAME:          Jaal_MIS_weekly.sql
   PURPOSE:       Looks at a online vs other channels for various collector actions (redemption, lost card, enrolment ) that were enabled by Jaal. Now also looks at  the WEB_TRACK and WEB_TRACK_EMAIL tables which track web user actions.
   
   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        07/05/2004  S.Osborne        Created as per CR 10046
   2.0        09/09/2004  S.Osborne        Added the Report 2) WEB_TRACK + WEB_TRACK_EMAIL section 
   3.0        28/09/2004  S.Osborne        Added Report 3) Vodafone links and Report 4) Additional card requests onto "the end " of Jaal MIS as per 11568. What Alex actually meant in here was alongside the originial Report 1), so that horrible 3 way join is now a 5 way join.. Arrrggggh.
   
   USAGE:         report_master.sh  Jaal_MIS_weekly  csv "S.Osborne@loyalty.co.uk" "Jaal MIS Weekly Report" 'SYSDATE'  ATTACHED &
	          
   if [ `date '+%a'` = Mon ] 
   then   
   
   ###############  3 ) Jaal_MIS_weekly  - Monday - Takes 5 minutes ###############   
   
   	#DISTR_LIST='S.Osborne@loyalty.co.uk'
   	REPORT=Jaal_MIS_weekly
   	FILE_TYPE=csv
   	DISTR_LIST='S.Osborne@loyalty.co.uk j.ward@loyalty.co.uk'
   	SUBJECT="Jaal MIS Weekly Report"
   
   	report_master.sh   ${REPORT} ${FILE_TYPE}   "${DISTR_LIST}"  "${SUBJECT}"   SYSDATE   ATTACHED  
   fi
   
*************************************************************************************/

DEFINE process_date=&1
DEFINE Output_file1=&2
--Weekly Report 
DEFINE REPORT_DAYS=7  

SET COLSEP ,
SET HEADS ,
SET TERMOUT OFF
SET LINESIZE 1000
SET UND OFF

ALTER SESSION SET NLS_DATE_FORMAT =  'DD-MM-YYYY';

SPOOL &&Output_File1

COL "TX_Online"   format 999999999
COL "TX_IVR"	  format 999999999
COL "TX_RTR"	  format 999999999
COL "TX_Batch"	  format 999999999
COL "TX_TCR"	  format 999999999
COL "TX_Other"	  format 999999999

COL "PTS_Online" format 999999999
COL "PTS_IVR"	 format 999999999
COL "PTS_RTR"	 format 999999999
COL "PTS_Batch"	 format 999999999
COL "PTS_TCR"	 format 999999999
COL "PTS_Other"	 format 999999999

COL "Online"  format 999999999
COL "IVR" 	 format 999999999
COL "Other"   format 999999999
COL "Total"	 format 999999999
COL "BATCH"	 format 999999999
COL "TCR"	 format 999999999
		

COL P FORMAT 999999  
COL K FORMAT 999999  
COL W FORMAT 999999  
COL G FORMAT 999999  
COL C FORMAT 999999  
COL B FORMAT 999999  
COL A FORMAT 999999  
COL "Total" FORMAT 999999 

COL lc_on                      HEADING "Lost Online" 
COL lc_ot                      HEADING "Lost Other" 
COL st_on                      HEADING "Stolen Online" 
COL st_ot                      HEADING "Stolen Other" 
COL re_on                      HEADING "Replaced Online" 
COL re_ot                      HEADING "Replaced Other" 

SET HEADING OFF FEEDBACK OFF

PROMPT Jaal MIS Weekly Report
PROMPT =====================================================

SELECT 'Run Date : '||TO_CHAR(SYSDATE,'DD-MON-RR HH24:MI') ||CHR(10)||
       'Run Period : '||to_char(TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))-&&REPORT_DAYS,'DD-MON-RR HH24:MI') ||' to '      ||to_char(TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))- (1/86400),'DD-MON-RR HH24:MI') 
FROM DUAL;

SET HEADING OFF 


prompt ;
prompt ------------------------------------------------------------------------------;
prompt  Report 1) Redemptions + Enrolments + Lost Cards + Vodafone links + Additional card requests : ;
prompt ------------------------;
prompt  ;

--Put an extra main heading row in the spreadsheet:

SELECT ',' || 'Redemptions - Absolute No.' || ',,,,,,' || 'Redemptions - Points' || ',,,,,,' || 
'Account Registrations' || ',,,,,,,' || 'Lost+ Stolen + Damaged' || ',,,,,,,' || 'Vodafone links' || ',,,,,,,' || 'Additional card requests' FROM dual ;

SET HEADING ON

--I have used a sort of 5 way join here to combine 5 separate reports along side each other into one spreadsheets as per the CR, having one row per day. 

SELECT t1.*,t2.P,t2.K,t2.W,t2.G,t2.C,t2.B,t2.A, t3.lc_on,t3.lc_ot,t3.st_on,t3.st_ot,t3.re_on,t3.re_ot,t4.*,t5.*
FROM (SELECT day
	      ,SUM(DECODE(UPPER(RTRIM(ruser)),'ONLINE',1,0))              AS "TX_Online"
	      ,SUM(DECODE(UPPER(RTRIM(ruser)),'IVR',1,0))                 AS "TX_IVR"
	      ,SUM(DECODE(UPPER(RTRIM(ruser)),'ARGOS',1,'TUSSAUDS',1,'LUNNPOLY',1,0))  AS "TX_RTR"
	      ,SUM(DECODE(UPPER(substr(ruser,1,2)),'B_',1,0))             AS "TX_Batch"
	      ,SUM(DECODE(substr(ruser,-4,1),'_',1,0))                    AS "TX_TCR"
	      ,SUM(CASE WHEN UPPER(RTRIM(ruser)) NOT IN ('ONLINE','IVR','ARGOS','TUSSAUDS','LUNNPOLY')  
		 THEN CASE WHEN (substr(ruser,-4,1)) != '_'  
		 THEN CASE WHEN (substr(ruser,1,2))  != 'B_'  
		 THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END )                AS "TX_Other"
	------ -----------------------------------------------
	      ,SUM(DECODE(UPPER(RTRIM(ruser)),'ONLINE',rpoints,0))        AS "PTS_Online"
	      ,SUM(DECODE(UPPER(RTRIM(ruser)),'IVR',rpoints,0))           AS "PTS_IVR"
	      ,SUM(DECODE(UPPER(RTRIM(ruser)),'ARGOS',rpoints,'TUSSAUDS',rpoints,'LUNNPOLY',rpoints,0))  AS "PTS_RTR"
	      ,SUM(DECODE(UPPER(substr(ruser,1,2)),'B_',rpoints,0))       AS "PTS_Batch"
	      ,SUM(DECODE(substr(ruser,-4,1),'_',rpoints,0))              AS "PTS_TCR"
	      ,SUM(CASE WHEN UPPER(RTRIM(ruser)) NOT IN ('ONLINE','IVR')  
		   THEN CASE WHEN (substr(ruser,-4,1)) != '_'  
		   THEN CASE WHEN (substr(ruser,1,2))  != 'B_'  
		   THEN rpoints ELSE 0 END ELSE 0 END ELSE 0 END )        AS "PTS_Other"
	FROM  (SELECT TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - &&REPORT_DAYS + (ROWNUM -1) AS day
	       FROM   TABLE(CAST(virtual_table(&&REPORT_DAYS) AS virtual_table_type )) )
	     ,(SELECT rdm_c_creation_user                    ruser
		     ,rdm_n_points                           rpoints
		     ,TRUNC(rdm_d_creation_date_time) rday
	       FROM   redemption_details
	       WHERE  rdm_d_creation_date_time BETWEEN TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - &&REPORT_DAYS
						   AND TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - (1/86400)
		      AND  RDM_V_REWARD_ID NOT IN ('REFVCH0250','REVELECRDT','SSLELECRDT','SSLVCH0250') 
		      )
	WHERE day = rday(+) 
	GROUP BY day ) t1
,	(SELECT day
	      ,SUM(DECODE(col_c_enrolment_mode,'P',DECODE(col_c_household_ind,'S',0,1),0)) P
	      ,SUM(DECODE(col_c_enrolment_mode,'K',DECODE(col_c_household_ind,'S',0,1),0)) K
	      ,SUM(DECODE(col_c_enrolment_mode,'W',DECODE(col_c_household_ind,'S',0,1),0)) W
	      ,SUM(DECODE(col_c_enrolment_mode,'G',DECODE(col_c_household_ind,'S',0,1),0)) G
	      ,SUM(DECODE(col_c_enrolment_mode,'C',DECODE(col_c_household_ind,'S',0,1),0)) C
	      ,SUM(DECODE(col_c_enrolment_mode,'B',DECODE(col_c_household_ind,'S',0,1),0)) B
	      ,SUM(DECODE(col_c_enrolment_mode,'A',DECODE(col_c_household_ind,'S',0,1),0)) A
	FROM   (SELECT TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - &&REPORT_DAYS + (ROWNUM -1) AS day
		FROM   TABLE(CAST(virtual_table(&&REPORT_DAYS) AS virtual_table_type ))        )
	      ,(SELECT col_c_enrolment_mode                   
		      ,col_c_household_ind                    
		      ,TRUNC(col_d_enrolment_date)        AS cday
		FROM   collector
		WHERE  col_d_enrolment_date BETWEEN TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - &&REPORT_DAYS
						AND TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - (1/86400) 
		)
	WHERE  day = cday(+)
	GROUP BY day ) t2
,	( SELECT  day  
	       ,SUM(CASE WHEN ctype = 'LC' THEN CASE WHEN UPPER(cuser) = 'ONLINE' THEN 1 ELSE 0 END ELSE 0 END)  lc_on 
	       ,SUM(CASE WHEN ctype = 'LC' THEN CASE WHEN UPPER(cuser) <> 'ONLINE' THEN 1 ELSE 0 END ELSE 0 END) lc_ot 
	       ,SUM(CASE WHEN ctype = 'ST' THEN CASE WHEN UPPER(cuser) = 'ONLINE' THEN 1 ELSE 0 END ELSE 0 END)  st_on 
	       ,SUM(CASE WHEN ctype = 'ST' THEN CASE WHEN UPPER(cuser) <> 'ONLINE' THEN 1 ELSE 0 END ELSE 0 END) st_ot 
	       ,SUM(CASE WHEN ctype = 'RE' THEN CASE WHEN UPPER(cuser) = 'ONLINE' THEN 1 ELSE 0 END ELSE 0 END)  re_on 
	       ,SUM(CASE WHEN ctype = 'RE' THEN CASE WHEN UPPER(cuser) <> 'ONLINE' THEN 1 ELSE 0 END ELSE 0 END) re_ot 
	FROM   (SELECT TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - &&REPORT_DAYS + (ROWNUM -1) AS day
		FROM   TABLE(CAST(virtual_table(&&REPORT_DAYS) AS virtual_table_type ))
	       )
	      ,(SELECT clr_c_creation_user                    cuser
		      ,clr_c_request_type                     ctype
		      ,TRUNC(clr_d_creation_date_time) cday
		FROM   collector_requests
		WHERE  clr_c_request_type IN ('LC','ST','RE')
		AND    clr_d_creation_date_time BETWEEN TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - &&REPORT_DAYS
						AND TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - (1/86400) 
		)
	WHERE  day = cday(+)
	GROUP BY day ) t3
,       (SELECT day 
	      ,SUM(DECODE(UPPER(substr(cuser,1,2)),'B_',1,0)) AS  "BATCH"
	      ,SUM(DECODE(UPPER(RTRIM(cuser)),'ONLINE',1,0))  AS  "Online"
	      ,SUM(DECODE(UPPER(RTRIM(cuser)),'IVR',1,0))     AS  "IVR"
	      ,SUM(DECODE(substr(cuser,-4,1),'_',1,0))        AS  "TCR"
	      ,SUM(CASE WHEN UPPER(RTRIM(cuser)) NOT IN ('ONLINE','IVR')  
		 THEN CASE WHEN (substr(cuser,-4,1)) != '_'  
		 THEN CASE WHEN UPPER(substr(cuser,1,2)) != 'B_'
		 THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END )    AS  "Other"
	      ,COUNT(cuser)                                   AS "Total"
	FROM   (SELECT TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - &&REPORT_DAYS + (ROWNUM -1) AS day
		FROM   TABLE(CAST(virtual_table(&&REPORT_DAYS) AS virtual_table_type ))
	       )
	      ,(SELECT etp_c_creation_user                 cuser
		      ,TRUNC(etp_d_creation_date_time)     cday
		FROM   external_transfer_points
		WHERE  etp_v_sponsor_id  = 'VODAFONE' 
		AND    etp_d_creation_date_time   BETWEEN TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))- &&REPORT_DAYS
						  AND TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))- (1/86400) 
		)	
	WHERE  day = cday(+)
	GROUP BY day)  t4
,	(SELECT day  
	      ,SUM(DECODE(UPPER(substr(cuser,1,2)),'B_',1,0))  AS "BATCH"
	      ,SUM(DECODE(UPPER(RTRIM(cuser)),'ONLINE',1,0))  AS "Online"
	      ,SUM(DECODE(UPPER(RTRIM(cuser)),'IVR',1,0))     AS "IVR"
	      ,SUM(DECODE(substr(cuser,-4,1),'_',1,0))        AS "TCR"
	      ,SUM(CASE WHEN UPPER(RTRIM(cuser)) NOT IN ('ONLINE','IVR')  
	         THEN CASE WHEN (substr(cuser,-4,1)) != '_'  
	         THEN CASE WHEN UPPER(substr(cuser,1,2)) != 'B_'
	         THEN 1 ELSE 0 END ELSE 0 END ELSE 0 END )    AS "Other"
	      ,COUNT(cuser)                                   AS "Total"
	FROM   (SELECT TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - &&REPORT_DAYS + (ROWNUM -1) AS day
		FROM   TABLE(CAST(virtual_table(&&REPORT_DAYS) AS virtual_table_type ))
	       )
	      ,(SELECT clr_c_creation_user                cuser
		      ,TRUNC(clr_d_creation_date_time)     cday
		FROM   collector_requests
		WHERE  clr_c_request_type  in  ('AD','AO','IH','JH')
		AND    clr_d_creation_date_time   BETWEEN TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))- &&REPORT_DAYS
					   AND TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))- (1/86400) 
		)
	  	WHERE  day = cday(+)
	GROUP BY day)  t5
WHERE t1.day = t2.day
AND   t2.day = t3.day 
AND   t3.day = t4.day 
AND   t4.day = t5.day 
;

SET HEADING OFF 
prompt ;
prompt ------------------------------------------------------------------------------;
prompt  Report 2) WEB_TRACK and WEB_TRACK_EMAIL reports : ;
prompt ------------------------;
prompt  ;

--Put an extra main heading row in the spreadsheet:

SELECT ',WEB_TRACK,,,,,, Email Opt In Change,,,' || 'Good Email - Cookie Settings - Email Options,,,,,,,,,' ||    'Bad Email - Cookie Settings - Email Options,,,,,,,,,No Email - Cookie Settings - Email Options'
FROM dual ;

SET HEADING ON

SELECT t1.*,"Y","Z","X","GCY","GCZ","GCX","GNY","GNZ","GNX","GPY","GPZ","GPX","BCY","BCZ","BCX","BNY","BNZ","BNX","BPY", "BPZ","BPX","NCY","NCZ","NCX","NNY","NNZ","NNX","NPY","NPZ","NPX"
FROM 	(SELECT         trunc(wbt_d_creation_date_time)                  AS DAY
	,              COUNT(DISTINCT wbt_n_collector_account_num || wbt_n_collector_issue_num )  AS "Collectors"
	,              SUM(CASE WHEN wbt_v_web_event IN ('AC','UL','EO') THEN 1 ELSE 0 END  )           AS  "Logins"
	,              SUM(DECODE(wbt_v_web_event,'CA',1,0 ))           AS  "CA"
	,              SUM(DECODE(wbt_v_web_event,'AC',1,0 ))           AS  "AC"
	,              SUM(DECODE(wbt_v_web_event,'UL',1,0 ))           AS  "UL"
	,              SUM(DECODE(wbt_v_web_event,'EO',1,0 ))           AS  "EO"
	FROM  web_track
	WHERE wbt_d_creation_date_time BETWEEN TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - &&REPORT_DAYS
	AND TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - (1/86400) 
	GROUP BY trunc(wbt_d_creation_date_time)   
	) t1              
,	(SELECT        trunc(wte_d_creation_date_time)   AS       DAY
	,              SUM(DECODE(wte_v_email_optin ,'Y',1,0 ))         AS  "Y"
	,              SUM(DECODE(wte_v_email_optin ,'Z',1,0 ))         AS  "Z"
	,              SUM(DECODE(wte_v_email_optin ,'X',1,0 ))         AS  "X"
	,              SUM(DECODE(ACTION,'GCY',1,0)) AS  "GCY"
	,              SUM(DECODE(ACTION,'GCZ',1,0)) AS  "GCZ"
	,              SUM(DECODE(ACTION,'GCX',1,0)) AS  "GCX"
	,              SUM(DECODE(ACTION,'GNY',1,0)) AS  "GNY"
	,              SUM(DECODE(ACTION,'GNZ',1,0)) AS  "GNZ"
	,              SUM(DECODE(ACTION,'GNX',1,0)) AS  "GNX"
	,              SUM(DECODE(ACTION,'GPY',1,0)) AS  "GPY"
	,              SUM(DECODE(ACTION,'GPZ',1,0)) AS  "GPZ"
	,              SUM(DECODE(ACTION,'GPX',1,0)) AS  "GPX"
	,              SUM(DECODE(ACTION,'BCY',1,0)) AS  "BCY"
	,              SUM(DECODE(ACTION,'BCZ',1,0)) AS  "BCZ"
	,              SUM(DECODE(ACTION,'BCX',1,0)) AS  "BCX"
	,              SUM(DECODE(ACTION,'BNY',1,0)) AS  "BNY"
	,              SUM(DECODE(ACTION,'BNZ',1,0)) AS  "BNZ"
	,              SUM(DECODE(ACTION,'BNX',1,0)) AS  "BNX"
	,              SUM(DECODE(ACTION,'BPY',1,0)) AS  "BPY"
	,              SUM(DECODE(ACTION,'BPZ',1,0)) AS  "BPZ"
	,              SUM(DECODE(ACTION,'BPX',1,0)) AS  "BPX"
	,              SUM(DECODE(ACTION,'NCY',1,0)) AS  "NCY"
	,              SUM(DECODE(ACTION,'NCZ',1,0)) AS  "NCZ"
	,              SUM(DECODE(ACTION,'NCX',1,0)) AS  "NCX"
	,              SUM(DECODE(ACTION,'NNY',1,0)) AS  "NNY"
	,              SUM(DECODE(ACTION,'NNZ',1,0)) AS  "NNZ"
	,              SUM(DECODE(ACTION,'NNX',1,0)) AS  "NNX"
	,              SUM(DECODE(ACTION,'NPY',1,0)) AS  "NPY"
	,              SUM(DECODE(ACTION,'NPZ',1,0)) AS  "NPZ"
	,              SUM(DECODE(ACTION,'NPX',1,0)) AS  "NPX"
	FROM    (SELECT wte_d_creation_date_time
		,             DECODE(wte_v_email_optin,'W','X',' ','X',Null,'X',wte_v_email_optin) AS wte_v_email_optin
		,             wte_v_email_quality || wte_v_cookie_setting || DECODE(wte_v_email_optin,'W','X',' ','X',Null,'X',wte_v_email_optin) AS ACTION          
		FROM WEB_TRACK_EMAIL        
		WHERE  wte_d_creation_date_time BETWEEN TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - &&REPORT_DAYS
						AND TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - (1/86400)   )				
	GROUP BY trunc(wte_d_creation_date_time) 
	) t2
WHERE t1.DAY = t2.DAY
;


SPOOL OFF
quit


