/************************************************************************************
   NAME:          merchandise_rewards_daily.sql
   PURPOSE:       Three reports detailing ABS redemptions by status. Totals by
                  redemption for yesterday, cumulative totals from 29th Jan 2004
                  and a detailed breakdown of yesterdays redemptions.
   USAGE:          
   report_master.sh   merchandise_rewards_daily csv "s.osborne@loyalty.co.uk"  'Merchandise daily reward report'  SYSDATE  ATTACHED &
               
   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        17/12/2003  S.Osborne        Script created.
   1.1        08/03/2004  S.Roope          Changes required for Jaal data model
                                           and migrated data adjustments.
   1.2        16/03/2004  J.Campbell       Additional Jaal required changes        
   1.3        23/04/2004  S.Osborne        Added 3 New suppliers - 'PROCUREMNT','A1','EIC' and Supplier column to reports 
                                           and also Used new reward catalogueue view 
         	
   	REPORT=merchandise_rewards_daily 
   	FILE_TYPE=csv ; LM="loyalty.co.uk"
   	DISTR_LIST="S.Lobb@$LM J.Adessky@$LM J.Bolden@$LM R.Morris@$LM R.Ruttenberg@$LM N.Brodie@$LM Rewards.Operations@$LM G.Lemarquer@$LM F.Leslie@$LM"
   	SUBJECT='Merchandise daily reward report'
   
	report_master.sh   ${REPORT} ${FILE_TYPE}    "${DISTR_LIST}"  "${SUBJECT}"  SYSDATE  ATTACHED

	
*************************************************************************************/

DEFINE process_date=&1
DEFINE Output_file1=&2

SET COLSEP ,
SET HEADS ,
SET UND OFF
--SET VERIFY OFF
SET FEEDBACK OFF 

/* 
COL "Modification Date"  FORMAT a20       
COL "Supplier ID"   FORMAT a14       
COL "Card No" format a12 
COL "Reward offer ID"  format a18
COL "Reward Item ID"  format a18
COL "Reward Price ID" format a16
COL "Reward Offer Name"  format a30
COL "Reward Item Description"   format a70
COL  "Redemption Status" FORMAT a18 
COL "Redemptions"    FORMAT  999999999999
COL "Points"    FORMAT  999999999
COL "Cash"    FORMAT  999999999
*/

SPOOL &&Output_File1

PROMPT Daily ABS Redemption Report
PROMPT =====================================================

SET HEADING OFF FEEDBACK OFF TIMING OFF

SELECT 'Run Date : '||TO_CHAR(sysdate,'DD-MON-RR HH24:MI') ||CHR(10)||
       'Run Period : '||to_char(TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))-1,'DD-MON-RR HH24:MI') ||' to '
                      ||to_char(TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))- (1/86400),'DD-MON-RR HH24:MI') 
FROM DUAL;

prompt ;
prompt ------------------------------------------------------------------------------;
prompt  Report for yesterday : ;
SELECT  'For redemptions issued from ' || to_char(TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))-1,'DD-MON-RR HH24:MI:SS') || 
' up until ' ||  to_char(TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) - 1/86400,'DD-MON-RR HH24:MI:SS')||' '  FROM  dual;
prompt ------------------------;
SET HEADING ON 

SELECT  oms_v_supplier_id                             AS "Supplier ID"
       ,oms_v_reward_offer_id                         AS "Reward offer ID"
       ,rit_v_reward_item_id                          AS "Reward Item ID"
       ,rip_v_reward_price_id                         AS "Reward Price ID"
       ,oms_v_reward_offer_name                       AS "Reward Offer Name"
       ,rit_v_mktg_desc                               AS "Reward Item Description"
       ,cgd_v_code_value_desc                         AS "Redemption Status"
       ,SUM(rrm_n_reward_quantity)                    AS "Redemptions"
       ,SUM(rrm_n_reward_quantity*rrm_n_points)       AS "Points"
       ,SUM(rrm_n_reward_quantity*rrm_n_cash)         AS "Cash"
FROM    redemption_details
       ,redemption_reward_master
       ,vw_rewards_catalogue
       ,code_group_detail
WHERE   rrm_n_redemption_seq_num =  rdm_n_redemption_seq_num
AND     rip_v_reward_price_id    =  rrm_v_reward_price_id
AND     rdm_d_effective_datetime BETWEEN rip_d_from_change_date AND rip_d_change_date
AND     rdm_d_effective_datetime BETWEEN rit_d_item_from_change_date AND rit_d_item_change_date
AND     rdm_d_effective_datetime BETWEEN oms_d_offer_from_change_date AND oms_d_offer_change_date
AND     rdm_d_effective_datetime BETWEEN msr_d_reward_from_change_date AND msr_d_reward_change_date
AND     rdm_c_redemption_status  =  cgd_v_code_value
AND     cgd_v_code_group         =  'RDMNSTATUS'
AND   rdm_d_creation_date_time >= TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) -1
AND   rdm_d_creation_date_time <  TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))
AND   oms_v_supplier_id  in ('ABS','PROCUREMNT','A1','EIC')  
GROUP BY oms_v_supplier_id 
        ,oms_v_reward_offer_id
        ,rit_v_reward_item_id
        ,rip_v_reward_price_id
        ,oms_v_reward_offer_name
        ,rit_v_mktg_desc
        ,cgd_v_code_value_desc
ORDER BY 1,2,4
;

prompt ;
prompt ------------------------------------------------------------------------------;
prompt  Cumulative report since 01/04/2004 : ;
prompt ------------------------;

SELECT  oms_v_supplier_id                             AS "Supplier ID"
       ,oms_v_reward_offer_id                         AS "Reward offer ID"
       ,rit_v_reward_item_id                          AS "Reward Item ID"
       ,rip_v_reward_price_id                         AS "Reward Price ID"
       ,oms_v_reward_offer_name                       AS "Reward Offer Name"
       ,rit_v_mktg_desc                               AS "Reward Item Description"
       ,cgd_v_code_value_desc                         AS "Redemption Status"
       ,SUM(rrm_n_reward_quantity)                    AS "Redemptions"
       ,SUM(rrm_n_reward_quantity*rrm_n_points)       AS "Points"
       ,SUM(rrm_n_reward_quantity*rrm_n_cash)         AS "Cash"
FROM    redemption_details
       ,redemption_reward_master
       ,vw_rewards_catalogue
       ,code_group_detail
WHERE   rrm_n_redemption_seq_num =  rdm_n_redemption_seq_num
AND     rip_v_reward_price_id    =  rrm_v_reward_price_id
AND     rdm_d_effective_datetime BETWEEN rip_d_from_change_date AND rip_d_change_date
AND     rdm_d_effective_datetime BETWEEN rit_d_item_from_change_date AND rit_d_item_change_date
AND     rdm_d_effective_datetime BETWEEN oms_d_offer_from_change_date AND oms_d_offer_change_date
AND     rdm_d_effective_datetime BETWEEN msr_d_reward_from_change_date AND msr_d_reward_change_date
AND     rdm_c_redemption_status  =  cgd_v_code_value
AND     cgd_v_code_group         =  'RDMNSTATUS'
AND   rdm_d_creation_date_time >= TO_DATE('01-APR-2004 00.00.00','DD-MON-YYYY HH24.MI.SS')
AND   rdm_d_creation_date_time <  TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))
AND   oms_v_supplier_id  in ('ABS','PROCUREMNT','A1','EIC')  
GROUP BY oms_v_supplier_id 
        ,oms_v_reward_offer_id
        ,rit_v_reward_item_id
        ,rip_v_reward_price_id
        ,oms_v_reward_offer_name
        ,rit_v_mktg_desc
        ,cgd_v_code_value_desc
ORDER BY 1,2,4
;

prompt ;
prompt ------------------------------------------------------------------------------;
prompt  Detailed Report for yesterday : ;
prompt ------------------------;

SELECT   oms_v_supplier_id                             AS "Supplier ID"
       ,oms_v_reward_offer_id       AS "Reward offer ID"
       ,rit_v_reward_item_id        AS "Reward Item ID"
       ,rip_v_reward_price_id       AS "Reward Price ID"
       ,oms_v_reward_offer_name     AS "Reward Offer Name"
       ,rit_v_mktg_desc             AS "Reward Item Description"
       ,cgd_v_code_value_desc       AS "Redemption Status"
       ,SUM(rrm_n_reward_quantity)  AS "Redemptions"
       ,SUM(rrm_n_reward_quantity*rrm_n_points)           AS "Points"
       ,SUM(rrm_n_reward_quantity*rrm_n_cash)             AS "Cash"
       ,rdm_n_collector_account_num  || LPAD(TO_CHAR(rdm_n_collector_issue_num),2,'0') || rdm_n_check_digit AS "Card ID"
       ,rdm_c_creation_user          AS "Issued By"
       ,rdm_d_creation_date_time     AS  "Creation Time"
       ,rdm_c_modification_user      AS "Modified By"
       ,rdm_d_modification_date_time AS "Modified Time"
FROM    redemption_details
       ,redemption_reward_master
       ,vw_rewards_catalogue
       ,code_group_detail
WHERE   rrm_n_redemption_seq_num =  rdm_n_redemption_seq_num
AND     rip_v_reward_price_id    =  rrm_v_reward_price_id
AND     rdm_d_effective_datetime BETWEEN rip_d_from_change_date AND rip_d_change_date
AND     rdm_d_effective_datetime BETWEEN rit_d_item_from_change_date AND rit_d_item_change_date
AND     rdm_d_effective_datetime BETWEEN oms_d_offer_from_change_date AND oms_d_offer_change_date
AND     rdm_d_effective_datetime BETWEEN msr_d_reward_from_change_date AND msr_d_reward_change_date
AND     rdm_c_redemption_status  =  cgd_v_code_value
AND     cgd_v_code_group         =  'RDMNSTATUS'
AND   rdm_d_creation_date_time >= TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY')) -1
AND   rdm_d_creation_date_time <  TRUNC(TO_DATE('&&PROCESS_DATE','DD-MON-YYYY'))
AND   oms_v_supplier_id  in ('ABS','PROCUREMNT','A1','EIC')  
GROUP BY  oms_v_supplier_id                             
       ,oms_v_reward_offer_id
        ,rit_v_reward_item_id
        ,rip_v_reward_price_id
        ,oms_v_reward_offer_name
        ,rit_v_mktg_desc
        ,cgd_v_code_value_desc
        ,rdm_n_collector_account_num  || LPAD(TO_CHAR(rdm_n_collector_issue_num),2,'0') || rdm_n_check_digit
        ,rdm_c_creation_user
        ,rdm_d_creation_date_time
        ,rdm_c_modification_user
        ,rdm_d_modification_date_time
ORDER BY oms_v_supplier_id  
        ,oms_v_reward_offer_id
        ,cgd_v_code_value_desc
        ,rdm_c_creation_user
;

SPOOL OFF
quit

