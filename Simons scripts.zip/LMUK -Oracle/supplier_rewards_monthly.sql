/************************************************************************************
   NAME:          supplier_rewards_monthly.sql
   PURPOSE:       Reports supplier redemptions by collector. This replaces
      		the individual monthly reports for the sponsors in the 
   		      where clause.
   USAGE :
   report_master.sh supplier_rewards_monthly xls 'S.Osborne@loyalty.co.uk'  "Supplier Monthly Redemptions Report"   SYSDATE   ATTACHED &
   
   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        09/03/2004  J.Campbell       Script created.
   1.1        22/03/2004  J.Campbell       changes to where clasus logic
   1.3        26/04/2004  S.Osborne        Added 3 new suppliers - 'PROCUREMNT','A1','EIC' 
                                           and also used new reward catalogueue view 
   1.4        18/05/2004  S.Osborne        Added 4 new suppliers - 'FUTUREFORE', 'OCTOPUS','IMGWORLD','GREENFREE'  
   
   USAGE:
if [ `date '+%e'` = 2 ] 
	then   
	REPORT=supplier_rewards_monthly
	FILE_TYPE=xls
	DISTR_LIST='S.Osborne@loyalty.co.uk Rewards.Operations@loyalty.co.uk' 
	SUBJECT='Supplier Monthly Redemptions Report'

	report_master.sh   ${REPORT} ${FILE_TYPE}   "${DISTR_LIST}"  "${SUBJECT}"   SYSDATE   ATTACHED 
fi
  	
*************************************************************************************/

DEFINE process_date=&1
DEFINE Output_file1=&2

SET COLSEP '	'
SET HEADS '	'
SET UND OFF

SPOOL &&Output_File1

PROMPT Monthly Supplier Redemption Report
PROMPT =====================================================

SET HEADING OFF FEEDBACK OFF TIMING OFF

SELECT 'Monthly Supplier Redemption Report' ||CHR(10)||
       'Run Date : '||TO_CHAR(SYSDATE,'DD Mon YYYY HH24:MI') ||CHR(10)||
       'Run Period : '||TO_CHAR(TRUNC(TO_DATE('&&process_date','DD-MON-YYYY') - 28,'MONTH'),'DD Mon YYYY')||' to '
                      ||TO_CHAR(TRUNC(TO_DATE('&&process_date','DD-MON-YYYY'),'MONTH') - 1/86400,'DD Mon YYYY')
FROM DUAL;

SET HEADING ON FEEDBACK ON

/*  This is now all the login.sql file

COL "Supplier ID"   FORMAT a14       
COL "Collector Name" format a40
COL "Collector ID" format  a14
COL "Transaction Date"  format a18
COL "Supplier Booking Ref"  format a22
COL "Molehill Reference Number"  format a25
COL "Supplier Reward ID"   format a18
COL "Reward offer ID"  format a18
COL "Reward Item ID"  format a18
COL "Reward Price ID" format a16
COL "Reward Offer Name"  format a30
COL "Reward Item Description"   format a60
*/

SELECT oms_v_supplier_id  as "Supplier ID"
	,INITCAP(rtrim(COL_C_COLLECTOR_PREFIX))||' '||INITCAP(rtrim(COL_V_COLLECTOR_FIRST_NAME))||' '||INITCAP(rtrim(COL_V_COLLECTOR_LAST_NAME)) as "Collector Name"
	,COL_N_COLLECTOR_ACCOUNT_NUM  || LPAD(TO_CHAR(COL_N_COLLECTOR_ISSUE_NUM),2,'0')  || COL_N_CHECK_DIGIT  as  "Collector ID"
	,RDM_D_EFFECTIVE_DATETIME as "Transaction Date"
	,RDM_V_PARTNER_ATTRIBUTE_1 as "Supplier Booking Ref"
	,to_char(RDM_N_REDEMPTION_SEQ_NUM) as "Molehill Reference Number"
	,rrm_n_supplier_reward_id   AS "Supplier Reward ID"
	,oms_v_reward_offer_id       AS "Reward offer ID"
	,rit_v_reward_item_id        AS "Reward Item ID"
	,rip_v_reward_price_id       AS "Reward Price ID"
        ,oms_v_reward_offer_name     AS "Reward Offer Name"
	,SUBSTR(rit_v_mktg_desc,1,60) AS "Reward Item Description" 
      ,SUM(rrm_n_reward_quantity)  AS "Redemptions"     
      ,SUM(rrm_n_reward_quantity*rrm_n_points)           AS "Points"
      ,SUM(rrm_n_reward_quantity*rrm_n_cash)	            AS "Cash"
      ,cgd_v_code_value_desc       AS "Redemption Status"
FROM    redemption_details
       ,redemption_reward_master
       ,vw_rewards_catalogue
       ,code_group_detail
        ,collector
WHERE   rrm_n_redemption_seq_num =  rdm_n_redemption_seq_num
AND     rip_v_reward_price_id    =  rrm_v_reward_price_id
AND     rdm_d_effective_datetime BETWEEN rip_d_from_change_date AND rip_d_change_date
AND     rdm_d_effective_datetime BETWEEN rit_d_item_from_change_date AND rit_d_item_change_date
AND     rdm_d_effective_datetime BETWEEN oms_d_offer_from_change_date AND oms_d_offer_change_date
AND     rdm_d_effective_datetime BETWEEN msr_d_reward_from_change_date AND msr_d_reward_change_date
AND     rdm_c_redemption_status  =  cgd_v_code_value
AND     cgd_v_code_group         =  'RDMNSTATUS'
AND     oms_v_supplier_id in  ('BESTWEST','ELECTRONIC','ENGLANDRBY','TOPTABLE','THISTLE','MACDONALDH', 'PROCUREMNT','A1','EIC','FUTUREFORE','OCTOPUS','IMGWORLD','GREENFREE','NATMAGS','EUROTUNNEL','LUNNPOLY' ) 
AND     RDM_N_COLLECTOR_ACCOUNT_NUM = COL_N_COLLECTOR_ACCOUNT_NUM 
AND     RDM_N_COLLECTOR_ISSUE_NUM   = COL_N_COLLECTOR_ISSUE_NUM
AND     rdm_d_creation_date_time >= TRUNC(TO_DATE('&&process_date','DD-MON-YYYY') - 28, 'MONTH')
AND     rdm_d_creation_date_time <  TRUNC(TO_DATE('&&process_date','DD-MON-YYYY'),'MONTH')
GROUP BY  oms_v_supplier_id  
	,INITCAP(rtrim(COL_C_COLLECTOR_PREFIX))||' '||INITCAP(rtrim(COL_V_COLLECTOR_FIRST_NAME))||' '||INITCAP(rtrim(COL_V_COLLECTOR_LAST_NAME))
	,COL_N_COLLECTOR_ACCOUNT_NUM  || LPAD(TO_CHAR(COL_N_COLLECTOR_ISSUE_NUM),2,'0')  || COL_N_CHECK_DIGIT  
	,RDM_D_EFFECTIVE_DATETIME 
	,RDM_V_PARTNER_ATTRIBUTE_1
	,to_char(RDM_N_REDEMPTION_SEQ_NUM) 
	,rrm_n_supplier_reward_id   
	,rrm_n_supplier_reward_id
	,oms_v_reward_offer_id     
	,rit_v_reward_item_id      
	,rip_v_reward_price_id     
	,oms_v_reward_offer_name   
	,substr(rit_v_mktg_desc,1,60)		 
	,cgd_v_code_value_desc
ORDER BY oms_v_supplier_id  
	,rdm_d_effective_datetime
;

SPOOL OFF
quit
