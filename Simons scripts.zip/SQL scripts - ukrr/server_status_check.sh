#!/bin/ksh
#/*********************************************************************************************
#  Name     : ~ukrr_pm/scripts/server_status_check.sh
#  Purpose  : lists all table, view and procedure objects in ukrr_mart with ${1} in their name  
#  Usage    : alias ssc='server_status_check.sh'
#           : 00 09,17 * * 1-6 /home/ukrr_pm/scripts/server_status_check.sh # on UAT - 131
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  22/11/2010   S Osborne       Created
#
#*********************************************************************************************/

# Declare variables :

. ~ukrr_pm/.profile

SCRIPT_NAME=server_status_check
RUNDATE=`date '+%Y-%m-%d'` 

OUTPUT=~ukrr_pm/log/${SCRIPT_NAME}.out
OUTPUT2=~ukrr_pm/log/${SCRIPT_NAME}2.out

SUBJECT="UKRR Server status check"
# DISTR_LIST='UKRR-support@rbccmcom'
DISTR_LIST='Aditi.Aurora@rbccm.com, Rahamat.Khan@rbccm.com, Lorcan.Neary@rbccm.com' # , UK-DatabaseAdmins@rbccm.com, '
CC_LIST='Simon.Osborne@rbccm.com'

# LOG_FILE=~ukrr_pm/log/${SCRIPT_NAME}.out

UN=`cat ~/.un`
PW=`cat ~/.pw`

if [ ${SN} != LDNEUR ] ; then echo Server Name : ${SN} ; fi

echo "\nThere should be no connection errors below - if there are, the DBAs should be alerted\n" > ${OUTPUT2}

DB_NAME=ukrr_ctrl

# for SN in LDNEUR LDNEURUAT2_TN LNPEUR1_TN_DS LDNEURUAT3_DS LDNEURUAT4_DS LNUEUR2_DS LNUEUR1_DS # LDNEURBRP 
# for ENV in "UAT2_LR_T2|LNUEUR1_DS UAT3_LR_T2|LNUEUR1_DS"
# LDNEURDEV LDNEURDEV1_DS LDNEURBRP 
for ENV in '1) PROD|LDNEUR' '2) UAT1_LR|LNPEUR1_TN_DS' '3) UAT2_SLIM|LDNEURUAT2_TN' '4) UAT3_LR_T+2|LNUEUR1_DS' # '5) UAT5_SLIM_CONV|LNUEUR2_DS' '6) UAT4_EGB|LDNEURUAT3_DS' LDNEURBRP UAT4_LR_NOT_USED|LDNEURUAT4_DS
do

ENV_DESC=`echo "${ENV}" | cut -d"|" -f1`
SN=`echo "${ENV}" | cut -d"|" -f2`

# echo ${SN} ${ENV_DESC}

echo "\n############################### Connecting to Sybase server:     ${SN}      (${ENV_DESC}) " >> ${OUTPUT2} 

isql -U${UN} -S ${SN} -D${DB_NAME} -o ${OUTPUT} -w00000000000000000000000000002000 -P${PW} << EOF 

SET NOCOUNT ON 

-- exec sp_who 'ukrr'
SELECT "Verified connection to server: " + @@servername
go

quit
EOF

cat ${OUTPUT}  >> ${OUTPUT2} 
done


cat ${OUTPUT2} | egrep -v "(DB_name|---------)"

# If any server is down, then send an alert email :

ERROR_COUNT=`grep -c CT-LIBRARY ${OUTPUT2}`

if [ ${ERROR_COUNT} -ge 1 ] 
then
   echo ERROR_COUNT= ${ERROR_COUNT}
   # cat ${OUTPUT2} | egrep -v "(DB_name|---------)" | mutt -s "${SUBJECT}" -c "${CC_LIST}"  "${DISTR_LIST}"  
fi


