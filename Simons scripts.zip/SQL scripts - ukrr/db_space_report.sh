#!/bin/ksh
#/*********************************************************************************************
#  Name     : ~ukrr_pm/scripts/db_space_report.sh
#  Purpose  : runs Ed Barlow's (http://www.edbarlow.com/document/procs/) sp__dbspace for all the listed databases on a given server
#  Usage    :  db_space_report.sh 95
#           :  alias dbs='db_space_report.sh'
#           :  daily_scripts_scheduler.sh : ${SCRIPT_DIR_2}/db_space_report.sh 95 > ${OUTPUT}
#           :  01 09,16 * * 1-5 /home/ukrr_pm/scripts/db_space_report.sh 95
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  06/06/2005   S Osborne       Created
#  14/01/2009   S Osborne       Added filesystem space check
#  17/06/2009   S Osborne       Added TEMPDB_THRESHOLD = 10 and logic to handle this
#
#*********************************************************************************************/

. ~ukrr_pm/.profile

# Declare variables :

#Default ALERT_THRESHOLD is 90.0 % else if parameter(1) is supplied use that.
if [[ -z ${1} ]]
then
   ALERT_THRESHOLD=95
else
   ALERT_THRESHOLD=${1}
fi

TEMPDB_THRESHOLD=10      # 30 in TEST
MKTD_THRESHOLD=90        # 95 in TEST
MART_THRESHOLD=95        # 98 in TEST
FILESYSTEM_THRESHOLD=80  # 90 in TEST

#DISTR_LIST='Aditi.Aurora@rbccm.com, Dikshant.Jain@rbccm.com, Rahamat.Khan@rbccm.com, Sushree.Ray@rbccm.com, Anju.Kumari@rbccm.com, Anupama.Ramakrishnaiah@rbccm.com'
DISTR_LIST='UKRR-support@rbccm.com'

OUTPUT=~ukrr_pm/log/db_spaceused.out
OUTPUT1=~ukrr_pm/log/db_spaceused1.out
OUTPUT2=~ukrr_pm/log/db_spaceused2.out
OUTPUT3=~ukrr_pm/log/filesystem_spaceused.out
OUTPUT4=~ukrr_pm/log/db_spaceused4.out

DATA_DIRECTORY=/cm/ukrr_data/

> ${OUTPUT1}
> ${OUTPUT2}

echo '${DB}      ${ALERT_THRESHOLD_USE} ${USED}'  > ${OUTPUT4}
echo '----------------------------------------' >> ${OUTPUT4}

# SN=`cat ~/.sn`
SN=${DB_SERVER}
UN=`cat ~/.un`
PW=`cat ~/.pw`

if [ ${SN} != LDNEUR ] ; then echo Server Name : ${SN} ; fi

SQL_STRING="SELECT name FROM master..sysdatabases WHERE (suid != 1 OR name = 'tempdb')\ngo"

# for DB in ukrr_anvl ukrr_acbs ukrr_ccms ukrr_ctrl ukrr_ebs ukrr_gclt ukrr_geqd ukrr_igcp ukrr_inft ukrr_mart ukrr_mist ukrr_offs ukrr_rats ukrr_ribs ukrr_rims powermart powermart_7 tempdb
for DB in `echo ${SQL_STRING} | isql -U${UN} -S${SN} -D${DB} -b -P${PW} | grep -v affected`
do  # 1) Loop though DBs and check space used against threshold and alert where appropriate

isql -U${UN} -S ${SN} -D${DB} -o ${OUTPUT} -w00000000000000000000000000002000 -P${PW} << EOF

exec sp__dbspace
go

quit
EOF

DATA=`grep ${DB} ${OUTPUT}`
USED=`echo ${DATA} | awk '{print $4}' | cut -d'.' -f1`

cat ${OUTPUT}  >> ${OUTPUT1}

# As of 17/6/2009, changed tempdb alert down to 10% as this should only have tiny tables in it as this will affect production which requires up to 700MB of the 1000MB available.
if   [ ${DB} = 'tempdb'    ] ; then
   ALERT_THRESHOLD_USE=${TEMPDB_THRESHOLD}
elif [ ${DB} = 'ukrr_mktd' ] ; then
   ALERT_THRESHOLD_USE=${MKTD_THRESHOLD}
elif [ ${DB} = 'ukrr_mart' ] ; then
   ALERT_THRESHOLD_USE=${MART_THRESHOLD}
else
   ALERT_THRESHOLD_USE=${ALERT_THRESHOLD}
fi

echo ${DB} ${ALERT_THRESHOLD_USE}  ${USED} | awk '{printf "%14s %21s %7s \n", $1, $2, $3}'  >> ${OUTPUT4}

if [ ${USED} -ge ${ALERT_THRESHOLD_USE} ]
then
   echo ' Name         Data MB       Used MB        Percent Log MB    Log Used  Log Pct' >  ${OUTPUT2}
   echo ' ------------ ------------- -------------- ------- --------- --------- -------' >> ${OUTPUT2}
   echo "${DATA}"  >> ${OUTPUT2}

   SUBJECT="UKRR ${SN} dbspace alert for ${DB} - space used is ${USED} %"
   # cat ${OUTPUT2} | mailx -s "${SUBJECT}" "${DISTR_LIST}"
   cat ${OUTPUT2} | mutt -s "${SUBJECT}" "${DISTR_LIST}"
fi

done  # 1) Loop though DBs and check space used against threshold

echo " sp__dbspace report for server ${SN} in descending percent order :"
echo
echo ' Name         Data MB       Used MB        Percent Log MB    Log Used  Log Pct'
echo ' ------------ ------------- -------------- ------- --------- --------- -------'


cat ${OUTPUT1} | sort -k 4 -r |  egrep -v "(Name|---------|return)"


echo "\nsp_spaceused for ukrr_mart's biggest tables :\n"

~ukrr_pm/scripts/db_spaceused.sh ${SN} ukrr_mart | sort -k 4 -r | head -25

DB=ukrr_mart

isql -U${UN} -S ${SN} -D${DB} -o ${OUTPUT} -w00000000000000000000000000002000 -P${PW} << EOF

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT 'ukrr_mart fact table statistics and locking schemes : '
PRINT '-------------------------------------------------'
PRINT ''

SET NOCOUNT ON

SELECT "Table"=convert( char(30), o.name  )
,       "Lock Scheme" = convert( char(10) ,
    CASE
        WHEN sysstat2 & 8192 = 8192 then 'All Pages'
        WHEN sysstat2 & 16384 = 16384 then 'Data Pages'
        WHEN sysstat2 & 32768 = 32768 then 'Data Rows'
        else 'AllP old-s' -- Old Style locking so its all pages
    END )
,        "Pages" = str( pagecnt, 10,0)
,        "Rows" = str( rowcnt,10,0)
,        "RSize" = str( s.datarowsize, 5,0)
,        "Total MB" = str( (convert( numeric(28,5), s.pagecnt) * 2048) /1048576, 8,2)
,        "Density" = str( ( convert( numeric(28,5), s.rowcnt) * convert( numeric(28,5),s.datarowsize)
          + convert( numeric(28,5), 64*s.pagecnt) ) / (convert( numeric(28,5),s.pagecnt) * 2048 ),7,2)
FROM sysobjects o
,    systabstats s
WHERE  o.type = 'U'
AND   s.indid in ( 0,1)
AND   o.id = s.id
AND   ( o.name like '%_fact' OR o.name like '%_dimension' )
AND   o.name NOT LIKE 'tran_%'
ORDER BY rowcnt desc
go

quit
EOF

cat  ${OUTPUT}

########################################################################################################################################
# 2) Now, as of Jan 2009 check filesystem space as well:

FILESYSTEM_SPACE=`df -k ${DATA_DIRECTORY} | tail -1 | awk '{print $4}' | sed -e 's/\%//g'`
cd ${DATA_DIRECTORY}     #/UKRR_tst/

if [ ${FILESYSTEM_SPACE} -ge ${FILESYSTEM_THRESHOLD} ]
then
   echo \\n"Filesystem alert level is ${FILESYSTEM_THRESHOLD}% or around 5-10GB free as this is REQUIRED FOR BATCH PROCESSING." >  ${OUTPUT3}
   echo \\n"Run /home/ukrr_pm/scripts/filesystem_housekeeping.sh to CLEAR DOWN SOME SPACE."        >>  ${OUTPUT3}
   echo \\n"See this page for more info http://rbcwss.fg.rbc.com/ykl0/W99_EURUKRRSharepoint/Test%20Wiki/Housekeeping%20-%20Unix%20filesystem.aspx"        >>  ${OUTPUT3}
   echo \\n"Directory usage stats: "\\n                                                        >>  ${OUTPUT3}
   df -h /cm/ukrr_data/                                                                        >>  ${OUTPUT3}
   echo \\n"biggest sub-directories :"\\n                                                      >>  ${OUTPUT3}
   du -k  | grep ^[0-9][0-9][0-9][0-9] | grep -v snapshot | sort -nr |  head -30               >>  ${OUTPUT3}
   SUBJECT="UKRR ${ENVIRONMENT} filesystem space alert for ${DATA_DIRECTORY} - space used is ${FILESYSTEM_SPACE} %"
   cat ${OUTPUT3} | mutt -s "${SUBJECT}" "${DISTR_LIST}"
fi

