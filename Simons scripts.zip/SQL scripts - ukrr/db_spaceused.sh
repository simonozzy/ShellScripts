#!/bin/ksh
#/*********************************************************************************************
#  Name     : ~ukrr_pm/scripts/db_spaceused.sh
#  Purpose  : creates and runs spaceused commands for all user objects in given database
#  Usage    :  # db_spaceused.sh LDNEUR ukrr_ebs
#           :  OR with server name option in version 2 :
#           :  db_spaceused.sh LDNEUR ukrr_ebs
#           :  alias dbs1='db_spaceused.sh LDNEUR'
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  08/02/2005   S Osborne       Created
#
#*********************************************************************************************/

# Declare variables :

SN=${1}
DB_NAME=${2}

cd ${HOME}
COMMAND_OUTPUT="${HOME}/temp/db_spaceused_cmds.sql"
OUTPUT="${HOME}/temp/db_spaceused.out"

UN=`cat ~/.un`
PW=`cat ~/.pw`

if [ ${SN} != LDNEUR ] ; then echo Server Name : ${SN} ; fi

isql -U${UN} -S ${SN} -D${DB_NAME} -o ${COMMAND_OUTPUT} -w00000000000000000000000000002000 -P${PW} << EOF 

SET NOCOUNT ON

IF  EXISTS (SELECT 1 FROM master..sysdatabases WHERE name = '${DB_NAME}')
BEGIN
   PRINT '--list of user tables ...... : '

   PRINT '/*'

   SELECT name as "table_name"
   FROM  sysobjects
   WHERE type like "U"  
   ORDER BY name

   --exec sp__dbspace 

   PRINT '*/'

   PRINT '----------------------------------------------------------------------------------------------------'
   PRINT '--creating sp_spaceused commands ...... : '
   PRINT '-------------------------------------------------'
   PRINT ''

   PRINT 'SET NOCOUNT ON'

   SELECT 'sp_spaceused ' + name + '
go'
   FROM  sysobjects
   WHERE type like "U"  
   ORDER BY name
END
ELSE    PRINT '------------------ DATABASE ${DB_NAME} DOES NOT EXIST -------------------------- '
go

EOF

echo "running sp_spaceused commands for ${SN}..${DB_NAME} ...... : "

sed -e 's/^ //g' ${COMMAND_OUTPUT} | egrep "(^    |^sp_|^go)" >> ${HOME}/temp/temp.txt

isql -U${UN} -S ${SN} -D${DB_NAME} -w00000000000000000000000000002000 -o ${OUTPUT} -i ${HOME}/temp/temp.txt -P${PW} 

cat ${OUTPUT} | grep KB | sed -e "s/ KB//g" -e "s/^/ ${DB_NAME}/g" > ${HOME}/temp/temp.txt ; mv ${HOME}/temp/temp.txt ${OUTPUT}

awk  'BEGIN { format = "%-16s %-40s %10s %15s %10s %15s %10s \n"
              printf  format, "db_name", "table","rowtotal","reserved_KB", "data_KB", "index_size_KB", "unused_KB"
              printf  format, "--------------", "------------------------------", "----------", "----------", "----------", "----------", "----------" }
              {printf format, $1, $2, $3, $4, $5, $6, $7 }'  ${OUTPUT} | sort -k 4 -r 

echo

SQL_STRING="exec sp__dbspace\ngo"
echo ${SQL_STRING} | isql -U${UN} -S${SN} -D${DB_NAME} -P${PW} | egrep -v "affected|return"
