#!/bin/ksh
#/*********************************************************************************************
#  Name     : ~ukrr_pm/scripts/test_query_performance.sh
#  Purpose  : 
#  Usage    :  test_query_performance.sh
#           :  alias tqp='test_query_performance.sh &'
#           :  calls :  ~ukrr_pm/scripts/sql/test_query_performance.sql
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  19/04/2006   S Osborne       Created
#
#*********************************************************************************************/

# Declare variables :

SUBJECT="Query performance test result run on ${ENVIRONMENT} / ${SN}"
DISTR_LIST='simon.osborne@rbccm.com'

OUTPUT="${HOME}/temp/tqp.out"
OUTPUT2="${HOME}/temp/tqp2.out"
SQL_INPUT=~ukrr_pm/scripts/sql/test_query_performance.sql
> ${OUTPUT}
echo "\nOutput file is  ${HOME}/temp/tqp.out"
echo "\nInput SQL file is  ~ukrr_pm/scripts/sql/test_query_performance.sql"
sleep 3

# SN=`cat ~/.sn`
DB=ukrr_mart
UN=`cat ~/.un`
PW=`cat ~/.pw`

if [ ${SN} != LDNEUR ] ; then echo Server Name : ${SN} ; fi

# date '+Started at : %H:%M:%S'  #>> ${OUTPUT}

#isql -U${UN} -S ${SN} -D${DB}  -c -w00000000000000000000000000002000 -P${PW}  << EOF 
isql -U${UN} -S ${SN} -D${DB} -c -b -o ${OUTPUT} -w00000000000000000000000000002000 -P${PW}  << EOF 

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT 'Testing the above query performance : '
PRINT '-------------------------------------------------'
PRINT ''

SET nocount ON

SELECT start_time = getdate() INTO #log

--SET nocount OFF
SET showplan ON
--SET forceplan on
--SET statistics time ON
--SET noexec ON

--SELECT substring(convert(varchar(30),  getdate(), 109),13,12)  as "time_started_hh:mm:ss:mms"
SELECT "time_started_hh:mm:ss = " + substring(convert(varchar(30),  getdate(), 109),13,8)  

--###################################################################################################################

--# below reads input sql. NB: NO "go" at the end!
:r ${SQL_INPUT}  

--###################################################################################################################

SET noexec OFF

SET showplan OFF

--SET statistics time OFF
--SET nocount ON
--SET forceplan OFF

SELECT "Elapsed time_ = " + convert(char(12),dateadd(ss,datediff(ss,start_time,getdate()), '1/1/1900'),108) FROM  #log
--SELECT substring(convert(varchar(30),  getdate(), 109),13,12)  as "time_finished"

quit
EOF

# date '+Finished at : %H:%M:%S'  #>> ${OUTPUT}

echo "\nSQL used:\n - followed by Head -300 of output: \n"  > ${OUTPUT2}
echo "\n#################################################### \n"  >> ${OUTPUT2}
cat ${SQL_INPUT}                  >> ${OUTPUT2} 
echo "\n#################################################### \n"  >> ${OUTPUT2}

echo "\nTiming stats : \n"        >> ${OUTPUT2}
grep "time_" ${OUTPUT}            >> ${OUTPUT2}    

head -300 ${OUTPUT}               >> ${OUTPUT2}

#echo "\nTail -50 : \n"           >> ${OUTPUT2}
#tail -50 ${OUTPUT}               >> ${OUTPUT2}

echo "\nOutput Rowcount : \n"    >> ${OUTPUT2}
wc -l ${OUTPUT}                  >> ${OUTPUT2}    

cat ${OUTPUT2}
cat ${OUTPUT2} | mutt -s "${SUBJECT}"  "${DISTR_LIST}"
