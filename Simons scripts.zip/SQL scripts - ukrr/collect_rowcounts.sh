#!/bin/ksh
#/*********************************************************************************************
#  Name     : ~ukrr_pm/scripts/collect_rowcounts.sh
#  Purpose  : creates and runs rowcount commands for all collect tables with a given string in their name  and an optional number of days of history to use
#  Usage    :  collect_rowcounts.sh  rolf
#           :  alias crc='collect_rowcounts.sh'
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  12/09/2005   S Osborne       Created
#
#*********************************************************************************************/

# Declare variables :

TABLE=${1}
cd ${HOME}
COMMAND_OUTPUT="${HOME}/temp/crc_cmds.sql"
OUTPUT="${HOME}/temp/crc.out"

SN=`cat ~/.sn`
DB=ukrr_ctrl
UN=`cat ~/.un`
PW=`cat ~/.pw`

#Default no. of days to go back is 7 else if parameter is supplied use that. 
if [[ -z ${2} ]]
then
   DH=7
else
   DH=${2}
fi

#Default no. of days to go back is 7 else if parameter is supplied use that. 
if [[ -z ${3} ]]
then
   COLLECT_DB='%'
else
   COLLECT_DB=${3}
fi

if [ ${SN} != LDNEUR ] ; then echo Server Name : ${SN} ; fi


isql -U${UN} -S ${SN} -D${DB} -o ${OUTPUT} -w00000000000000000000000000002000 -P${PW} << EOF 

SET NOCOUNT ON

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT 'ukrr_ctrl..collect_table_archiving contents where db_name or tab_name  have "${TABLE}" in them : '
PRINT '-------------------------------------------------'
PRINT ''

SELECT  convert(varchar(40),db_name + '..' + tab_name)  as 'table'
--,      convert(char(9),db_name)  as 'db_name'
--,      tab_name             
,      convert(char(18),col_name)  as 'col_name'
,       convert (char(8), last_archive_date, 112)  as  'last_archive_date'
,       days_to_keep         
,       archive_flag         
,       archive_monthend_flag
FROM ukrr_ctrl..collect_table_archiving
WHERE (tab_name like '%' + '${TABLE}' + '%' 
OR     db_name like '%' + '${TABLE}' + '%'  )
AND    db_name like '%' + '${COLLECT_DB}' + '%'  
go

quit
EOF

cat ${OUTPUT}

isql -U${UN} -S ${SN} -D${DB} -o ${COMMAND_OUTPUT} -w00000000000000000000000000002000 -P${PW} << EOF 

SET NOCOUNT ON

PRINT 'SET NOCOUNT ON'

SELECT "SELECT " +  "'" +db_name+'..'+ tab_name +  "' , convert(char(8)," +  col_name + ",112) as 'loaded',count(*) FROM " + db_name + '..' + tab_name 
+ ' WHERE ' +  col_name + ' >=' +  "'" + convert(varchar(8), dateadd(dd,-${DH},getdate()) , 112) +  "'"  
+ ' GROUP BY  convert(char(8),' +  col_name + ",112)" 
+ '
go'
FROM   ukrr_ctrl..collect_table_archiving
WHERE (tab_name like '%' + '${TABLE}' + '%' 
OR     db_name like '%' + '${TABLE}' + '%'  )
AND    db_name like '%' + '${COLLECT_DB}' + '%'   
go

EOF

echo "\\nrunning rowcounts for the last ${DH} days (2nd paramater) for collect tables with '${TABLE}' in their name ...... : \\n"

# sed -e 's/^ //g' ${COMMAND_OUTPUT} | egrep "(^ |^SELECT |^go|NOCOUNT)"  > ${HOME}/temp/temp.txt
cat ${COMMAND_OUTPUT} | egrep "(^ |^SELECT |^go|NOCOUNT)"  > ${HOME}/temp/temp.txt

isql -U${UN} -S ${SN} -D${DB_NAME} -w00000000000000000000000000002000 -o ${OUTPUT} -i ${HOME}/temp/temp.txt -P${PW} 

echo SQL used :\\n
cat ${HOME}/temp/temp.txt | egrep -v "(^  |-----|NOCOUNT)" 
echo

egrep -v "loaded|-----" ${OUTPUT} | sort |  awk  'BEGIN { format = "%-40s %-12s %-10s \n"
        printf  format, "table", "loaded","rows"
        printf  format, "----------------------------------------", "------------", "---------" }
        {printf format, $1, $2, $3 }'  
