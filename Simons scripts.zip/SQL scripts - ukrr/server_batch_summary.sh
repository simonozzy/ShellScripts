#!/bin/ksh
#/*********************************************************************************************
#  Name     : ~ukrr_pm/scripts/server_batch_summary.sh
#  Purpose  : 
#  Usage    : alias sbs='server_batch_summary.sh'
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  22/11/2010   S Osborne       Created
#
#*********************************************************************************************/

# Declare variables :

. ~ukrr_pm/.profile

SCRIPT_NAME=server_batch_summary
RUNDATE=`date '+%Y-%m-%d'` 

OUTPUT=~ukrr_pm/log/${SCRIPT_NAME}.out
OUTPUT2=~ukrr_pm/log/${SCRIPT_NAME}2.out

SUBJECT="UKRR Server status check"
DISTR_LIST='Simon.Osborne@rbccm.com'
# DISTR_LIST='Aditi.Aurora@rbccm.com, Rahamat.Khan@rbccm.com, Lorcan.Neary@rbccm.com' # , UK-DatabaseAdmins@rbccm.com, '
# CC_LIST='Simon.Osborne@rbccm.com'

# LOG_FILE=~ukrr_pm/log/${SCRIPT_NAME}.out

UN=`cat ~/.un`
PW=`cat ~/.pw`

> ${OUTPUT2}

DB_NAME=pc_rep

# for SN in LDNEUR LDNEURUAT2_TN LNPEUR1_TN_DS LDNEURUAT3_DS LDNEURUAT4_DS LNUEUR2_DS LNUEUR1_DS # LDNEURBRP 
# for ENV in "UAT2_LR_T2|LNUEUR1_DS UAT3_LR_T2|LNUEUR1_DS"
# LDNEURDEV LDNEURDEV1_DS LDNEURBRP 
for ENV in '4) UAT3_PERF|LNPEUR2_DS' '5) UAT3_ASE15|LNUEUR3_DS' # '1) PROD|LDNEUR' '2) UAT1_LR|LNPEUR1_TN_DS' '3) UAT2_SLIM|LDNEURUAT2_TN'   '5) UAT5_SLIM_CONV|LNUEUR2_DS' '6) UAT4_EGB|LDNEURUAT3_DS' LDNEURBRP UAT4_LR_NOT_USED|LDNEURUAT4_DS
do

ENV_DESC=`echo "${ENV}" | cut -d"|" -f1`
SN=`echo "${ENV}" | cut -d"|" -f2`

# echo ${SN} ${ENV_DESC}

# echo "\n############################### Batch Summary for Sybase server:     ${SN}      (${ENV_DESC}) " >> ${OUTPUT2} 

isql -U${UN} -S ${SN} -D${DB_NAME} -o ${OUTPUT} -w00000000000000000000000000002000 -P${PW} << EOF 

SET NOCOUNT ON 

SELECT "Env_name | Server"      = "${ENV_DESC} | ${SN}"
,      "Start_time_hour"        = convert(char(9),  START_TIME, 112) + substring(convert(char(8),  START_TIME, 108),1,3) + '00'  
,      "Succesfull_job_count"   = sum(CASE WHEN RUN_STATUS_CODE in (1,6) THEN 1 ELSE 0 END ) 
,      "UNsuccesfull_job_count" = sum(CASE WHEN RUN_STATUS_CODE NOT in (1,6) THEN 1 ELSE NULL END ) 
FROM   pc_rep..REP_WFLOW_RUN  rc
WHERE START_TIME  >= dateadd(HH, -48, getdate())  
AND   rc.WORKFLOW_NAME NOT  IN ('b_CollectINFT_InterestCurve','s_CollectGCPInfinityProfile','s_CollectGCPInfinityCDO','s_CollectType1_OrgUnitDimension','b_CollectRIMS_WK' ) 
GROUP BY convert(char(9),  START_TIME, 112) + substring(convert(char(8),  START_TIME, 108),1,3) + '00'  
HAVING  sum(CASE WHEN RUN_STATUS_CODE in (1,6) THEN 1 ELSE 0 END ) > 0
go

quit
EOF

cat ${OUTPUT}  >> ${OUTPUT2} 
done

cat ${OUTPUT2} | egrep -v "(DB_name)"

# cat ${OUTPUT2} | egrep -v "(DB_name)" | mutt -s "${SUBJECT}"  "${DISTR_LIST}"  # -c "${CC_LIST}"



