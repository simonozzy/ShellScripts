#!/bin/ksh
#/*********************************************************************************************
#  Name     : compare_files.sh
#  Purpose  : 
#  Usage    :  compare_files.sh '/home/UKRR_tst/src/ribs' '/cm/ukrr_data/ftp'
#           :  compare_files.sh /home/UKRR_tst/src/ribs   /cm/ukrr_data/ftp 
#           :  #alias cf='compare_files.sh'
#           :  the first directory is the master list, so best to have this one having only the required files
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  28/03/2006   S Osborne       Created
#
#*********************************************************************************************/

# Declare variables :

#TEMP_FILE="${HOME}/temp/temp.txt"

DIR_1=${1}
DIR_2=${2}

#DIR_1='/home/UKRR_tst/src/ribs'
#DIR_2='/cm/ukrr_data/ftp'

echo "comparing all files in this directory : ${DIR_1} with MATCHING file names in this directory : ${DIR_2}" 
echo

echo "FILE_NAME COUNT_1 COUNT_2 COUNT_VAR DIFF_COUNT" | awk  '{printf "%-30s %10s %10s %10s %10s \n", $1, $2, $3, $4, $5 }'
echo "--------- ------- ------- --------- ----------" | awk  '{printf "%-30s %10s %10s %10s %10s \n", $1, $2, $3, $4, $5 }'

cd ${DIR_1} 

for FILE in `ls -1`
do
   COUNT_1=`cat ${FILE} | wc -l`
   COUNT_2=`cat ${DIR_2}/${FILE} | wc -l`
   COUNT_VAR=`expr ${COUNT_1} - ${COUNT_2}`
   DIFF_COUNT=`diff ${FILE} ${DIR_2}/${FILE} | wc -l`
   echo ${FILE} ${COUNT_1} ${COUNT_2} ${COUNT_VAR} ${DIFF_COUNT}  | awk  '{printf "%-30s %10s %10s %10s %10s \n", $1, $2, $3, $4, $5 }'
done






exit

awk  'BEGIN { format = "%-30s %10s %10s %10s \n"
              printf  format, "FILE_NAME", "table","rowtotal","reserved_KB", "data_KB", "index_size_KB", "unused_KB"
              printf  format, "--------------", "------------------------------", "----------", "----------", "----------", "----------", "----------" }
              {printf format, $1, $2, $3, $4, $5, $6, $7 }'  ${OUTPUT}
