#!/bin/ksh
###################################################################
# Script   : /cm/users/ukrr_pm/scripts/big.sh  / /cm/users/sosborne/scripts/big.sh
# Purpose  : This script looks for big files or dicrectories in the current file system.
# Usage    :  alias big='big.sh'
# Modifications :
# Date         User               Description
#  -------------------------------------------------------------------------------------------
# 28/09/2005   Simon Osborne      Script created
###################################################################

echo "\ndirectory usage :"
df -h .

echo \\n"biggest sub-directories - all bigger than 500MB :"\\n
du -h  | egrep "^..G|^...G|^....G" | sort -nr | head -10 | sed -e 's/G/GB/g'
du -h  | egrep "^[5-9][0-9][0-9]M" | sort -nr | head -10 | sed -e 's/M/MB/g'
# du -k  | grep ^[0-9][0-9][0-9][0-9] | sort -nr | head -20

echo "\nbig files in sub-directories :"
ls -1Rs   | grep -v total  | grep -v ./   | grep ^[0-9][0-9][0-9][0-9][0-9][0-9] | sort -nr | head -20

echo "\n files bigger than 100MB in sub-directories :"
ls -lhSr `find ./?* -size +100000000c -print` | egrep " [1-9][0-9][0-9]M|G "
#find ./?* -size   +200000000c -exec ls -lhSr {} \; 

# echo "\nbiggest files in current directory :"
# ls -l  | grep " [0-9][0-9][0-9][0-9][0-9][0-9][0-9]" | sort -r -t " " -k5

