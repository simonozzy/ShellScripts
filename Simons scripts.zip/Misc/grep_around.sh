#!/bin/ksh
#/*********************************************************************************************
#  Name     : grep_around.sh
#  Purpose  : 
#  Usage    : grep_around.sh
#           : alias grep2='grep_around.sh'
#           : grep_around.sh sql_de ukrrConfig.pl
#           : grep2          sql_de ukrrConfig.pl
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  08/06/2009   S Osborne       Created
#
#*********************************************************************************************/

# Declare variables :

#date '+Run on : %Y-%m-%d at %H:%M:%S' 
# RUNDATE=`date '+%Y-%m-%d %H:%M:%S'` 

SEARCH_STRING=${1}
# FILE=${2}

LINES_BEFORE=10

#Default FILE is trade, else use ${2} if this parameter is supplied. 
if [ -z ${2} ]
then
   FILE=/home/UKRR_tst/run_sh/scheduler/ukrrConfig.pl
else
   FILE=${2}
fi

# Default ROWS_TO_SHOW is 30, else use ${3} if this parameter is supplied. 

if [ -z ${3} ]
then
   ROWS_TO_SHOW=30
else
   ROWS_TO_SHOW=${3}
fi

LINES_AFTER=`expr ${ROWS_TO_SHOW} - ${LINES_BEFORE} `

#SEARCH_STRING=sql_de
#FILE=ukrrConfig.pl

echo 'Usage       :  grep2 SEARCH_STRING    // FILE  // ROWS_TO_SHOW   '    
echo 'Usage eg    :  grep2 b_CollectRIMS_ER    ukrrConfig.pl  20        '    
echo "Usage actual:  grep2 ${SEARCH_STRING} // ${FILE} // ${ROWS_TO_SHOW}"    

if [ $# -lt 1 ]
then
   echo '\n#################  TOO FEW PARAMETERS SUPPLIED - see above for usage info #################\n'
   exit
fi

echo "\nie Showing ${ROWS_TO_SHOW} rows around SEARCH_STRING = ${SEARCH_STRING} in file = ${FILE}\n\n"

for STRING_ROW_NO in `grep -n ${SEARCH_STRING} ${FILE} | cut -d":" -f1`
do
	echo "\nSTRING_ROW_NO = ${STRING_ROW_NO}:        ###############################################################################\n"
	# FIRST_ROW_NO=`expr ${STRING_ROW_NO} - 5 `
	LAST_ROW_NO=`expr ${STRING_ROW_NO} + ${LINES_AFTER} `
	head -${LAST_ROW_NO} ${FILE} | tail -${ROWS_TO_SHOW}
   # tail -${FIRST_ROW_NO} ${FILE} | head -${ROWS_TO_SHOW}
done



exit


