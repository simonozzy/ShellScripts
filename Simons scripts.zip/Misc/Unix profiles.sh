###################################################################################################
# ~/.profile: executed by the command interpreter for login shells.
# call with: . ${HOME}/.profile
# this version is for my home linux servers and DO droplets / VMs
# This file is not read by bash(1), if ~/.bash_profile or ~/.bash_login
# exists.
###################################################################################################

# the default umask is set in /etc/profile; for setting the umask
# for ssh logins, install and configure the libpam-umask package.
# umask 022

# if running bash
if [ -n "$BASH_VERSION" ]; then
    # include .bashrc if it exists
    if [ -f "$HOME/.bashrc" ]; then
        . "$HOME/.bashrc"
    fi
fi

# set PATH so it includes user's private bin if it exists
if [ -d "$HOME/bin" ] ; then
    PATH="$HOME/bin:$PATH"
fi

# set PATH so it includes user's private bin if it exists
if [ -d "$HOME/.local/bin" ] ; then
    PATH="$HOME/.local/bin:$PATH"
fi

# set PATH so it includes /opt/bin if it exists
if [ -d "/opt/bin" ] ; then
    PATH="/opt/bin:$PATH"
fi

.  ~/.envfile

###################################################################################################
#   ~/.envfile
# call with: . ${HOME}/.envfile
# BUT SEE current verions of this script in same dir called envfile_xx.sh

#!/bin/bash
umask 002

LC_ALL=C;export LC_ALL
EDITOR=vi;export EDITOR

MY_HOME=/root
LOGDIR=${MY_HOME}/logs
SCRIPTS_1=${MY_HOME}/scripts
TOOLS_SCRIPT=${MY_HOME}/unix_tools.sh
TMPDIR=/tmp 
TD=${TMPDIR}

uuu=`id -un`
PS1="${uuu}@${machine}"':$PWD>' 

export  MY_HOME SCRIPTS_1 TOOLS_SCRIPT LOGDIR PS1 TMPDIR TD

# Misc useful commands :
# . ${MY_HOME}/UNIX_utility_functions.sh
alias ll='ls -l'
alias ld='ls -ltr | grep ^d'
alias l='ls -ltr'
alias lls='ls -lhSr'
alias cls='clear'
alias hist='history'
alias m='less -MQR'
alias server='hostname |nslookup'

alias tse='vi ${TOOLS_SCRIPT}'
alias ree='. ${MY_HOME}/.envfile'
alias ene='echo "About to edit this file" ; ls -la ${MY_HOME}/.envfile ; sleep 3 ; vi ${MY_HOME}/.envfile'  # 

alias rf='echo "The most recent 20 files in this dir:\n" ; ls -ltr | tail -20 ; date "+Timecheck : %H:%M:%S"'
alias rf2='ls -ltr | tail -60 ; date "+Timecheck : %H:%M:%S"'
# WIP alias rf3='ls -lrt `find . -type f -mtime -3 -print` | tail -100 | awk {printf \"%-70s %12s %10s %2s %5s \n\", $9, $5, $6, $7, $8}'
alias rf3='echo "All files from the last 4 hours in all sub-dirs:\n"; ls -lrt `find . -type f -mmin -240 -print 2>/dev/null` | tail -30'
alias rf4='echo "All files from the last 4 DAYS in all sub-dirs:\n"; ls -lrt `find . -type f -mtime -4 -print 2>/dev/null` | tail -30'

alias me='echo "  ps -ef | grep mongo|docker|meteor etc"  : ; ps -ef | egrep "mongo|docker|meteor" | egrep -v "grep|-bash" | cut -c1-140 | sort ; date "+Timecheck : %H:%M:%S"'
alias me2='echo "  ps -ef | egrep -i ..."  ; ps -ef | egrep -i '
alias psm='echo " ps --user myser k-rss -o pid,tid,user,pmem,rss,vsz,pcpu,size,sz,comm,cmd | cut -c1-140" ; ps --user ${uuu} k-rss -o pid,tid,user,pmem,rss,vsz,pcpu,size,sz,comm,cmd | cut -c1-140'  
alias pst='echo " ps k-rss -eo pid,tid,uid,user,pmem,rss,vsz,pcpu,comm,cmd | cut -c1-140 | head -10" ; ps k-rss -eo pid,tid,uid,user,pmem,rss,vsz,pcpu,comm,cmd | cut -c1-140 | head -10'
alias topm='echo " top -n3 -d1 -bu  ${uuu} | egrep "${uuu}| PID|Mem:" " ; top -n3 -d1 -bu  ${uuu} | egrep "${uuu}| PID|Mem:" '  
alias topt='echo " top -n3 -d1 -b  | egrep pvkl0adm| PID|Mem: " ; top -n3 -d1 -bu  pvkl0adm | egrep "pvkl0adm| PID|Mem:" '  
alias fbf='echo "finding 10 biggest files in local dir: " ; find . -type f -ls 2> /dev/null | sort -nk5 -r | head -10'
alias dh='du -hs * | sort -rn | head -11'

alias chp='chmod 755'
alias fa='alias | grep -i'

alias big='${TOOLS_SCRIPT} big                      '
alias  ff='${TOOLS_SCRIPT} findfiles                '
alias fif='${TOOLS_SCRIPT} find_text_in_files       '
alias frc='${TOOLS_SCRIPT} file_and_row_count       '
alias ffm='${TOOLS_SCRIPT} find_files_older_months  '
alias dfm='${TOOLS_SCRIPT} delete_files_older_months'
alias zfb='${TOOLS_SCRIPT} zip_local_files_bigger   '
alias srv='${TOOLS_SCRIPT} server_info              '
# alias att='${TOOLS_SCRIPT} attach                   '
alias  ss='${TOOLS_SCRIPT} substitute_string        '

###################################################################################################
# /users/sosborne/.envfile OR  ~/.envfile
# OR /users/q4wn5gc/.envfile  # though yet to write to this file
# ALSO:   /users/dsadm/.envfile_sosborne  

#!/bin/sh
umask 002

LC_ALL=C;export LC_ALL
EDITOR=vi;export EDITOR

LD_LIBRARY_PATH='' ; PATH=/usr/xpg4/bin:/bin:/usr/local/bin:/usr/bin:/usr/sbin
DSH7=/app/ascential/Ascential/DataStage/DSEngine ; DSH8=/ibm/InformationServer/Server/DSEngine # DSHOME85=/ibm/InformationServer/Server/DSEngine

export machine=`uname -n`
case  ${machine} in
  lndvs342)  ENV=DEV  ; VER=UK81 ;PROJ="MRL_VFH0_${ENV}"    ;; 
  lnpss153)  ENV=UAT  ; VER=UK81 ;PROJ="MRL_VFH0_${ENV}"    ;; 
  lntrs419)  ENV=PRD  ; VER=UK81 ;PROJ="MRL_VFH0_${ENV}"    ;; 
  lnbrs374)  ENV=PRD  ; VER=UK81 ;PROJ="MRL_VFH0_${ENV}"    ;; 
  usvdstgd1) ENV=DEV  ; VER=75   ;PROJ='SLIM_Temp'          ;; 
  usvdstgt1) ENV=uat  ; VER=75   ;PROJ='slim_temp_uat'      ;; 
  usvdstgt2) ENV=uat  ; VER=75   ;PROJ='slim_temp_qa'       ;; 
  usvdstgq1) ENV=qa   ; VER=75   ;PROJ='slim_temp_qa'       ;; 
  usvdstgp1) ENV=PROD ; VER=75   ;PROJ="SLIM_XAU0_${ENV}"   ;; 
  uaetldsd1) ENV=DEV  ; VER=81   ;PROJ='CDR_dev'            ;; 
  uaetldst1) ENV=UAT  ; VER=81   ;PROJ='CDR_uat'            ;; 
  ulvetld02) ENV=DEV  ; VER=85   ;PROJ="SLIM_XAU0_${ENV}"   ;;
  ulvetlt02) ENV=UAT  ; VER=85   ;PROJ="SLIM_XAU0_${ENV}"   ;;
  ulvetlp02) ENV=PROD ; VER=85   ;PROJ="CDR_RECON_ZIU0_${ENV}" ;; 
  ###########
esac                                                                                     

uuu=`id -un`
PS1="${uuu}@${machine}"':$PWD>' 
MY_HOME=/users/${uuu}  # replaces CASE version of this above.

case  ${VER} in
  75)      S_C=/opt/bi/code/bin  ; SCRIPTS_2=/opt/bi/code/bin/slim/scripts ; MY_HOME=/users/q4wn5gc  ; DSH=${DSH7} ; TMPDIR=/tmp              ;;  #  LOGDIR=${MY_HOME}/logs  
  81)      S_C=/opt/etl/code/bin ; SCRIPTS_2=/users/q4wn5gc/scripts        ; MY_HOME=/users/q4wn5gc  ; DSH=${DSH8} ; TMPDIR=/data/temp        ;;  #    LOGDIR=/tmp             
  85)      S_C=/opt/etl/code/bin ; SCRIPTS_2=/users/q4wn5gc/scripts        ; MY_HOME=/users/q4wn5gc  ; DSH=${DSH8} ; TMPDIR=/data/etl/SAN/tmp ;;  #    LOGDIR=${MY_HOME}/logs ;
  UK81)    S_C=/opt/etl/code/bin ; SCRIPTS_2=/users/sosborne/scripts       ; MY_HOME=/users/sosborne ; DSH=${DSH8} ; TMPDIR=/tmp              ;;  #    LOGDIR=${SCRIPTS_2}/logs
esac

LOGDIR=${MY_HOME}/logs
TD=${TMPDIR}
SCRIPTS_COMMON=${S_C}
SCRIPTS_1=${MY_HOME}/scripts
SCRIPTS_3_85=/opt/etl/code/bin/common
SLIM_SCRIPT_HOME=/opt/etl/code/bin/common/SLIM_XAU0  # ; mkdir -p ${SLIM_SCRIPT_HOME}
SLIM_POLLER_HOME=${SCRIPTS_COMMON}/slim/DSExec

TOOLS_SCRIPT=${SCRIPTS_1}/unix_tools.sh
PROJ_DEF=${PROJ} ; ENVIRONMENT=${ENV} ; DB_SERVER=${DB} ; DSHOME=${DSH} ; 

case  ${uuu} in
   q4wn5gc)  DISTR_LIST='simon.osborne@rbccm.com'   ;;
   sosborne) DISTR_LIST='simon.osborne@rbccm.com'   ;;
   pzas0a1)  DISTR_LIST='simon.osborne@rbccm.com'   ;;
esac                                                                                     

export ENVIRONMENT PROJ_DEF MY_HOME DB_SERVER DB DSHOME SCRIPTS_1 TOOLS_SCRIPT VER LOGDIR PS1 DISTR_LIST SLIM_SCRIPT_HOME SCRIPTS_COMMON SLIM_POLLER_HOME TMPDIR TD

# ABSHOME=/ibm/InformationServer/ASBNode
if [ -r ${DSHOME}/dsenv ] ; then
  echo "Sourcing $DSHOME/dsenv..."
  . ${DSHOME}/dsenv
  echo "\n ############ SELECTED DSENV VARIBALES for the default SLIM project : ^UKRR|RDR|^SLIM_D|^ZINFIN|PATH_LON|^GLOSS_|^MAH_|^VS_FTP ############\n"
  dsadmin -listenv ${PROJ_DEF} | egrep -i "^UKRR|RDR|^SLIM_D|^ZINFIN|PATH_LON|^GLOSS_|^MAH_|^VS_FTP" | sort
else
  echo "Could not source ${DSHOME}/dsenv"
fi

PATH=~:$PATH:${MY_HOME}/:${MY_HOME}/scripts/:${DSHOME}/bin/:/usr/sybase;export PATH # :/users/ukrr_pm/scripts

if [ -n "$DSHOME" ] && [ -d "$DSHOME" ] && [ ${VER} = '85' ]
then
        . /opt/sybase15/SYBASE.sh
        ORACLE_HOME=/u01/app/oracle/product/10.2.0/clnt_64; export ORACLE_HOME
        LANG="en_US";export LANG
        LC_ALL="en_US";export LC_ALL
        LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$ORACLE_HOME/lib
        export LD_LIBRARY_PATH
        PATH=$PATH:$ORACLE_HOME/bin:/opt/etl/code/bin/common
        export PATH
fi

echo "\n ############ SELECTED ENV VARIBALE SETTINGS: HOME|PATH|SYB|ENVIRON|PROJ|HOST|ORACLE|USER ############\n"
env | egrep "HOME|PATH|SYB|ENVIRON|PROJ|HOST|ORACLE|USER" | sort

# set correct permissions
# chmod 755 ~/scripts/unix_tools.sh

# Misc useful commands :
. ${MY_HOME}/UNIX_utility_functions.sh
alias ll='ls -l'
alias ld='ls -ltr | grep ^d'
alias l='ls -ltr'
alias lls='ls -lhSr'
alias cls='clear'
alias hist='history'
alias m='less -MQR'
alias ftp='echo "NB: make sure to use full path in scripts: /usr/kerberos/bin/ftp" ; /usr/kerberos/bin/ftp'
alias server='hostname |nslookup'
alias int="cat ${SYBASE}/interfaces | egrep  -i 'LDNE|LNPE|LNUE|LNDE|UKRR|gpsqa|ased902|ased043|GLOSS|ASET032'; cat ${SYBASE}/interfaces | egrep  '^LDNEUR|^LNPEUR|^LNUEUR|^LNDEUR' ; ls -lL ${SYBASE}/interfaces"
alias int1=" ls -lL ${SYBASE}/interfaces ; cat ${SYBASE}/interfaces | egrep  -i "
alias ora='cat ${ORACLE_HOME}/network/admin/tnsnames.ora | egrep  -i "uasl|^dx|SLM001|=150" ; ls -l ${ORACLE_HOME}/network/admin/tnsnames.ora'
alias ora1='echo usage eg - for egrep on tnsnames.ora: ora "uasl|^d" ; ls -l ${ORACLE_HOME}/network/admin/tnsnames.ora; cat ${ORACLE_HOME}/network/admin/tnsnames.ora | egrep  -i '
alias odbc='cat ${DSHOME}/.odbc.ini | egrep -i "SLIM|dxau|uasl|gloss|gpsqa" | grep -v Description ; ls -l ${DSHOME}/.odbc.ini ; echo usage eg - for egrep "PortNumber|VMora|VMase" ' #lnpeu|lnueu|lndeu
if [ ${VER} = '75' ] ; then  alias gawk='/bin/nawk' ; fi

alias ce='cat ~sosborne/common_emails.txt'
alias ene='print "About to edit this file" ; ls -la ${MY_HOME}/.envfile ; sleep 3 ; vi ${MY_HOME}/.envfile'  # for 7.5 where using dsadm id: rm ${MY_HOME}/.envfil* ~/.envfil* ; ln -s ${MY_HOME}/.envfile ~/.envfile ; vi ~/.envfile 
alias tse='vi ${TOOLS_SCRIPT}'
alias ree='. ${MY_HOME}/.envfile'

alias rf='echo "The most recent 20 files in this dir:\n" ; ls -ltr | tail -20 ; date "+Timecheck : %H:%M:%S"'
alias rf2='ls -ltr | tail -60 ; date "+Timecheck : %H:%M:%S"'
# WIP alias rf3='ls -lrt `find . -type f -mtime -3 -print` | tail -100 | awk {printf \"%-70s %12s %10s %2s %5s \n\", $9, $5, $6, $7, $8}'
alias rf3='echo "All files from the last 4 hours in all sub-dirs:\n"; ls -lrt `find . -type f -mmin -240 -print 2>/dev/null` | tail -30'
alias rf4='echo "All files from the last 4 DAYS in all sub-dirs:\n"; ls -lrt `find . -type f -mtime -4 -print 2>/dev/null` | tail -30'

alias big='${TOOLS_SCRIPT} big                      '
alias  ff='${TOOLS_SCRIPT} findfiles                '
alias fif='${TOOLS_SCRIPT} find_text_in_files       '
alias frc='${TOOLS_SCRIPT} file_and_row_count       '
alias ffm='${TOOLS_SCRIPT} find_files_older_months  '
alias dfm='${TOOLS_SCRIPT} delete_files_older_months'
alias zfb='${TOOLS_SCRIPT} zip_local_files_bigger   '
alias esf='${TOOLS_SCRIPT} ETL_sourcefile_check     '
alias sfm='${TOOLS_SCRIPT} source_file_missing      '
alias tfm='${TOOLS_SCRIPT} target_file_missing      '
alias srv='${TOOLS_SCRIPT} server_info              '
alias dlf='${TOOLS_SCRIPT} download_latest_files    '
alias cft='${TOOLS_SCRIPT} copy_from_tmp            '
alias cnn='${TOOLS_SCRIPT} check_new_NAS_files      '
alias dpw='${TOOLS_SCRIPT} daily_prod_workarounds   '
alias att='${TOOLS_SCRIPT} attach                   '
alias  ss='${TOOLS_SCRIPT} substitute_string        '
alias spv='${TOOLS_SCRIPT} slim_project_variables   ' 

alias me='echo "  ps -ef | grep dsexec|bp|ibm|sosborne|q4wn5gc|ukrr etc"  : ; ps -ef | egrep "dsexec|bp|ibm|sosborne|q4wn5gc|ukrr" | egrep -v "^root|grep|-ksh" | cut -c1-140 | sort ; date "+Timecheck : %H:%M:%S"'
alias me2='echo "  ps -ef | egrep -i ..."  ; ps -ef | egrep -i '
alias kpj="echo 'killing these after 3s pause:' ;  ps -ef | egrep -i 'phantom.*DataClensing' | grep -v grep ; sleep 3; kill -9 \$(ps -ef | egrep -i 'phantom.*DataClensing'  | grep -v grep | awk '{print \$2}') "
alias psm='echo " ps --user myser k-rss -o pid,tid,user,pmem,rss,vsz,pcpu,size,sz,comm,cmd | cut -c1-140" ; ps --user ${uuu} k-rss -o pid,tid,user,pmem,rss,vsz,pcpu,size,sz,comm,cmd | cut -c1-140'  
alias pst='echo " ps k-rss -eo pid,tid,uid,user,pmem,rss,vsz,pcpu,comm,cmd | cut -c1-140 | head -10" ; ps k-rss -eo pid,tid,uid,user,pmem,rss,vsz,pcpu,comm,cmd | cut -c1-140 | head -10'
alias topm='echo " top -n3 -d1 -bu  ${uuu} | egrep "${uuu}| PID|Mem:" " ; top -n3 -d1 -bu  ${uuu} | egrep "${uuu}| PID|Mem:" '  
alias topt='echo " top -n3 -d1 -b  | egrep pvkl0adm| PID|Mem: " ; top -n3 -d1 -bu  pvkl0adm | egrep "pvkl0adm| PID|Mem:" '  
alias fbf='echo "finding 10 biggest files in local dir: " ; find . -type f -ls 2> /dev/null | sort -nk5 -r | head -10'
alias dh='du -hs * | sort -rn | head -11'

alias chp='chmod 755'
alias fa='alias | grep -i'
alias dog='cat_alias_script.sh'
alias ulg='echo "\nUnix log recent entries from /var/adm/messages\n" ; tail -200 /var/adm/messages | egrep -v "repeated" | tail -30 ; echo "\nAnd summarised by just the first few words \n"; tail -200 /var/adm/messages | cut -c 1-30 | sort -u | tail -40'
# alias p2u='copy_prod_to_uat.sh'
# alias csql='/home/ukrr_pm/scripts/call_sql.sh'
alias env2='echo "\nenv | egrep HOME|PATH|SYB|ENVI|PROJ|HOST|ORA|USER :\n"  ; env | egrep "HOME|PATH|SYB|ENVI|PROJ|HOST|ORA|USER" | sort'
alias eng='echo running: env | sort | grep -i ...  ; env | sort | grep -i '

# Sudo commands  :
alias suz='echo changing user to pzas0a1 - run after: ". /users/q4wn5gc/.envfile OR . /users/sosborne/.envfile" .. ; sudo /bin/su - pzas0a1'
alias sua='echo changing user to pzasadm - run after: ". /users/q4wn5gc/.envfile OR . /users/sosborne/.envfile" .. ; sudo /bin/su - pzasadm'
alias sus='echo to change user to slmfdr[xx], type: sudo /bin/su - slmfdr[xx] - run after: ". /users/q4wn5gc/.envfile" '
alias suq='echo changing user to q4wn5gc@${machine} : ; ssh q4wn5gc@${machine}'

# Switch ENV commands  :
alias sps='echo Switching DS project to PROJ_DEF=SLIM_XAU0_${ENV}      ; PROJ_DEF=SLIM_XAU0_${ENV}      ; export PROJ_DEF'
alias spc='echo Switching DS project to PROJ_DEF=CDR_RECON_ZIU0_${ENV} ; PROJ_DEF=CDR_RECON_ZIU0_${ENV} ; export PROJ_DEF'
alias spo='echo Switching DS project to PROJ_DEF=OBIEE_VQS0_${ENV}     ; PROJ_DEF=OBIEE_VQS0_${ENV}     ; export PROJ_DEF'
alias spb='echo Switching DS project to PROJ_DEF=CDR_ZIU0_${ENV}       ; PROJ_DEF=CDR_ZIU0_${ENV} ; export PROJ_DEF'
alias spbm='echo Switching DS project to PROJ_DEF=CDR_Migration       ; PROJ_DEF=CDR_Migration ; export PROJ_DEF'

# Misc DIR commands:
alias sc1='cd ${SCRIPTS_1} ; ls -lrt | tail -20 ; pwd'
alias sc2='cd ${SCRIPTS_2} ; ls -lrt | tail -20 ; pwd'
alias sc3='cd ${SCRIPTS_3_85} ; ls -lrt | tail -20 ; pwd'
alias dsh='cd ${DSHOME} ; ls -lrt | tail -20 ; pwd'
alias cdc='cd /data/etl/NAS/ZAS0/CDR_RECON/incoming/  ; ls -lrt | tail -20 ; pwd'
alias cdc2='cd /data/etl/SAN/CDR/logs ; ls -lrt | tail -20 ; ls -lrt ../work | tail -20  ; pwd'
alias cds='cd ${SLIM_SCRIPT_HOME} ; ls -lrt | tail -20 ; pwd'
alias rtfd='DIR=/app/orf/control/events ;  cd ${DIR} ; tail -20 `ls -1rt feed_events.log* | tail -3` | grep Completed | cut -d"|" -f8,1,4 ; ls -lrt | tail -20 ; ls -ld ../ ; ls -ld ${DIR} '

alias prh='cd /opt/etl/projects/${PROJ_DEF}/ ; ls -lrt | tail -20 ; pwd ; ls -ld ; l DSParams'
alias cdt='cd ${TMPDIR} ; rf ; pwd'
function ctt { 
    echo running: cp "*${1}*" ${TMPDIR} .. ; cp  *${1}* ${TMPDIR} ; cd ${TMPDIR} ; ls -ltr | tail -20 ; date "+Timecheck : %H:%M:%S" ; pwd
}
# Misc Datastage / poller commands :
alias cdp='echo cding to poller dir, listing files and tailing poller.properties; cd ${SLIM_POLLER_HOME}/scripts ; ls -lrt | tail -10 ; pwd ; tail -10 poller.properties ; ls -lrt ../logs | tail -5'
alias prj="echo recent 30 SLIM poller jobs: ; tail -1000 ${SLIM_POLLER_HOME}/logs/runjob.log | egrep -i 'BATCH_BUS_DATE|Job Status' | tail -30 | awk '{print \$2, \$3, \$4, \$(NF-1), \$NF}' ; ps -ef | egrep -i 'dsexec|bp' "
alias pls='nohup ${SLIM_POLLER_HOME}/scripts/bp.ksh &; sleep 4 ; ps -ef | egrep "bp|dsexec"'

alias dsl='echo running: job_log_check_named.ksh {dsjob -logdetails}  [job_name] [project] .. ; ${SCRIPTS_1}/job_log_check_named.ksh'
alias dsl2='echo running: job_log_check_latest.ksh {dsjob -logdetails} [job_name] [project]  .. ; ${SCRIPTS_1}/job_log_check_latest.ksh'
alias dsl3='echo running: DSjob_error_check.ksh {dsjob -logdetails} [job_name] [project] .. ; ${SCRIPTS_1}/DSjob_error_check.ksh'

alias dsi='echo running: dsjob -jobinfo ${PROJ_DEF} [job_name] ..         ; dsjob -jobinfo ${PROJ_DEF} '
alias dslp='echo running: dsjob -lparams ${PROJ_DEF} [job_name] ..         ; dsjob -lparams ${PROJ_DEF} '
function dsr {   
     echo running: dsjob -report  ${PROJ_DEF} [job_name] DETAIL .. ; dsjob -report ${PROJ_DEF} ${1} DETAIL  
}
alias dsr2='echo running: dsjob -report  ${PROJ_DEF} [job_name] ..         ; dsjob -report ${PROJ_DEF} '
alias dsf='echo running: dsjob -ljobs ${PROJ_DEF}  | egrep -i ..           ; dsjob -ljobs ${PROJ_DEF}  | egrep -i '
alias dsp='echo running: dsjob -lprojects  | grep -i ..                             ; dsjob -lprojects '
alias dsv='echo running: dsjob -listenv ${PROJ_DEF} - grep -v "^APT_" | sort | egrep -i ...  ; dsadmin -listenv ${PROJ_DEF} | grep -v "^APT_" | sort | egrep -i '
alias pvs='echo running: dsjob -listenv ${PROJ_DEF}-grep -i "TY_DB_S|TY_DB_NAME|ORT_DB_S|RDR_T|MAH_T|IM_DSN|NT_DB_S|US_DB_S" .. ; dsadmin -listenv ${PROJ_DEF} | egrep -i "TY_DB_S|TY_DB_NAME|ORT_DB_S|RDR_T|MAH_T|IM_DSN|NT_DB_S|US_DB_S" | sort '
alias pvb='echo running: dsjob -listenv ${PROJ_DEF}-grep -i "PATH|DIR|FILE|^CDR_DB_|^BDR_DB_|^CDR_AVL" .. ; dsadmin -listenv ${PROJ_DEF} | egrep -i "PATH|DIR|FILE|^CDR_DB_|^BDR_DB_|^CDR_AVL" | egrep -i "ANVIL|SOPHIS|FIB|DB_NAME|DB_SERVER|BIN_" | sort '
alias cv1="echo switching CDR_DB_DBNAME to gcplus_qa; dsadmin -envset CDR_DB_DBNAME -value gcplus_qa CDR_RECON_ZIU0_${ENV}"
alias cv2="echo switching CDR_DB_DBNAME to gcplus_preprod; dsadmin -envset CDR_DB_DBNAME -value gcplus_preprod CDR_RECON_ZIU0_${ENV}"

alias dsx='echo running: dsjob -run -mode RESET ${PROJ_DEF} [job_name] .. ; dsjob -run -mode RESET -jobstatus ${PROJ_DEF} '
alias dsk='echo running: dsjob -stop ${PROJ_DEF} [job_name] | grep -i .. ; dsjob -stop ${PROJ_DEF} '

alias dsj='echo running: dsjob -run -jobstatus ${PROJ_DEF} [job_name]  .. ; dsjob -run -jobstatus ${PROJ_DEF} '
alias dsjs='echo "running: DSjob_run_batches.sh <BUSINESS_DATE> <job_string> [excl_string] ${PROJ_DEF} .." ; DSjob_run_batches.sh'
alias cbdr='ETL_DSJobExe.ksh /opt/etl/code/bin/common ${PROJ_DEF} ${SEQ}' # -Reset '
alias ltj='cat ${MY_HOME}/scripts/ETL_batch_list.txt | sort | egrep -i '

# Misc useful shellscripts:
alias sfc='/users/q4wn5gc/scripts/source_file_uat_phased_copy.sh'
alias sdb='echo "running: SLIM_DB_checks.sh .." ; SLIM_DB_checks.sh'
alias cdb='echo "running: CDR_REC_DB_checks.sh .." ; CDR_REC_DB_checks.sh'

# Misc Tidal commands - DS 8.5 - maybe all same dir?  :
TIDAL_LOGFILE=`ls -1rt /opt/TIDAL/Agent/agent1/logs/ES_SE??????_1.log | tail -1` ; export TIDAL_LOGFILE
TIDAL_CRASHFILE=`ls -1rt /opt/TIDAL/Agent/agent1/tagent.????.log | tail -1`  ; export TIDAL_CRASHFILE
alias td1='echo TIDAL_CRASHFILE: ; ls -lrt ${TIDAL_CRASHFILE} ; sleep 3 ; tail -50 ${TIDAL_CRASHFILE} ; echo TIDAL_LOGFILE: ; ls -lrt ${TIDAL_LOGFILE} ; sleep 3 ; tail -50 ${TIDAL_LOGFILE} ' 
alias td2="tail -2000 ${TIDAL_LOGFILE} | grep 'process finished' | cut -c1-13 | awk '{cnt[\$2\$1\$3]++;} END{for (v in cnt) print v, cnt[v]}' | sort"


###################################################################################################
# Env setup for sosborne / q4wn5gc as at at Jan 2012 :

mkdir -p /users/sosborne/scripts/logs         ; chmod 777 -R /users/sosborne/scripts/logs*
mkdir -p /users/q4wn5gc/scripts/logs         ; chmod 777 -R /users/q4wn5gc/scripts/logs*

#7.5 dsadm:
mkdir -p /users/dsadm/bin/scripts/
MY_HOME=/users/q4wn5gc # MY_HOME=/users/dsadm/bin
rm ${MY_HOME}/.envfil* ~/.envfil* ; ln -s /users/q4wn5gc/.envfile ${MY_HOME}/.envfile ; ln -s /users/q4wn5gc/.envfile ~/.envfile ; l ~/.envfile 

ln -s  /users/dsadm/bin/.envfile /users/q4wn5gc/.envfile



###################################################################################################
# DS ${DSHOME}/dsenv profile :

#!/bin/sh
####################################################################
#
# dsenv - DataStage environment file
#
#       Licensed Materials - Property of IBM (c) Copyright IBM Corp. 1997, 2009 All Rights Reserved.
#       This is unpublished proprietary source code of IBM Corporation
#       The copyright notice above does not evidence any actual or
#       intended publication of such source code.
#
# This script is sourced by the DataStage dsrpcd daemon to establish
# proper environment settings for DataStage client connections.
#
# This script may also be sourced by bourne shells to establish
# proper environment settings for local DataStage use.
#
####################################################################

# PLATFORM SPECIFIC SECTION

set +u

if [ -z "$DSHOME" ] && [ -f "/.dshome" ]
then
        DSHOME=`cat /.dshome`
        export DSHOME
fi

if [ -z "$DSHOME" ]
then
DSHOME=/ibm/InformationServer/Server/DSEngine; export DSHOME
fi

DS_HOSTNAME_ALIAS=ds85vld02;export DS_HOSTNAME_ALIAS
APT_PM_CONDUCTOR_HOSTNAME=ds85vld02; export APT_PM_CONDUCTOR_HOSTNAME

if [ -z "$DSRPCD_PORT_NUMBER" ]
then
        true
DSRPCD_PORT_NUMBER=31538; export DSRPCD_PORT_NUMBER
fi

if [ -z "$APT_ORCHHOME" ]
then
APT_ORCHHOME=/ibm/InformationServer/Server/PXEngine; export APT_ORCHHOME
fi

#if [ -z "$UDTHOME" ]
#then
UDTHOME=/ibm/InformationServer/Server/DSEngine/ud41 ; export UDTHOME
UDTBIN=/ibm/InformationServer/Server/DSEngine/ud41/bin ; export UDTBIN
#fi

#if [ -z "$ASBHOME" ] && [ -f "$DSHOME/.asbnode" ]
#then
        ASBHOME=`cat $DSHOME/.asbnode`
        export ASBHOME
#fi

#if [ -z "$ASBHOME" ]
#then
        #ASBHOME=`dirname \`dirname $DSHOME\``/ASBNode
        #export ASBHOME
#fi

. /opt/sybase15/SYBASE.sh
. /home/pajzasc/sqllib/db2profile

if [ -n "$DSHOME" ] && [ -d "$DSHOME" ]
then
        ODBCINI=$DSHOME/.odbc.ini; export ODBCINI
        HOME=${HOME:-/}; export HOME
        ORACLE_HOME=/u01/app/oracle/product/10.2.0/clnt_64; export ORACLE_HOME

        LANG="en_US";export LANG
        LC_ALL="en_US";export LC_ALL
        #LC_CTYPE="<langdef>";export LC_CTYPE
        #LC_COLLATE="<langdef>";export LC_COLLATE
        #LC_MONETARY="<langdef>";export LC_MONETARY
        #LC_NUMERIC="<langdef>";export LC_NUMERIC
        #LC_TIME="<langdef>";export LC_TIME
        #LC_MESSAGES="<langdef>"; export LC_MESSAGES

        LD_LIBRARY_PATH=`dirname $DSHOME`/branded_odbc/lib:`dirname $DSHOME`/DSComponents/lib:`dirname $DSHOME`/DSComponents/bin:$DSHOME/lib:$DSHOME/uvdlls:`dirname $DSHOME`/PXEngine/lib:$ASBHOME/apps/jre/bin:$ASBHOME/apps/jre/bin/classic:$ASBHOME/lib/cpp:$ASBHOME/apps/proxy/cpp/linux-all-x86_64:$LD_LIBRARY_PATH:$ORACLE_HOME/lib:$ASBHOME/apps/jre/bin:$ASBHOME/apps/jre/bin/j9vm:$ASBHOME/apps/jre/bin/classic
        export LD_LIBRARY_PATH
        #LD_PRELOAD=`dirname $DSHOME`/DSComponents/lib/libicui18n.so
        #export LD_PRELOAD

        PATH=$PATH:$DSHOME/bin:$ORACLE_HOME/bin:$ASBHOME/apps/jre/bin:/opt/etl/code/bin/common
        export PATH

        MERC_DO_NOT_CHDIR=TRUE
        export MERC_DO_NOT_CHDIR

        ulimit -d unlimited
        ulimit -m unlimited
        ulimit -s 65536
        ulimit -f unlimited
        ulimit -n 8196

fi


###################################################################################################
# Old .envfile stuff:

#LD_LIBRARY_PATH=`dirname $DSHOME`/branded_odbc/lib:`dirname $DSHOME`/DSComponents/lib:`dirname $DSHOME`/DSComponents/bin:$DSHOME/lib:$DSHOME/uvdlls:$ABSHOME/lib/cpp:`dirname $DSHOME`/PXEngine/lib:$ASBHOME/apps/jre/bin:$ASBHOME/apps/jre/bin/classic:$ASBHOME/apps/proxy/cpp/linux-all-x86:$LD_LIBRARY_PATH
#export LD_LIBRARY_PATH


#if [ -t 0 ]
#then
#        stty erase " kill "" intr "" eof "" susp "
#fi

# . /opt/sybase/SYBASE.sh
# PATH=~:$PATH:/usr/local/bin:/home/pm5_2/informatica/pm:~ukrr_pm/scripts:/cm/ukrr_data/UKRR_tst/run_sh/scripts:/usr/sybase;export PATH

# 75)      S_C=/opt/bi/code/bin  ; SCRIPTS_2=/opt/bi/code/bin/slim/scripts ; LOGDIR=${SCRIPTS_2}/logs ; DSH=${DSH7} ; TMPDIR=${SCRIPTS_2}/logs ;;  # MY_HOME=/opt/bi/code/bin/; 
  INF8)    SCRIPTS_2=/users/sosborne/scripts  ; LOGDIR=${SCRIPTS_2}/logs ; INFA_DIR=informatica ;;                      # MY_HOME=/users/sosborne  ; 
  INF8b)   SCRIPTS_2=/users/sosborne/scripts  ; LOGDIR=${SCRIPTS_2}/logs ; INFA_DIR=Informatica ;;  # NB: [I]nform.     # MY_HOME=/users/sosborne  ; 

# DSQUERY=LDNEURDEV; export DSQUERY

LD_LIBRARY_PATH=/home/pm5_2/informatica/pm:$LD_LIBRARY_PATH; export LD_LIBRARY_PATH

# Sudo commands  :
alias sup='echo changing user to pm5_2 .. ; sudo /bin/su - pm5_2'
alias suu='echo changing user to ukrr_pm .. ; sudo /bin/su - ukrr_pm'
alias suo='echo changing user to ukrr_op .. ; sudo /bin/su - ukrr_op'
alias sud='echo changing user to ukrr_data .. ; sudo /bin/su - ukrr_data'

# Misc Erebus commands:
alias erf='cd /cm/erebus/feeds/source/  ; ls -lrt | tail -20 ; pwd' # esf = erebus source files
alias efc='/users/sosborne/scripts/erebus_file_check.sh'
alias efr='/users/sosborne/scripts/erebus_file_rowcount.sh'
alias erl='echo "Erebus report list: "; cd /cm/erebus/reports ; ls -lrt | tail -50 ; pwd'

alias spf='echo Switching DS project to PROJ_DEF=SFCS_YSQ0_${ENV}      ; PROJ_DEF=SFCS_YSQ0_${ENV}      ; export PROJ_DEF'
alias spa='echo Switching DS project to PROJ_DEF=AXIOM_YSQ0_${ENV}     ; PROJ_DEF=AXIOM_YSQ0_${ENV}     ; export PROJ_DEF'

#SYBASE=/opt/sybase; export SYBASE

# export EMAIL='UKRR-support@rbccm.com'
#PS1=$uuu' on $PWD>'
#PS2="... and more>"
# UKRR_HOME=/cm/ukrr_data/UKRR_tst; export UKRR_HOME

# alias int2hex='perl -e printf\ \"%lx\\n\",\$_\ foreach\ @ARGV' //  alias urlencode='perl -ple "s/([^a-zA-Z0-9_.-])/uc sprintf(qq(%%%02x),ord(\$1))/eg"'

#Aliases - now within .envfile
# . /cm/users/ukrr_pm/.alias


###################################################################################################
# lnpss130/1 : ukrr_pm on /home/ukrr_pm>cat .profile
# AND now, same as this  - why shouldn't it be? ....:
# lnpss130/1 : pm5_2 on /opt/pm5_2> cat .profile
# NOW here:  /cm/users/sosborne/.ukrr_envfile

export TERM=vt100
umask 002

LC_ALL=C;export LC_ALL
EDITOR=vi;export EDITOR

. /opt/sybase/SYBASE.sh

export machine=`uname -n`
export SERVER_NODE=`echo ${machine} | cut -c5-9 | tr "[:lower:]" "[:upper:]"`

case  ${machine} in
  lndvs330)  ENV=DEV ; VER=INF8 ; DB='LNDEUR1_DS'      ; UKRR_HOME=/cm/ukrr_data/UKRR_tst ;;
  lnpss130)  ENV=SIT ; VER=INF8 ; DB='LNDEUR2_DS'      ; UKRR_HOME=/cm/ukrr_data/UKRR_tst ;;  # LR SIT
  lnpss131)  ENV=UAT ; VER=INF8 ; DB='LNPEUR1_TN_DS'   ; UKRR_HOME=/cm/ukrr_data/UKRR_uat ;;  # LR UAT
  lnpss142)  ENV=UAT2; VER=INF8 ; DB='LDNEURUAT2_TN'   ; UKRR_HOME=/cm/ukrr_data/UKRR_uat2 ;; #  SLIM SIT / UAT
  lnpss146)  ENV=UAT3; VER=INF8b; DB='LNUEUR1_DS'      ; UKRR_HOME=/cm/ukrr_data/UKRR_uat3 ;; # NB: [I]nform. For T+2 // testing
  lnpss145)  ENV=UAT4; VER=INF8 ; DB='LNPEUR1_UAT3_DS' ; UKRR_HOME=/cm/ukrr_data/UKRR_uat4 ;; # EGB testing
  lnpss147)  ENV=UAT5; VER=INF8 ; DB='LNUEUR2_DS'      ; UKRR_HOME=/cm/ukrr_data/UKRR_uat5 ;; # SLIM conversion
esac

case  ${VER} in
  INF8)   MY_HOME=/users/sosborne  ; SCRIPTS_2=/users/sosborne/scripts  ; LOGDIR=${SCRIPTS_2}/logs ; INFA_DIR=informatica ;;
  INF8b)  MY_HOME=/users/sosborne  ; SCRIPTS_2=/users/sosborne/scripts  ; LOGDIR=${SCRIPTS_2}/logs ; INFA_DIR=Informatica ;;  # NB: [I]nform.
esac                                                                                     

INFA_HOME=/home/pm5_2/${INFA_DIR}/PowerCenter8.6.1

INFA_HOME=/home/pm5_2/informatica/PowerCenter8.6.1  # /home/pm5_2/informatica/PowerCenter8.6.0_64
export INFA_HOME

PATH=$INFA_HOME/server/bin:~:$PATH:/bin:/usr/sbin:~ukrr_pm/scripts:/cm/ukrr_data/UKRR_tst/run_sh/scripts:/usr/sybase
export PATH

LD_LIBRARY_PATH=$INFA_HOME/server/bin:$LD_LIBRARY_PATH   ;   export LD_LIBRARY_PATH
#LD_LIBRARY_PATH=/cm/opt_tools_redhatEL4-64bit/freetds/lib/:$INFA_HOME/server/bin:$LD_LIBRARY_PATH   ;   export LD_LIBRARY_PATH
# PERL5LIB=/opt/tools/lib/perl5/site_perl/:/opt/tools/lib/perl5/5.8.0/:/opt/tools/perl-5.8.7/lib/site_perl/5.8.7

INFA_DEFAULT_DOMAIN=Domain_${ENVIRONMENT}                       ; export INFA_DEFAULT_DOMAIN
INFA_DEFAULT_DOMAIN_USER=admin                                  ; export INFA_DEFAULT_DOMAIN_USER
INFA_DEFAULT_DOMAIN_PASSWORD=m64NsOyNNI2Lk6xkCuSkLw==           ; export INFA_DEFAULT_DOMAIN_PASSWORD

INT_USER=ukrr_pm                                                ; export INT_USER
INT_PASS=Xrw0xz0SCo3GsNTXwCdx+Q==                               ; export INT_PASS
INT_SRV=INT_SVC                                                 ; export INT_SRV
INFA_SERVER_LOG=${INFA_HOME}/server/tomcat/logs/node.log        ; export INFA_SERVER_LOG

SN=${DB_SERVER} ; DSQUERY=${DB_SERVER} ; export ENVIRONMENT DB_SERVER  SN DSQUERY UKRR_HOME INFA_HOME

export EMAIL='UKRR-support@rbccm.com'
# export PM_PASSWORD=rep0s1t0ry
# export WEB_DIR=/cm/www_data/webroot/ukrr/logs
# export ARCHIVE_DIR=/cm/ukrr_data

#Aliases

alias sqlu="echo isql ${DB_SERVER}..ukrr_mart as ukrr : ; isql -Uukrr -S ${DB_SERVER} -D ukrr_mart -w2000"

alias sqld='echo isql LDNEURDEV..ukrr_mart : ; isql -Uukrr -S LDNEURDEV -D ukrr_mart -w2000'
alias sqlu1='echo isql LDNEUR_TN..ukrr_mart : ; isql -Uukrr -S LDNEUR_TN -D ukrr_mart -w2000'
alias sqlu2='echo isql LDNEURUAT2_TN..ukrr_mart : ; isql -Uukrr -S LDNEURUAT2_TN -D ukrr_mart -w2000'
alias sqlu3='echo isql LDNEURUAT3_DS..ukrr_mart : ; isql -Uukrr -S LDNEURUAT3_DS -D ukrr_ctrl -w2000'
alias sqlu4='echo isql LDNEURUAT4_DS..ukrr_mart : ; isql -Uukrr -S LDNEURUAT4_DS -D ukrr_ctrl -w2000'

alias sfs='call_sql.sh slim_feed_status_summary ${SN} "simon.osborne@rbccm.com"'

alias int="cat ${SYBASE}/interfaces | egrep  -i 'LDNEUR|LNPEUR|LNUEUR|LNDEUR|UKRR|lndvs269|lnbrs207|LDNINFGCP|TORCTS|LDNGCPRPT|PLDNINF10|TORCTS|^#'; cat ${SYBASE}interfaces | egrep  '^LDNEUR|^LNPEUR|^LNUEUR|^LNDEUR' ; ls -lL ${SYBASE}interfaces"

# . ~ukrr_pm/.alias


###################################################################################################
# lntrs375 : ukrr_pm on /home/ukrr_pm>cat .profile

# The "case  ${machine}" now means that each time you login to a box, the whole environement will be set according to which box you login to
# -> and ALL BOXES CAN HAVE THE EXACT SAME .PROFILE NOW !!
# -> AND pm5_2 can have the SAME profile or even just refer to the ukrr_pm profile - easy! :  . ~ukrr_pm/.profile

export TERM=vt100
umask 002

LC_ALL=C;export LC_ALL
EDITOR=vi;export EDITOR

. /opt/sybase/SYBASE.sh
# UAT . /cm/opt_tools_redhatEL4-64bit/sybase15/SYBASE.sh

export machine=`uname -n`
export SERVER_NODE=`echo ${machine} | cut -c5-9 | tr "[:lower:]" "[:upper:]"`

case  ${machine} in
  lndvs330)  ENVIRONMENT=DEV  ; DB_SERVER='LDNEURDEV'       ; UKRR_HOME=/cm/ukrr_data/UKRR_tst;  INFA_DIR=informatica ;;
  lnpss130)  ENVIRONMENT=SIT  ; DB_SERVER='LDNEURDEV1_DS'   ; UKRR_HOME=/cm/ukrr_data/UKRR_tst;  INFA_DIR=informatica ;;  # LR SIT
  lnpss131)  ENVIRONMENT=UAT  ; DB_SERVER='LNPEUR1_TN_DS'   ; UKRR_HOME=/cm/ukrr_data/UKRR_uat;  INFA_DIR=informatica ;;  # LR UAT
  lnpss142)  ENVIRONMENT=UAT2 ; DB_SERVER='LDNEURUAT2_TN'   ; UKRR_HOME=/cm/ukrr_data/UKRR_uat2; INFA_DIR=informatica ;;  #  SLIM SIT / UAT
  lnpss146)  ENVIRONMENT=UAT3 ; DB_SERVER='LNUEUR1_DS'      ; UKRR_HOME=/cm/ukrr_data/UKRR_uat3; INFA_DIR=Informatica ;;  # NB: [I]nform. For T+2 // testing
  lnpss145)  ENVIRONMENT=UAT4 ; DB_SERVER='LNPEUR1_UAT3_DS' ; UKRR_HOME=/cm/ukrr_data/UKRR_uat4; INFA_DIR=informatica ;;  # EGB testing
  lnpss147)  ENVIRONMENT=UAT5 ; DB_SERVER='LNUEUR2_DS'      ; UKRR_HOME=/cm/ukrr_data/UKRR_uat5; INFA_DIR=informatica ;;  # SLIM conversion
  lntrs375)  ENVIRONMENT=PROD ; DB_SERVER='LNPEUR1_DS'      ; UKRR_HOME=/cm/ukrr_data/UKRR_tst;  INFA_DIR=informatica ;;
  lntrs189)  ENVIRONMENT=PROD ; DB_SERVER='LNPEUR1_DS'      ; UKRR_HOME=/cm/ukrr_data/UKRR_tst;  INFA_DIR=informatica ;;
esac

INFA_HOME=/home/pm5_2/${INFA_DIR}/PowerCenter8.6.1
SN=${DB_SERVER} ; DSQUERY=${DB_SERVER} ; export ENVIRONMENT DB_SERVER  SN DSQUERY UKRR_HOME INFA_HOME

#export INFA_HOME

PATH=$INFA_HOME/server/bin:~:$PATH:/bin:/usr/sbin:/usr/kerberos/bin:~ukrr_pm/scripts:$UKRR_HOME/run_sh/scripts:/usr/sybase; export PATH

#PATH=$INFA_HOME/server/bin:~:$PATH:/bin:/usr/sbin:~ukrr_pm/scripts:${UKRR_HOME}/run_sh/scripts:/usr/sybase  # changed to above rather for SIT purposes

LD_LIBRARY_PATH=/cm/opt_tools_redhatEL4-64bit/freetds/lib/:$INFA_HOME/server/bin:$LD_LIBRARY_PATH   ;   export LD_LIBRARY_PATH 
#LD_LIBRARY_PATH=$INFA_HOME/server/bin:$LD_LIBRARY_PATH   ;   export LD_LIBRARY_PATH # changed to above rather for SIT purposes

INFA_DEFAULT_DOMAIN=Domain_${ENVIRONMENT}                       
INFA_DEFAULT_DOMAIN_USER=admin                                  
INFA_DEFAULT_DOMAIN_PASSWORD=m64NsOyNNI2Lk6xkCuSkLw==           

INT_USER=ukrr_pm                                                
INT_PASS=Xrw0xz0SCo3GsNTXwCdx+Q==                               
INT_SRV=INT_SVC                                                 
INFA_SERVER_LOG=${INFA_HOME}/server/tomcat/logs/node.log        

export INFA_DEFAULT_DOMAIN INFA_DEFAULT_DOMAIN_USER INFA_DEFAULT_DOMAIN_PASSWORD INT_USER INT_PASS INT_SRV INFA_SERVER_LOG

export EMAIL='UKRR-support@rbccm.com'
export WEB_DIR=/cm/www_data/webroot/ukrr/logs
export ARCHIVE_DIR=/cm/ukrr_data

#Aliases
.  

echo "\nEnvironment setup:  env | egrep HOME|INFA|INT_|CMD|PATH|SYB|ENVIRONMENT|LDN|EUR :\n"  

env | egrep "HOME|INFA|INT_|CMD|PATH|SYB|ENVIRONMENT|LDN|EUR" | sort



###################################################################################################
# pm5_2@lnbrs115  :

LC_ALL=C;export LC_ALL

EDITOR=vi;export EDITOR

if [ -t 0 ]
then
        stty erase "^?" kill "" intr "" eof "" susp ""
#       stty erase "^?" kill "^U" intr "^C" eof "^D" susp "^Z"

fi

# . /usr/sybase/SYBASE.sh
# ORACLE_HOME=/opt/oracle/product/9.2.0; export ORACLE_HOME
# TNS_ADMIN=/opt/oracle/product/9.2.0/network/admin; export TNS_ADMIN

PATH=~/:$PATH:/usr/local/bin:/usr/sbin:/home/pm5_2/informatica/pm:~/scripts:/cm/ukrr_data/UKRR_tst/run_sh/scripts:/opt/sybase;export PATH

. /opt/sybase/SYBASE.sh
export DSQUERY=LDNEURBRP

LD_LIBRARY_PATH=/home/pm5_2/informatica/pm:$LD_LIBRARY_PATH; export LD_LIBRARY_PATH

export PM_PASSWORD=rep0s1t0ry

#UKRR_HOME=/home/UKRR_dev ;export UKRR_HOME
UKRR_HOME=/cm/ukrr_brp_data/UKRR_tst ;export UKRR_HOME
#UKRR_HOME=/home/UKRR ;export UKRR_HOME
export PMLOG=/home/pm5_2/informatica/pm/pmserver.log
export WEB_DIR=/cm/www_data/webroot/ukrr/logs
export ARCHIVE_DIR=/cm/ukrr_brp_data

CMDHOST=lnbrs115; export CMDHOST
CMDPORT=4001; export CMDPORT
CMDBATCH=UKRR_MART; export CMDBATCH

#PS1=$PS1' @ $PWD>'

#Aliases

. ~ukrr_pm/.alias

chmod 777 .envfile

##################################################################################################################################
# lndvs144  : 

umask 002
# CGP 12/07/2002 Add Environment Variables for Informatica
UKRR_HOME=/home/UKRR_tst ;export UKRR_HOME

LC_ALL=C;export LC_ALL

EDITOR=vi;export EDITOR

#if [ -t 0 ]
#then
#        stty erase " kill "" intr "" eof "" susp "
#fi

. /opt/sybase/SYBASE.sh
# export ORACLE_HOME=/opt/tools/oracle10g2/product/10.2.0
#:${ORACLE_HOME}/lib:${ORACLE_HOME}/lib32:$LD_LIBRARY_PATH

export INTERFACES=${SYBASE}/interfaces

#PATH=/home/pm5_2/informatica/powercenter7_1_5/repositoryserver:/home/pm5_2/informatica/powercenter7_1_5/server:~:$PATH:/usr/local/bin:/usr/sbin:~ukrr_pm/scripts:/cm/ukrr_data/UKRR_tst/run_sh/scripts:/usr/sybase;export PATH
PATH=/home/pm5_2/informatica/powercenter7_1_5/repositoryserver:/home/pm5_2/informatica/powercenter7_1_5/server:~:$PATH:/usr/local/bin:/usr/sbin:~ukrr_pm/scripts:/cm/ukrr_data/UKRR_tst/run_sh/scripts:/usr/sybase::${ORACLE_HOME}/bin
export PATH

DSQUERY=LDNEURDEV; export DSQUERY

#LD_LIBRARY_PATH=/home/pm5_2/informatica/pm:$LD_LIBRARY_PATH; export LD_LIBRARY_PATH
#LD_LIBRARY_PATH=/home/pm5_2/informatica/powercenter7_1_5/repositoryserver:/home/pm5_2/informatica/powercenter7_1_5/server:$LD_LIBRARY_PATH; export LD_LIBRARY_PATH
LD_LIBRARY_PATH=/home/pm5_2/informatica/powercenter7_1_5/repositoryserver:/home/pm5_2/informatica/powercenter7_1_5/server::${ORACLE_HOME}/lib:${ORACLE_HOME}/lib32:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH

ORACLE_HOME=/cm/opt_tools_solaris8/oracle92010/product/9.2.0
export ORACLE_HOME

#SYBASE=/opt/sybase; export SYBASE

export PM_HOME=/home/pm5_2/informatica/powercenter7_1_5/server
export PM_REPHOME=/home/pm5_2/informatica/powercenter7_1_5/repositoryserver
export PM_PASSWORD=rep0s1t0ry

CMDHOST=lndvs144;export CMDHOST

export PMLOG=/home/pm5_2/informatica/powercenter7_1_5/server/pmserver.log
export WEB_DIR=/cm/www_data/webroot/ukrr/logs
export ARCHIVE_DIR=/cm/ukrr_data

CMDPORT=4002; export CMDPORT
CMDBATCH=UKRR_MART; export CMDBATCH
# JAG 16/07/2002 Usability settings

uuu=`who am i | awk '{ print $1 } '`
machine=`uname -n`
#PS1=$uuu' on $PWD>'
#PS2="... and more>"

#Aliases

. ~ukrr_pm/.alias


##################################################################################################################################
# lndvs269v7 ukrr_pm .profile  : 

umask 002
# CGP 12/07/2002 Add Environment Variables for Informatica
UKRR_HOME=/home/UKRR_tst ;export UKRR_HOME

LC_ALL=C;export LC_ALL

EDITOR=vi;export EDITOR

#if [ -t 0 ]
#then
#        stty erase " kill "" intr "" eof "" susp "
#fi

# . /opt/sybase/SYBASE.sh
. /cm/opt_tools_solaris10/sybase125/SYBASE.sh
# export ORACLE_HOME=/opt/tools/oracle10g2/product/10.2.0
export INTERFACES=${SYBASE}/interfaces

#PATH=/home/pm5_2/informatica/powercenter7_1_5/repositoryserver:/home/pm5_2/informatica/powercenter7_1_5/server:~:$PATH:/usr/local/bin:/usr/sbin:~ukrr_pm/scripts:/cm/ukrr_data/UKRR_tst/run_sh/scripts:/usr/sybase;export PATH
PATH=/home/pm5_2/informatica/powercenter7_1_5/repositoryserver:/home/pm5_2/informatica/powercenter7_1_5/server:~:$PATH:/usr/local/bin:/usr/sbin:~ukrr_pm/scripts:/cm/ukrr_data/UKRR_tst/run_sh/scripts:/usr/sybase::${ORACLE_HOME}/bin
export PATH

DSQUERY=LDNEURDEV; export DSQUERY

#LD_LIBRARY_PATH=/home/pm5_2/informatica/pm:$LD_LIBRARY_PATH; export LD_LIBRARY_PATH
#LD_LIBRARY_PATH=/home/pm5_2/informatica/powercenter7_1_5/repositoryserver:/home/pm5_2/informatica/powercenter7_1_5/server:$LD_LIBRARY_PATH; export LD_LIBRARY_PATH
LD_LIBRARY_PATH=/home/pm5_2/informatica/powercenter7_1_5/repositoryserver:/home/pm5_2/informatica/powercenter7_1_5/server::${ORACLE_HOME}/lib:${ORACLE_HOME}/lib32:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH

ORACLE_HOME=/cm/opt_tools_solaris8/oracle92010/product/9.2.0
export ORACLE_HOME

#SYBASE=/opt/sybase; export SYBASE

export PM_HOME=/home/pm5_2/informatica/powercenter7_1_5/server
export PM_REPHOME=/home/pm5_2/informatica/powercenter7_1_5/repositoryserver
export PM_PASSWORD=rep0s1t0ry

CMDHOST=lndvs144;export CMDHOST

export PMLOG=/home/pm5_2/informatica/powercenter7_1_5/server/pmserver.log
export WEB_DIR=/cm/www_data/webroot/ukrr/logs
export ARCHIVE_DIR=/cm/ukrr_data

CMDPORT=4002; export CMDPORT
CMDBATCH=UKRR_MART; export CMDBATCH
# JAG 16/07/2002 Usability settings

# uuu=`who am i | awk '{ print $1 } '`
machine=`uname -n`
#PS1=$uuu' on $PWD>'
PS1=$PS1' @ $PWD>'
#PS2="... and more>"

#Aliases

. ~ukrr_pm/.alias


##################################################################################################################################
# lndvs330 ukrr_pm .profile  : 

umask 002
UKRR_HOME=/home/UKRR_tst ;export UKRR_HOME

LC_ALL=C;export LC_ALL

EDITOR=vi;export EDITOR

. /opt/sybase/SYBASE.sh
#. /cm/opt_tools_solaris10/sybase125/SYBASE.sh

INFA_HOME=/home/pm5_2/informatica/PowerCenter8.6.1  # /home/pm5_2/informatica/PowerCenter8.6.0_64
export INFA_HOME

PATH=$INFA_HOME/server/bin:~:$PATH:/bin:/usr/sbin:~ukrr_pm/scripts:/cm/ukrr_data/UKRR_tst/run_sh/scripts:/usr/sybase
export PATH

DSQUERY=LDNEURDEV; export DSQUERY
LD_LIBRARY_PATH=$INFA_HOME/server/bin:$LD_LIBRARY_PATH   ;   export LD_LIBRARY_PATH 
#:${ORACLE_HOME}/lib:${ORACLE_HOME}/lib32:$LD_LIBRARY_PATH

INFA_DEFAULT_DOMAIN=Domain_DEV                                  ; export INFA_DEFAULT_DOMAIN               
INFA_DEFAULT_DOMAIN_USER=admin                                  ; export INFA_DEFAULT_DOMAIN_USER          
INFA_DEFAULT_DOMAIN_PASSWORD=m64NsOyNNI2Lk6xkCuSkLw==           ; export INFA_DEFAULT_DOMAIN_PASSWORD      

INT_USER=ukrr_pm                                                ; export INT_USER                          
INT_PASS=Xrw0xz0SCo3GsNTXwCdx==                                 ; export INT_PASS                          
INFA_SERVER_LOG=${INFA_HOME}/server/tomcat/logs/node.log        ; export INFA_SERVER_LOG                   

# CMDHOST=lndvs144;export CMDHOST

export WEB_DIR=/cm/www_data/webroot/ukrr/logs
export ARCHIVE_DIR=/cm/ukrr_data

CMDPORT=4002; export CMDPORT
CMDBATCH=UKRR_MART; export CMDBATCH
machine=`uname -n`
PS1=$PS1' @ $PWD>'

#Aliases
. ~ukrr_pm/.alias

/*
# PATH=/home/pm5_2/informatica/powercenter7_1_5/repositoryserver:/home/pm5_2/informatica/powercenter7_1_5/server # :~:$PATH:/usr/local/bin:/usr/sbin:~ukrr_pm/scripts:/cm/ukrr_data/UKRR_tst/run_sh/scripts:/usr/sybase

# export INTERFACES=${SYBASE}/interfaces

# ORACLE_HOME=/cm/opt_tools_solaris8/oracle92010/product/9.2.0 ; export ORACLE_HOME
#SYBASE=/opt/sybase; export SYBASE

# export PM_HOME=/home/pm5_2/informatica/powercenter7_1_5/server
# export PM_REPHOME=/home/pm5_2/informatica/powercenter7_1_5/repositoryserver
# export PM_PASSWORD=rep0s1t0ry

# export PMLOG=/home/pm5_2/informatica/powercenter7_1_5/server/pmserver.log

*/

# vi  .envfile



###################################################################################################
# New user : 

cp /users/sosborne/.envfile   /users/jlomax/.envfile 

###################################################################################################
# /users/sybase/SYBASE.sh called from .profile

#!/bin/sh
SYBASE=/opt/sybase
export SYBASE
PATH=/opt/sybase/ASE-12_5/bin:/opt/sybase/OCS-12_5/bin:$PATH
export PATH
SHLIB_PATH=/opt/sybase/ASE-12_5/lib:/opt/sybase/OCS-12_5/lib:/usr/lib:/lib:/usr/lib/Motif1.2:$SHLIB_PATH
export SHLIB_PATH
SYBASE_OCS=OCS-12_5
export SYBASE_OCS
SYBASE_ASE=ASE-12_5
export SYBASE_ASE
LM_LICENSE_FILE=/opt/sybase/SYSAM-1_0/licenses/license.dat:$LM_LICENSE_FILE
export LM_LICENSE_FILE
SYBASE_SYSAM=SYSAM-1_0
export SYBASE_SYSAM

###################################################################################################
# ~ukrr_pm/SYBASE.sh called from .profile

#!/bin/sh
SYBASE=/opt/tools/sybase1254
export SYBASE
VERSION=12_5
export VERSION
PATH=${SYBASE}/ASE-${VERSION}/bin:${SYBASE}/OCS-${VERSION}/bin:$PATH
export PATH
SHLIB_PATH=${SYBASE}/ASE-${VERSION}/lib:${SYBASE}/OCS-${VERSION}/lib:/usr/lib:/lib:/usr/lib/Motif1.2:$SHLIB_PATH
export SHLIB_PATH
SYBASE_OCS=OCS-${VERSION}
export SYBASE_OCS
SYBASE_ASE=ASE-${VERSION}
export SYBASE_ASE
LM_LICENSE_FILE=${SYBASE}/SYSAM-1_0/licenses/license.dat:$LM_LICENSE_FILE
export LM_LICENSE_FILE
SYBASE_SYSAM=SYSAM-1_0
export SYBASE_SYSAM
LD_LIBRARY_PATH=${SYBASE}/OCS-${VERSION}/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH


###################################################################################################
#  - set up script alias environment for another user (ukkr_op OR sosborne) to share the ukrr_pm environment.

cd /users/sosborne/
#cd /users/ukrr_op

ln -s ~ukrr_pm/log log
ln -s ~ukrr_pm/log temp
# ln -s ~ukrr_pm/scripts scripts
ln -s ~ukrr_pm/data data

# These would work but don't as the permissions are -rwxr----- and the ukrr_op is in a different group (sup) to ukrr_pm - could put them in the same?
ln -s ~ukrr_pm/.un .un
ln -s ~ukrr_pm/.pw .pw
ln -s ~ukrr_pm/.sn .sn

uid=5011(ukrr_pm)   gid=511(ukrr_pm)
uid=6396(ukrr_op)   gid=240(sup)
uid=6160(sosborne)  gid=240(sup)
uid=5010(ukrr_data) gid=510(ukrr_data)

# for now, copy over .* files

cd ~ukrr_pm

chmod 744 .un .pw .sn .repo_pw  # this should be 740 if this user was in the same group

# rm .un .pw .sn .repo_pw

chmod 740 .un .pw .sn .repo_pw

chmod 766 `ls ~ukrr_pm/?*/?*.out` `ls ~ukrr_pm/?*/?*/?*.out` `ls ~ukrr_pm/?*/?*.tmp`

# block some scripts so only ukrr_pm can use them:
ll `ls ~ukrr_pm/?*/roll_back_*sh` 
chmod 754 `ls ~ukrr_pm/?*/roll_back_[sdf]*sh` 



###################################################################################################
# sosborne@lntrs189 : .profile

################################################################################
#
# RBC CM (London) korn shell profile
#
# 27/03/2004    -       Replaced all `hostname` instances with HOSTNAME,
#                       replaced all `whoami` instances with WHOAMI,
#                       used sudo in the path, HISTFILE admin,
#                       added -x xauth condition  - alexs
# 30/03/2004    -       Forced remove of HISTFILE's, alexs
# 31/03/2004    -       Set TZ for each OS, alexs
# 30/06/2004    -       Move the sup menu aliases above the focus call, as
#                       the focus profile includes a menu alias for the support
#                       team - Paul Murray.
# 25/07/2004    -       Added Robin alias for sup users - Paul Murray.
# 03/11/2004    -       Added passwd alias, alexs
# 16/02/2005    -       Added cpan alias, alexs
# 06/04/2005    -       Added CURRENTENVIRON to hightlight Prod, Dev or UAT.
#                       - Paul Murray
# 14/07/2005    -       Added suroot alias (CR:14514 - Paul Murray).
# 13/09/2005    -       Modified FOCUSHOST routine for BRP capability
#                       (CR:15519 - Paul Murray).
# 23/09/2005    -       Added suoracle, susybase, suingres and sumysql, alexs
#                       (CR:15778)
# 26/09/2005    -       Added suradmin, sumqm and sutekadmin, alexs (CR:15801)
# 28/09/2005    -       Added surbc, sufipricing, suautoex, sugcp, suinfinity,
#                       lsfadminuk, gcpstu alexs (CR:15859)
# 06/10/2005    -       Split the CTXSmf PATH settings so that the sbin
#                       tree is only assigned to root and ctxsrvr accounts.
#                       Paul Murray (CR:16078).
# 29/11/2005    -       Added suanvil alias (CR:17034 - Paul Murray).
# 20/03/2006    -       Remove /groups/all/bin from the PATH, alexs (CR:TBC)
#
################################################################################

# set -xv
umask 022

#  Remove any old history files and set new one
find . -prune -mtime +7 -name ".sh_history.*.*" -exec rm -f {} \;
HOSTNAME="`hostname`"
export HISTFILE=~/.sh_history.${HOSTNAME}.$$

# RBC and TIBCO defs
[ -f /etc/tss_sitedefs/def.sh ] && . /etc/tss_sitedefs/def.sh
[ -f /etc/rbc_sitedefs.sh ] && . /etc/rbc_sitedefs.sh

# Set up env variables
WHOAMI="`whoami`"
export ENV=$HOME/.envfile
export SYBASE_TERM=xterm_c.hp
export MANPATH=/usr/share/man:/usr/man:/usr/rbc/inf/local/man:/usr/contrib/man:/opt/tools/man:/usr/local/man:/usr/rbc/perl/man:/usr/dt/man:/opt/CTXSmf/man
export PATH=${PATH}:/usr/rbc/perl/bin:/usr/rbc/tcltk/bin:/usr/bin/X11:/usr/contrib/bin:/usr/contrib/bin/X11:/sbin:/usr/sbin:$SYBASE/bin:/usr/rbc/ra/bin:/cm/scripts/bin:/opt/tools/bin:/usr/local/bin:/opt/sudo/bin:/opt/CTXSmf/bin:/opt/CTXSmf/sbin
if [ "${WHOAMI}" = "root" -o "${WHOAMI}" = "ctxsrvr" ]
then
        PATH=${PATH}:/opt/CTXSmf/sbin
        export PATH
fi
export CVSROOT=:pserver:$LOGNAME@jaguar:/work/cvsroot
export EDITOR=`which vi`
export PAGER=`which more`
export UNAME=`uname -s`
export MAIL=/var/mail/$LOGNAME
export LANG=C
export USER=$LOGNAME

# For Infront (will go soon)
if [ "${HOSTNAME}" = "lntrs184" -o "${HOSTNAME}" = "lntrs185" ]; then
        export ORACLE_HOME=/opt/oracle7
        ##export ORACLE_HOME=/opt/oracle7/product/7.3.4
else
        export ORACLE_HOME=/disk2/apps/oracle7
fi
export TWO_TASK=lntrs223_HAM1.world
##export TWO_TASK=HAM1.ln


case ${UNAME} in
        Linux|SunOS)
                wherefrom()
                {
                        who -m | awk ' { printf "%s\n", $6 } ' | sed 's/[()]//g' | cut -d: -f1
                }
                ;;
        HP-UX)
                wherefrom()
                {
                        who am i -l | awk ' { printf "%s\n", $8 } ' | cut -d: -f1
                }
                ;;
esac

# Set timezone variable

case ${UNAME} in
        SunOS)
                ID=/usr/xpg4/bin/id
                export TZ="GB"
                ;;
        Linux)
                ID=/usr/bin/id
                export TZ="GB"
                ;;
        HP-UX)
                ID=/usr/bin/id
                export TZ="GMT0BST"
                ;;
esac

# Append . to the path if we're not root

[ `${ID} -u` != 0 ] && PATH=${PATH}:.

if [ -t 0 ]
then
        export HISTSIZE=500

        if [ "`tty`" = "/dev/console" ]
        then
                COLUMNS=120 LINES=49 TERM=300h
        fi

        if [ "${UNAME}" = "Linux" -o "${UNAME}" = "SunOS" ]
        then
                stty erase "^?" kill "^U" intr "^C" eof "^D" susp "^Z"
        else
                stty erase "^H" kill "^U" intr "^C" eof "^D" susp "^Z"
        fi

        if [ -z "${DISPLAY}" ]
        then

                # Try and get DISPLAY from rxvt if possible
                esc=`printf '\033'`
                stty -icanon -echo min 0 time 15
                printf "${esc}Z" # Ask for terminal ID
                read term_id
                if [ "x$term_id" = "x${esc}[?1;2c" ] # Looks like an rxvt
                then
                        printf "${esc}[7n" # Ask for display name
                        read DISPLAY
                        export DISPLAY
                        TERM=xterm
                        export TERM
                fi
                stty icanon echo

                if [ ! -z "$DISPLAY" ]
                then
                        echo "Got DISPLAY from rxvt: $DISPLAY"
                else
                        xconsole=`rwho -a | grep $LOGNAME | grep console | head -1 | cut -d':' -f1 | awk '{print $2}'`
                        if [ "x$xconsole" != "x" ]
                        then
                                export DISPLAY="${xconsole}:0"
                        else
                                export DISPLAY="`wherefrom`:0"
                        fi
                        echo >&2 "Warning: DISPLAY was not set, guessed $DISPLAY"
                fi
        fi

        if [ "${UNAME}" = "Linux" ]; then
                TERM=xterm-r5
        fi

        if [ -z "$TERM" ]
        then
                echo >&2 'Warning: TERM is not set'
        else
                case $TERM in
                        vt100|network|dumb|unknown)
                                echo >&2 "Warning: TERM is set to $TERM"
                                ;;
                esac
        fi

        export COLUMNS LINES TERM

        set -o vi
fi

# Give rbc authority to display to user
if [ ${DISPLAY} -a -x /usr/bin/X11/xauth ]
then
        if [ $LOGNAME != "rbc" ]
        then
                /usr/bin/X11/xauth extract - $DISPLAY 2>/dev/null | sudo -u rbc /usr/bin/X11/xauth -f /users/rbc/.Xauthority merge - > /dev/null 2>&1
                /usr/bin/X11/xauth extract - ${HOSTNAME}:0 2>/dev/null | sudo -u rbc /usr/bin/X11/xauth -f /users/rbc/.Xauthority merge - > /dev/null 2>&1
        fi
fi

prettyprint()
{
        enscript -2Gr -T4 -o - "$@" | lp
}

if [ -t 0 ]
then
        if [ "x$PREFERRED_SHELL" != "x" ]
        then
                NEWSHELL=`which $PREFERRED_SHELL`
                if [ "x$NEWSHELL" != "x" ]
                then
                        if [ "x$NEWSHELL" != "x$SHELL" ]
                        then
                                if [ -x $NEWSHELL ]
                                then
                                        exec $NEWSHELL
                                fi
                        fi
                fi
        fi
fi

unset IGNOREEOF

# Set printer default for certain users
if [ -f /cm/scripts/etc/set_default_printer ]
then
        . /cm/scripts/etc/set_default_printer
fi

echo "[You are using `basename ${SHELL}`]"

[ -t 0 -a "${HOSTNAME}" != "lntrs184" -a "${HOSTNAME}" != "lntrs185" ] && . /cm/scripts/etc/set_titlebar

# Set default Unix Shell Prompt

if [ "X${WHOAMI}" = "Xroot" ]
then
        PS1_EXT="#"
else
        PS1_EXT="$"
fi
PS1="${WHOAMI}@${HOSTNAME}.${PS1_EXT} "
export PS1

# Set Required Variable for Citrix Client

ICAROOT=/cm/scripts/ICAClient
export ICAROOT

# Set up CURRENTENVIRON variable

case ${HOSTNAME} in

        lndv*)          CURRENTENVIRON="DEV" ; export CURRENTENVIRON
                        ;;

        lnps*)          CURRENTENVIRON="UAT" ; export CURRENTENVIRON
                        ;;

        *)              CURRENTENVIRON="PROD" ; export CURRENTENVIRON
                        ;;

esac


# Set up and alias for the Helpdesk memu and sudo

HDGROUP=sup
if [ "x`groups | grep sup`" != "x" ]
then
        alias menu='sudo /cm/scripts/bin/rbcAdminMenu.ksh -h'
        alias admin='sudo /cm/scripts/bin/rbcAdminMenu.ksh'
        alias Robin='sudo /cm/BatMan/bin/Robin.ksh'

        # Add admin sudo alias

        case ${UNAME} in
                SunOS|HP-UX)
                        alias suroot='sudo /usr/bin/su - root'
                        alias susybase='sudo /usr/bin/su - sybase'
                        alias suoracle='sudo /usr/bin/su - oracle'
                        alias suingres='sudo /usr/bin/su - ingres'
                        alias sumysql='sudo /usr/bin/su - mysql'
                        alias sumqm='sudo /usr/bin/su - mqm'
                        alias suradmin='sudo /usr/bin/su - radmin'
                        alias sutekadmin='sudo /usr/bin/su - tekadmin'
                        alias sufipricing='sudo /usr/bin/su - fipricing'
                        alias suautoex='sudo /usr/bin/su - autoex'
                        alias surbc='sudo /usr/bin/su - rbc'
                        alias suinfinity='sudo /usr/bin/su - infinity'
                        alias sugcp='sudo /usr/bin/su - gcp'
                        alias sugcpstu='sudo /usr/bin/su - gcpstu'
                        alias sulsfadminuk='sudo /usr/bin/su - lsfadminuk'
                        alias suanvil='sudo /usr/bin/su - anvil'
                        ;;
                Linux)
                        alias suroot='sudo /bin/su - root'
                        alias susybase='sudo /bin/su - sybase'
                        alias suoracle='sudo /bin/su - oracle'
                        alias suingres='sudo /bin/su - ingres'
                        alias sumysql='sudo /bin/su - mysql'
                        alias sumqm='sudo /bin/su - mqm'
                        alias suradmin='sudo /bin/su - radmin'
                        alias sutekadmin='sudo /bin/su - tekadmin'
                        alias sufipricing='sudo /bin/su - fipricing'
                        alias suautoex='sudo /bin/su - autoex'
                        alias surbc='sudo /bin/su - rbc'
                        alias suinfinity='sudo /bin/su - infinity'
                        alias sugcp='sudo /bin/su - gcp'
                        alias sugcpstu='sudo /bin/su - gcpstu'
                        alias sulsfadminuk='sudo /bin/su - lsfadminuk'
                        alias suanvil='sudo /bin/su - anvil'
                        ;;
        esac
fi

if [ "${WHOAMI}" = "root" ]
then
        alias cpan='perl -MCPAN -e shell'
fi

# This is the passwd replacement program

alias passwd='/cm/scripts/bin/rbcPasswd.sh'

# Execute Focus Profile/Menu if Accessed via FOCUSHOST

FOCUSHOSTS="lnbrs159 lntrs161"
for FOCUSHOST in ${FOCUSHOSTS}
do
        if [ "${HOSTNAME}" = "${FOCUSHOST}" ]
        then
                if [ -x /cm/eur_data/bin/rbcEURProfile.ksh ]
                then
                        . /cm/eur_data/bin/rbcEURProfile.ksh
                fi
        fi
done

