#!/bin/bash
###################################################################
# Script   : ~/scripts/unix_tools.sh  // TOOLS_SCRIPT=${SCRIPTS_1}/unix_tools.sh // /users/q4wn5gc/scripts/unix_tools.sh 
# Purpose  : This script is a collection of misc useful functions for various ETL file operations. 
#          :   - Generally where the command is too long for a one line alias
# Usage    : 01) alias big='${TOOLS_SCRIPT} big                      '  
#          : 02) alias  ff='${TOOLS_SCRIPT} findfiles                '   
#          : 03) alias fif='${TOOLS_SCRIPT} find_text_in_files       '  
#          : 04) alias frc='${TOOLS_SCRIPT} file_and_row_count       '  
#          : 05) alias ffm='${TOOLS_SCRIPT} find_files_older_months  '  
#          : 06) alias dfm='${TOOLS_SCRIPT} delete_files_older_months'  
#          : 07) alias zfb='${TOOLS_SCRIPT} zip_local_files_bigger   '  
#          : 10) alias srv='${TOOLS_SCRIPT} server_info              '  
#          : 12) alias cft='${TOOLS_SCRIPT} copy_from_tmp            '  
#          : 14) alias dpw='${TOOLS_SCRIPT} daily_prod_workarounds   '  
#          : 15) alias att='${TOOLS_SCRIPT} attach                   '  
#          : alias tse='vi ${TOOLS_SCRIPT}'
# Modifications :
# Date         User               Description
#  -------------------------------------------------------------------------------------------
# 20/09/2012   Simon Osborne      Script created

###################################################################

FUNCTION=${1}
PARAM_1=${2}
PARAM_2=${3}
PARAM_3=${4}

if [ ! -d ${MY_HOME}/logs/ ] ; then mkdir -p ${MY_HOME}/logs/ ; chmod -R 777 ${MY_HOME}/logs/ 2>/dev/null ; fi
LOG_FILE=${MY_HOME}/logs/unix_tools_${FUNCTION}.log  ; > ${LOG_FILE} ; chmod 777 ${LOG_FILE} 2>/dev/null

DATA_DIR=${MY_HOME}/data/temp  # DATA_DIR=/tmp     # used by 10) download_latest_files and also FTP pull via: ftp_ETL_testing_extracts.cmd
if [ ! -d ${DATA_DIR} ] ; then mkdir -p ${DATA_DIR} ; chmod -R 777 ${DATA_DIR} ; fi

TEMP_DIR=/tmp    # used by 10) download_latest_files  
SAMPLE_ROWS=200  # used by 10) download_latest_files 

L_HELP_FMT="   %-25.25s : %s\n" # used by

typeset FUNCTION PARAM_1 MIN_HISTORY DATA_DIR TEMP_DIR LOG_FILE SAMPLE_SIZE

echo > ${LOG_FILE} ; date '+Run time: %Y-%m-%d at %H:%M:%S %Z' >> ${LOG_FILE} # ; echo >> ${LOG_FILE}

#### 01) function big ###############################################################

function big {

echo "\ndirectory usage :"
df -h .

echo  \\n"biggest sub-directories - all bigger than 500MB :"\\n
du -h  | egrep "^..G|^...G|^....G" | sort -nr | head -10 | sed -e 's/G/GB/g'
du -h  | egrep "^[5-9][0-9][0-9]M" | sort -nr | head -10 | sed -e 's/M/MB/g'

echo "\nbig files in sub-directories :"
ls -1Rs   | grep -v total  | grep -v ./   | grep ^[0-9][0-9][0-9][0-9][0-9][0-9] | sort -nr | head -20

echo "\n files bigger than 100MB in sub-directories :"
ls -lhSr `find ./?* -size +100000000c -print` | egrep " [1-9][0-9][0-9]M|G "
}  # end function


#### 02) function findfiles ###############################################################
function findfiles {

FILE_NAME_STRING=${PARAM_1}
FILE_AGE_MIN=${PARAM_2}

#Default FILE_NAME_STRING is *, else use ${PARAM_1} if this parameter is supplied.
if [[ -z ${PARAM_1} ]] ; then FILE_NAME_STRING="*"
    else    FILE_NAME_STRING=${PARAM_1} ; fi

#Default FILE_AGE_MIN is 9999999 (all time), else use ${PARAM_2} if this parameter is supplied.
if [[ -z ${PARAM_2} ]] ; then FILE_AGE_MIN=9999999
    else    FILE_AGE_MIN=${PARAM_2} ; fi

echo 'Usage       :  ff FILE_NAME_STRING [FILE_AGE_MIN] '    
echo "Usage actual:  fif ${FILE_NAME_STRING} // ${FILE_AGE_MIN} "    

ls -ld `find . -mmin -${FILE_AGE_MIN} -iname  "*${FILE_NAME_STRING}*"  -print 2>/dev/null`  | awk '{printf "%-60s %12s %10s %2s %5s \n", $9, $5, $6, $7, $8}'  > ${LOG_FILE}

echo  FILE COUNT : `cat ${LOG_FILE} | wc -l `
echo  FILE LIST  :\\n
cat ${LOG_FILE}

}  # end function

#### 03) function find_text_in_files ###############################################################
function find_text_in_files {

SEARCH_STRING=${PARAM_1}

#Default FILE_NAME_STRING is *, else use ${PARAM_2} if this parameter is supplied.
if [[ -z ${PARAM_2} ]] ; then FILE_NAME_STRING="*"
    else    FILE_NAME_STRING=${PARAM_2} ; fi

echo 'Usage       :  fif SEARCH_STRING    // FILE_NAME_STRING     '    
echo 'Usage eg    :  fif UKRR_tst .sh                             '    
echo "Usage actual:  fif ${SEARCH_STRING} // ${FILE_NAME_STRING} "    

egrep -i "${SEARCH_STRING}" `find . -name  "*${FILE_NAME_STRING}*"  -print ` 2>/dev/null

}  # end function
   
#### 05) function find_files_older_months ###############################################################

function find_files_older_months {

MONTH_AGE=${PARAM_1}
DAY_AGE=`expr ${MONTH_AGE} \* 30`

echo FUNCTION=${FUNCTION} // PARAM_1= ${PARAM_1} // MONTH_AGE=  ${MONTH_AGE} // DAY_AGE=  ${DAY_AGE}

find . \( -type d ! -name . -prune \) -o \( -mtime +${DAY_AGE} -exec ls -lrt {} \; \)  | awk '{printf "%-60s %12s %10s %2s %5s \n", $9, $5, $6, $7, $8}'  
}  # end function

#### 06) function delete_files_older_months ###############################################################

function delete_files_older_months {

MONTH_AGE=${PARAM_1}
DAY_AGE=`expr ${MONTH_AGE} \* 30`

find . \( -type d ! -name . -prune \) -o \( -mtime +${DAY_AGE} -exec ls -lrt {} \; \)  | awk '{printf "%-60s %12s %10s %2s %5s \n", $9, $5, $6, $7, $8}'  

echo  "\nTO DELETE the above files : \n"
read INPUT?"--> Press enter to CONTINUE or CTRL+c to ABORT ..."
find . \( -type d ! -name . -prune \) -o \( -mtime +${DAY_AGE} -exec rm -f {} \; \)  
}  # end function


#### 07) function zip_local_files_bigger ###############################################################

function zip_local_files_bigger {

SIZE_LIMIT=100M
echo FUNCTION=${FUNCTION} // PARAM_1= ${PARAM_1} // SIZE_LIMIT=  ${SIZE_LIMIT} 

find . \( -type d ! -name . -prune \) -o \( -size +${SIZE_LIMIT} -exec ls -lrt {} \; \)  | awk '{printf "%-60s %12s %10s %2s %5s \n", $9, $5, $6, $7, $8}'  

echo  "\nTO GZIP the above files : \n"
read INPUT?"--> Press enter to CONTINUE or CTRL+c to ABORT ..."
find . \( -type d ! -name . -prune \) -o \( -size +${SIZE_LIMIT} -exec gzip -f {} \; \)  
}  # end function


#### 10) function server_info ###############################################################
function server_info {

echo  "Server info - running:  uname -a // echo ${machine} // nslookup  ${machine} // isql -v \n"

uname -a   
echo ${machine}
nslookup  ${machine} 
isql -v

}  # end function


#### 15) function attach att ###############################################################
function attach {

FILE=${PARAM_1}
WHOAMI="`whoami`"

DISTR_LIST='simon.osborne@rbccm.com'
echo FUNCTION=${FUNCTION} // FILE= ${PARAM_1} // DISTR_LIST=  ${DISTR_LIST} 

cat ${FILE} | mailx -s "File contents included: ${FILE}" "${DISTR_LIST}"
# uuencode ${FILE} ${FILE} | mailx -s "File attached : ${FILE}" "${DISTR_LIST}"
# echo "File sent from Unix attach.sh command attached" | mutt -s "File attached : ${FILE}" -a ${FILE} "${DISTR_LIST}"    

}  # end function


#### function TEMPLATE ###############################################################
function TEMPLATE {

echo FUNCTION=${FUNCTION} // PARAM_1= ${PARAM_1} // SIZE_LIMIT=  ${SIZE_LIMIT} 
}  # end function

############################################################################
# Main - call the required function according to what input was supplied and display outputs and logs

echo "\nFUNCTION= ${FUNCTION} // PARAM_1_\$2= ${PARAM_1} // PARAM_2_\$3= ${PARAM_2} // LOG_FILE= ${LOG_FILE}" | tee -a ${LOG_FILE} 

case ${FUNCTION} in
        big                      )  big                         ;;  #  01) alias big   >> ${LOG_FILE}  
        findfiles                )  findfiles                   ;;  #  02) alias  ff                   
        find_text_in_files       )  find_text_in_files          ;;  #  03) alias fif   >> ${LOG_FILE}  
        # frc)  file_and_row_count  file_and_row_count          ;;  #  04) alias frc   >> ${LOG_FILE}  
        find_files_older_months  )  find_files_older_months     ;;  #  05) alias ffm   >> ${LOG_FILE}  
        delete_files_older_months)  delete_files_older_months   ;;  #  06) alias dfm                   
        zip_local_files_bigger   )  zip_local_files_bigger      ;;  #  07) alias zfb                   
        source_file_missing      )  source_file_missing         ;;  #  09) alias sfm   
        target_file_missing      )  target_file_missing         ;;  #  09b) alias tfm   
        server_info              )  server_info                 ;;  #  10) alias srv   >> ${LOG_FILE}  
        attach                   )  attach                      ;;  #  15) alias att   >> ${LOG_FILE}  
esac                                                           

cat ${LOG_FILE} | grep -v 'FUNCTION=' ;  echo










exit

/*

# OLD:

# spv
ENV_LIST_OLD="  \
D1|rbcSl1m      \
D2|irldevelop1  \
D3|irldevelop1  \
T1|t1sl1m       \
T2|t2sl1m       \
T3|t3sl1m       \
T4|t4sl1m       \
T5|t5sl1m       \
T6|T6sl1m       \
T7|T7sl1m       \
T8|T8sl1m       \
T9|T9sl1m       \
L1|T6sl1m       \
L2|T7sl1m       \
Q1|q1sl1m       \
Q2|q2sl1m       \
Q3|q2sl1m       "


# function check_new_NAS_files {

# echo -e "\n1) CDR_MONACO_YYYYMMDD.txt \n-  expected on 8.5 by 20121015 @ XXpm \n- /data/etl/NAS/BDR_RECON/Monaco/cmacs_book_recon/CDR_* :\n"
# ls -lrt /data/etl/NAS/BDR_RECON/Monaco/cmacs_book_recon/CDR_* | tail -10 
# echo -e "\n3) SLIM 8.5 target location for 8.5 Migration from 7.5 \n- expected to be mounted by 20121130 or so \n/data/etl/NAS/XAU0/ :\n"
# ls -lrt /data/etl/NAS/XAU0/  | tail -10 


# 1) CDR ADP_US .ok->.OK , 9am file
ls -1rt /data/etl/NAS/ZAS0/CDR_RECON/incoming/CDRRecon_ADPUS_2012*.ok | tail -1
for FILE in `ls -1rt /data/etl/NAS/ZAS0/CDR_RECON/incoming/CDRRecon_ADPUS_2012*.ok | tail -1` ; do 
   NEW_NAME=`echo ${FILE} | sed -e 's/ok/OK/g'` 
   mv ${FILE} ${NEW_NAME} ; echo ${FILE} ${NEW_NAME}
done

# 2) OPENLINK file DAILY workaround, 6pm file
ls -lrt /data/etl/NAS/OPENLINK/reports/YVO0_Books_Access_2012*csv | tail -5 ; sleep 5
cp `ls -1rt /data/etl/NAS/OPENLINK/reports/YVO0_Books_Access_2012*csv | tail -1` /data/etl/NAS/ZAS0/BDR_RECON/incoming/

sleep 3 
echo -e "\n...Now override Tidal ICI and OPENLINK, ADP US will run on it's own"
sleep 3 
echo -e '\n...Then run: esf "OPEN|YVO0|Adpus|ICI" 7'

# function check_new_NAS_files cnn :

echo  "\n2) BDR OPENLINK YVO0_Books_Access_YYYYMMDD.csv \n-  expected on 8.5 by 20120915 @ 18:00 \n- /data/etl/NAS/OPENLINK/reports/YVO0_Books_Access*  :\n"
ls -lrt /data/etl/NAS/OPENLINK/reports/YVO0_Books_Access* | tail -10 

echo  "\n4) OPICS 8.5 source location (Win) \n- can this be read from Tidal? \n/data/etl/NAS/BDR_RECON/OPICS/ :\n"
ls -lrt /data/etl/NAS/BDR_RECON/OPICS/  | tail -10 

echo  "\n5) SLIM 7.5 target location for OTIS2 5 \n- expected to be mounted by 20121130 or so \n/data/etl/NAS/XAU0/ :\n"
echo  "\n5) SLIM 7.5 target location for OTIS2 5 \n- expected to be mounted by 20121130 or so \n/data/etl/NAS/XAU0/ :\n"
# ls -lrt /data/etl/NAS/XTA0/  | tail -10 ls -lrt /data/etl/NAS/otis*  | tail -10
EXISTING_DIR=/data/etl/NAS/eDR/production/incoming/SLIM/
EXISTING_DIR_ARCHIVE=/data/etl/NAS/eDR/production/incoming/SLIM/archive
NEW_DIR=/data/etl/NAS/XTA0/PROD/incoming/RATES_INFINITY

for DIR in ${EXISTING_DIR} ${EXISTING_DIR} ${NEW_DIR}
do
   echo '##############################'
   ls -lrt ${DIR}/slim_cmit_dailypos_*csv* | tail 
done
echo '##############################'
ls -lrt /opt/bi/datasets/slim/SLIM_OTIS_*.txt  



