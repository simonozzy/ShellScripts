#!/bin/ksh
#************************************************************************************
#   NAME:          ~ukrr_pm/scripts/report_master.sh  
#   PURPOSE:       Master shell script that accepts up to five parameters and passes them
#                  on to various .sql scripts
#                  USAGE: report_master.sh REPORT [ FILE_TYPE | 'SCREEN' | 'EMAIL' ] [ DISTR_LIST ] [ SUBJECT ] [ BUSINESS_DATE | MONTH_END | QUARTER_END] [ DEBUG ]' 
#                  eg1):  report_master.sh  'test'  'csv' 'UKRR-support@rbccm.com' 'Test Report' 20081120 
#                  eg1):  report_master.sh  'REP_long_running_sessions' 'csv' "simon.osborne@rbccm.com" 
#                  alias rep='/home/ukrr_pm/scripts/report_master.sh'
#   PARAMATER LIST :
#   -------------------------------------------------------------------------------
#   ${1}  : Report name as used in naming of .sql,  output and log file.
#   ${2}  : File type /  extension eg 'csv' or 'xls'
#   ${3}  : Email distribution list eg. ''
#   ${4}  :  Email subject eg. 'Weekly ???? report'.  Note 'for  2006-03-22' will be appended in the actual subject.
#   ${5}  :  Run date parameter that is passed as $BUSINESS_DATE to the .sql file. If not suppllied, default of last business date (for reports run AFTER midnight).
#   
#   REVISIONS:
#   Ver        Date        Author           Description
#   ---------  ----------  ---------------  ------------------------------------
#   1.0        10/01/2007  S.Osborne        Script created.
# 
#*************************************************************************************/

# Declare variables :

. ~ukrr_pm/.profile

if [ $# -lt 3 ] ;
then
   echo;
   echo 'USAGE report_master.sh REPORT [ FILE_TYPE | 'SCREEN' ] [ DISTR_LIST ] [ SUBJECT ] [ BUSINESS_DATE ] [ DEBUG ]' ; 
   echo;
   exit 1;
fi

REPORT=`echo ${1} | cut -d'.' -f1`
FILE_TYPE=${2}
DISTR_LIST=${3} 

# DISTR_LIST=`echo "${DISTR_LIST}" | sed -e 's/\.com /\.com\, /g'`   # replaces ' ' with ', ' in email distros for mutt on linux

LOG_FILE=~/log/${REPORT}.log
>  ${LOG_FILE}
RDATE=`date "+%Y-%m-%d"`
# SENDER='UKRR-support@rbccm.com'
SENDER='UKRR.support@rbccm.com' 
TEMP_FILE=~/data/subs.tmp 
TEMP_SQL=~/scripts/sql/report_master.tmp.sql

DISTRO_LOOKUP=~ukrr_pm/data/reference/distro_lookup.txt
HAS_DISTRO=`grep -cw ${REPORT} ${DISTRO_LOOKUP}`

#  Check if this report has a pre-defined distribution list and if so then use it 

if [ ${HAS_DISTRO} -eq 1 ]
then
   DISTR_LIST=`grep -w ${REPORT} ${DISTRO_LOOKUP} | cut -d"|" -f2`
fi

# echo $HAS_DISTRO $DISTR_LIST

SN=${DB_SERVER} 
DB=ukrr_mart
UN=`cat ~/.un`
PW=`cat ~/.pw`

SQL_STRING="SELECT convert(char(8),max(calendar_date),112) FROM date_dimension WHERE calendar_date < convert(char(8), getdate(), 112) AND working_day_flag = 'Y' \ngo"
LAST_BUS_DAY=`echo "${SQL_STRING}" | isql -U${UN} -S${SN} -Dukrr_mart -b -P${PW} | grep -v affected  | sed -e 's/ //g'`

SQL_STRING="SELECT convert(char(8),max(calendar_date),112) FROM date_dimension WHERE calendar_date < convert(char(8), getdate(), 112) AND  last_day_of_month_flag = 'Y' \ngo"
LAST_ME_DAY=`echo "${SQL_STRING}" | isql -U${UN} -S${SN} -Dukrr_mart -b -P${PW} | grep -v affected  | sed -e 's/ //g'`

SQL_STRING="SELECT convert(char(8),max(calendar_date),112) FROM date_dimension WHERE calendar_date < '${LAST_ME_DAY}' AND working_day_of_month = 1 \ngo"
 MONTH_START_DAY=`echo "${SQL_STRING}" | isql -U${UN} -S${SN} -Dukrr_mart -b -P${PW} | grep -v affected  | sed -e 's/ //g'`

SQL_STRING="SELECT convert(char(8),max(calendar_date),112) FROM date_dimension WHERE calendar_date < convert(char(8), getdate(), 112) AND  last_day_of_quarter_flag = 'Y' \ngo"
QUARTER_END_DAY=`echo "${SQL_STRING}" | isql -U${UN} -S${SN} -Dukrr_mart -b -P${PW} | grep -v affected  | sed -e 's/ //g'`

SQL_STRING="SELECT convert(char(8),max(calendar_date),112) FROM date_dimension WHERE calendar_date < dateadd(DD,-75,'${QUARTER_END_DAY}') AND working_day_of_month = 1 \ngo"
QUARTER_START_DAY=`echo "${SQL_STRING}" | isql -U${UN} -S${SN} -Dukrr_mart -b -P${PW} | grep -v affected  | sed -e 's/ //g'`

SQL_STRING="SELECT working_day_of_month FROM date_dimension WHERE calendar_date = convert(char(8),  getdate(), 112) \ngo"
WORKING_DAY_OF_MONTH=`echo "${SQL_STRING}" | isql -U${UN} -S${SN} -Dukrr_mart -b -P${PW} | grep -v affected  | sed -e 's/ //g'`

# DAY_NO=`date '+%d'` WEEKDAY=`date '+%a'`

# Default RUN_DATE is ${LAST_BUS_DAY} otherwise use ${5} if it is supplied.
if [ -z ${5} ]
then
	RUN_DATE=${LAST_BUS_DAY}
else
	RUN_DATE=${5}
fi

echo 'Usage       :  report_master.sh REPORT // FILE_TYPE | "SCREEN" // [DISTR_LIST | 'FTP'] // [SUBJECT | 'FTP_USER'] // [RUN_DATE]'
echo 'Usage eg    :  report_master.sh   REP_long_running_sessions // csv //   UKRR-support@rbccm.com // "New Report" // MONTH_END '
echo "Usage actual:  report_master.sh ${1} // ${2} // ${3} // ${4} // ${5} "

# New as at Apr 2009: allow for reports only to be run at month end by supplying ${5} = 'MONTH_END' OR 'MONTH_END_4' : 
# This will allow month-end reports to be cronned as 0 7 1-3 * * report_master.sh ... 

# If its a scheduled MONTH_END report and it's not the first working_day then abort here:
# if [ ${5} = 'MONTH_END' ] && [ ${WEEKDAY} = 'Sat' -o ${WEEKDAY} = 'Sun' ] ; then

# if [ ${RUN_DATE} = 'MONTH_END' -a ${WORKING_DAY_OF_MONTH} -ne 1 ] ; then
if [   ${RUN_DATE} = 'MONTH_END' -o ${RUN_DATE} = 'QUARTER_END' ] && [ ${WORKING_DAY_OF_MONTH} -ne 1 ] ; then
#echo "It's a weekend day so aborting this MONTH_END only report here. "                                          >>  ${LOG_FILE}
   echo "Aborting this MONTH_END only report here as it's not the first working day of the month."  >>  ${LOG_FILE}
   # NB  NB TESTING : NB  NB  NB  NB  NB  NB  NB  NB  NB  NB  NB  NB  NB  NB  NB  NB  NB  NB  NB  NB  NB  NB  NB  NB  NB  NB  NB 
   # exit 1 
#  elif [ ${RUN_DATE} = 'MONTH_END' -a ${WEEKDAY} != 'Mon' -a ${DAY_NO} -ge 2 ] ; then
elif [   ${RUN_DATE} = 'MONTH_END_4' ] && [ ${WORKING_DAY_OF_MONTH} -eq 0 -o ${WORKING_DAY_OF_MONTH} -gt 4 ] ; then
   #echo "Aborting this MONTH_END only report here as it's a not a Monday and the date is greater than 2nd or 3rd."  >>  ${LOG_FILE}
   echo "Aborting this MONTH_END_4 only report here as it's not one of the first working four working days of the month."  >>  ${LOG_FILE}
   exit 1 
fi

# Default run date is last business date, otherwise use ${5} if it is supplied.

if   [ ${RUN_DATE} = 'MONTH_END' -o ${RUN_DATE} = 'MONTH_END_4' ] ; then
   BUSINESS_DATE=${LAST_ME_DAY} 
   START_DATE=${MONTH_START_DAY} 
elif [ ${RUN_DATE} = 'QUARTER_END'  ] ; then
   BUSINESS_DATE=${QUARTER_END_DAY}
   START_DATE=${QUARTER_START_DAY} 
else 
   BUSINESS_DATE=${RUN_DATE}
fi

# Default email SUBJECT is the name of the REPORT otherwise use ${4} if it is supplied.

if [ -z "${4}" ]
then
	SUBJECT="${REPORT} report for ${BUSINESS_DATE}"
else
	SUBJECT="${4}"
fi

if [ ${ENVIRONMENT} != PROD ] ; then SUBJECT="${SUBJECT} run on ${ENVIRONMENT}" ; fi

BODY="\n###########  THIS IS AN AUTOMATED MESSAGE ########### \
\n\nIt has been sent to you as you are a user of a report run on UKRR. \
\n\nShould you have any queries, please email +UK-UKRR-support@rbccm.com .  \
\n\nRegards \
\nUKRR Support "

# If its a csv or .xls file then set the seperator and ATTACHED flag too  :
if [ ${FILE_TYPE} = 'csv' ]   ;  then
   SEPERATOR=","
   ATTACHED=YES
elif [ ${FILE_TYPE} = 'xls' ]  ; then
    SEPERATOR="	"   # "tab" NB NB "TAB here" - check that text editor doesn't change to spaces...
    ATTACHED=YES
elif [ ${FILE_TYPE} = 'txt' ] ; then
   ATTACHED=YES
   SEPERATOR="	"   # "tab" NB NB "TAB here" - check that text editor doesn't change to spaces...
elif [ ${FILE_TYPE} = 'dat' ] ; then
   ATTACHED=YES
   SEPERATOR="|"   # "pipe" 
elif [ ${FILE_TYPE} = 'SCREEN' ] ; then
   ATTACHED=SCREEN
   FILE_TYPE=out
   SEPERATOR=" "   # "space" 
else
   ATTACHED=NO
   FILE_TYPE=out
   SEPERATOR=" "   # "space" 
fi

FILENAME=${REPORT}_${BUSINESS_DATE}.${FILE_TYPE}
OUTPUT=~/scripts/output/${FILENAME}

echo '       REPORT: '${REPORT};
echo 'BUSINESS_DATE: '${BUSINESS_DATE};
echo '   START_DATE: '${START_DATE};
echo '    FILE_TYPE: '${FILE_TYPE};
echo '    SEPERATOR: 'X-${SEPERATOR}-X;
echo '     FILENAME: '${FILENAME};
echo '       OUTPUT: '${OUTPUT};
echo '   DISTR_LIST: '${DISTR_LIST};

echo "\n Report begun at `date` \n" >>  ${LOG_FILE}

sed -e "s/BUSINESS_DATE/${BUSINESS_DATE}/g" -e "s/START_DATE/${START_DATE}/g"  ~/scripts/sql/${REPORT}.sql > ${TEMP_SQL}

isql -U${UN} -S${SN} -D${DB} -s "${SEPERATOR}" -i ${TEMP_SQL} -o ${OUTPUT} -w5000 -P${PW}  >>  ${LOG_FILE}

# If its a csv or .xls file then replace multiple spaces with one space, leading tab/comma with blank, and also remove the ------------- heading underliners :
# The leading tab/comma/pipe replacement assumes that the first column is NOT NULL which could be a problem in some cases.
if [ ${ATTACHED} = YES ]
then
   cat ${OUTPUT} | sed -e 's/  */ /g;s/^	//g;s/^,//g;s/^\|//g' >  ${TEMP_FILE}
	grep -v "\\-\\-\\-\\-\\-\\-\\-"  ${TEMP_FILE}  > ${OUTPUT}
fi
#rm -f ${TEMP_FILE}


# "if file too large ( > 6MB) then compress before emailing" :

FILE_SIZE=`ls -l ${OUTPUT} | awk '{print  $5 } '`
FILE_ROWCOUNT=`cat ${OUTPUT} | wc -l`

if [ ${FILE_SIZE} -gt 6000000 -a ${ATTACHED} = YES  -a "${DISTR_LIST}" != FTP ] 
then
   echo "file too large ( > 6MB) so compressing it before emailing" :
   echo "===================\n"
   gzip -f ${OUTPUT} 
   OUTPUT=${OUTPUT}.gz
   FILENAME=${FILENAME}.gz
fi

# "if file is too large for Excel and it's being FTPd ( > 64K lines ) then split before FTP'ing" :

if [ ${FILE_ROWCOUNT} -ge 64000 -a "${DISTR_LIST}" = FTP ]  
then
   echo "file is too large for Excel and it's being FTPd ( > 64K lines ) so splitting before FTP'ing" :
   echo "===================\n"
	cd ~/scripts/output/
   split -l 64000 -a 1 ${FILENAME} report_output_split. 
   head -1 report_output_split.a >  report_output_split.header
   for SUFFIX in a b c d e f g h i j
   do
      # Rename the split files and also copy the header row from the first file to the other files:
      if [ -f report_output_split.${SUFFIX} ]  ; then
         if [ ${SUFFIX} = a ]  ; then
            cat report_output_split.${SUFFIX}  > ${REPORT}_${BUSINESS_DATE}_${SUFFIX}.${FILE_TYPE}
         else
            cat report_output_split.header     >  ${REPORT}_${BUSINESS_DATE}_${SUFFIX}.${FILE_TYPE}
            cat report_output_split.${SUFFIX}  >> ${REPORT}_${BUSINESS_DATE}_${SUFFIX}.${FILE_TYPE}
         fi
      fi
   done
rm -f ${FILENAME} report_output_split.* 
fi

# Output to screen and email with output as attachment or in body depending on $ATTACHED which is automatically set by file type.
if [ ${ATTACHED} = SCREEN ]   ;  then
	cat  ${OUTPUT}
elif [ "${DISTR_LIST}" = FTP ] ; then   
	 cd ~/scripts/output/
    /home/ukrr_pm/scripts/FTP_wrapper.sh ${4} ${REPORT}_${BUSINESS_DATE}
elif [ ${ATTACHED} = YES  ] ; then   
	# uuencode ${OUTPUT} ${FILENAME} |  mailx -s "${SUBJECT}" -r "${SENDER}"  "${DISTR_LIST}" 
   #cp ${OUTPUT} ${FILENAME}
   echo ${BODY} | mutt  -s "${SUBJECT}" -a ${OUTPUT} "${DISTR_LIST}" 
else
	#cat  ${OUTPUT} | mailx -s "${SUBJECT}"  -r "${SENDER}"  "${DISTR_LIST}"
   cat  ${OUTPUT} | mutt -s "${SUBJECT}" "${DISTR_LIST}"
fi

echo "\n Report completed at `date`" >>  ${LOG_FILE}

