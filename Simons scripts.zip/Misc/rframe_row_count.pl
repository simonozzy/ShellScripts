#!/usr/bin/perl 
#/*********************************************************************************************
#  Name     : ~ukrr_pm/scripts/rframe_row_count.pl
#  Purpose  : Counts rows per record type and system in an rFrame extract file 
#  Usage    : rframe_row_count.pl
#           : alias rrc='rframe_row_count.pl'
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  01/05/2007   S Osborne       Created
#  16/09/2009   S Osborne       Added new logic to handle and count RT00 as opposed to just ignoring them for a more complete count
#*********************************************************************************************/

$in_file="${ARGV[0]}";     # Our input file.

$REC_TYPE = 0 ; $SYSTEM = 0 ; $SYSTEM_OUT = 0 ; $RUBBISH = 0 ; $REST = 0 ; 
$REC_CAT = 0 ; $REC_CAT_OUT = 0 ;  $SYSTEM_RT = 0 ; $TOT_RECORDS = 0 ; %TOT_RECORDS = () ; 

open(FILE, ${in_file});        

while(<FILE>)  {
chomp ;

   #if (substr($_,0,2) eq '00') {next ; }  ;
   if (substr($_,0,2) eq '00') {
   #         R_T   OTHER    SYSTEM  REST
   $FORMAT= 'Z2    Z1       Z1     Z200'  ;   ## Only RT = 00 is required, SYSTEM is forced to be 0000 later on.
   }
   elsif (substr($_,5,1) eq 'T')   {
   #         R_T   OTHER    SYSTEM  REST
   $FORMAT= 'Z2    Z4       Z4     Z200'  ;
   }
   else       {
   #         R_T   OTHER    SYSTEM  REST
   $FORMAT= 'Z2    Z3       Z4     Z200'  ;
   }

      { ($REC_TYPE, $RUBBISH, $SYSTEM, $REST)=unpack($FORMAT, $_ ) ; } 

      #$SYSTEM_OUT=$SYSTEM_RENAME{$SYSTEM} ;

      if ( $REC_TYPE eq '00' )      {    $SYSTEM_OUT='0000'  ; }   
      elsif ( $SYSTEM eq 'EBS:' ||  $SYSTEM eq 'EBS-' )   {    $SYSTEM_OUT='EBS_'  ; $REC_CAT=substr($REST,0,1)  ; }   
      else  { $SYSTEM_OUT=$SYSTEM ; $REC_CAT=substr($REST,1,1)  ; } 

      if   ( $REC_TYPE eq '00' )      {  $REC_CAT_OUT='CCY'  ; }   
      elsif ( $REC_CAT eq 'S'    )    {  $REC_CAT_OUT='POS'  ; }   
      elsif ( $REC_CAT eq 'T' )    {  $REC_CAT_OUT='TRD'  ; }   
      else  {  $REC_CAT_OUT='ACC'  ; }   

      $SYSTEM_RT=$SYSTEM_OUT."-".$REC_TYPE."-".$REC_CAT_OUT  ;
      $TOT_RECORDS{$SYSTEM_RT}++ ;
      # print "\n$REC_TYPE // $SYSTEM_OUT // $SYSTEM_RT" ;

   } 
close FILE ;

print "\nTotals Rows for each System-RT-TYPE :\n\n" ;

print  "Import file name\tSyst-RT-TYP\tRow Count\n" ;
print  "----------------\t-----------\t-----------\n" ;

foreach $System_RT (sort keys %TOT_RECORDS) 
   { 
#   print  "$System_RT\t\t$TOT_RECORDS{$System_RT}\n"  ;
    print  "${in_file}\t${System_RT}\t$TOT_RECORDS{$System_RT}\n"  ;
   }





exit


/*

# Hash array which maps system names starting with T to the name with the T in front - eg) TCCM -> CCMS - this allows the same subtring to be used for each record :
%SYSTEM_RENAME = (
'ANVL', 'ANVL',
'EBS-', 'EBS_',
'GNSY', 'GNSY',
'INFT', 'INFT',
'MIST', 'MIST',
'REGL', 'REGL',
'RIBS', 'RIBS',
'RIMS', 'RIMS',
'SWIT', 'SWIT',
'TANV', 'ANVL',
'TACB', 'ACBS',
'TCCM', 'CCMS',
'TEBS', 'EBS_',
'TGNS', 'GNSY',
'TNFT', 'INFT',
'TMIS', 'MIST',
'TRIB', 'RIBS',
'TRIM', 'RIMS',
'TSWI', 'SWIT'   ) ;
