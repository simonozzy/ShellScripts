#!/usr/bin/perl
#/*********************************************************************************************
#  Name     : $UKRR_HOME/ext/rfrm/rframe_entity_split.pl
#  Purpose  : Splits each rFrame output file into two parts by legal entity (EL/LTD) - looked up via operational_unit. 
#           : Called by  p_m_RFRM_MergeDaily.sh 
#  Usage    : rframe_entity_split.pl IN_FILE OUT_FILE_EL OUT_FILE_LTD 
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  11/06/2007   S Osborne       Created
#*********************************************************************************************/

# The input file which will be the list of all rFrame output record type files, provided by p_m_RFRM_MergeDaily.sh 
$in_file="${ARGV[0]}";     

# The output file names provided by p_m_RFRM_MergeDaily.sh  .
$output_el="${ARGV[1]}";   
$output_ltd="${ARGV[2]}";   

$output_other="$in_file.err" ;

$rec_type = ''     ;
$op_unit = ''      ;
$op_unit_num = 0   ;
$op_unit_length=8  ;
$entity = ''       ;
$other_1 = ''      ;
$other_2 = ''      ;
%entity_hash = ()  ;

# entity_operation_unit_lkp.prm is the output of a query on ukrr_mart..organisation_unit_dimension run by organisation_unit_load.sh each time organisation_unit_dimension is loaded.
$UKRR_HOME=$ENV{UKRR_HOME};
$entity_lkp="${UKRR_HOME}/src/parm/entity_operation_unit_lkp.prm" ;

# Creat a hash array from the above lookup:
open(ENTITY_LKP, $entity_lkp) || die "cannot open $entity_lkp $!";
while( <ENTITY_LKP> )
{
   chomp ;
   ($op_unit, $entity) = split(' ', $_) ;      
   $entity_hash{$op_unit} = $entity;           
}
close ENTITY_LKP;

# Hash array which maps record type to the starting position of the operational_unit field:
%rt_op_unit_posn = (
'01', 166,
'02', 185,
'03', 150,
'04', 125,
'05', 162,
'06', 198,
'08', 183,
'09', 189,
'10', 145,
'11', 109,
'12', 103,
'13', 82 ,
'14', 182,
'15', 132,
'16', 125     ) ;

# Open the input and output files
open(FILE, $in_file) || die "Cannot open input file $!\n";
open(RFRM_EL, ">> $output_el") || die "Cannot open new $output_el for append $!\n";       
open(RFRM_LTD, ">> $output_ltd") || die "Cannot open new $output_ltd for append $!\n";       

# Loop through each row of the input file :
while(<FILE>)  {
   chomp ;
   $rec_type=substr($_,0,2) ;
   $op_unit_posn=$rt_op_unit_posn{$rec_type} ;
   $op_unit = substr($_,$op_unit_posn-1,$op_unit_length) ;  #perl substr different to ksh in that start posn is the char ONE BEFORE the first to be selected
   $op_unit_num = $op_unit + 0 ;                            # Required to convert the 'char(8)' operational_unit field ( eg. '82676   ') to a number
   $entity = $entity_hash{$op_unit_num} ;
   
   # $op_unit_entity=$op_unit_num."-".$entity ; $hash_check{$op_unit_entity}++ ;
   
   # Split each rFrame output file into two parts (EL/LTD) by legal entity
   if ( $rec_type eq '00' ) {    # Print RT=00 in both files.
      print RFRM_EL "$_\n"   ;
      print RFRM_LTD "$_\n"   ;
   }
   elsif ( $entity eq  EL ) { 
      print RFRM_EL "$_\n"   ;
   }
   elsif ( $entity eq LTD ) { 
      print RFRM_LTD "$_\n"   ;
   }
   else {  # There shouldn't be any rows in here, this is just for fault finding
      open(RFRM_OTHER, ">> $output_other") || die "Cannot open new $output_other for append $!\n";       
      print RFRM_OTHER "$rec_type $op_unit $op_unit_num $entity END\n"   ;
      close RFRM_OTHER ;
   }

   }

close FILE ;
close RFRM_EL ;
close RFRM_LTD; 
