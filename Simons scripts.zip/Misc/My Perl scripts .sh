

############################################################################
# Perl cheat sheet : 

http://search.cpan.org/~nwclark/perl-5.8.8/pod/perlcheat.pod

# Perl cheat sheet :

  CONTEXTS  SIGILS             ARRAYS        HASHES
  void      $scalar   whole:   @array        %hash
  scalar    @array    slice:   @array[0, 2]  @hash{'a', 'b'}
  list      %hash     element: $array[0]     $hash{'a'}
            &sub
            *glob    SCALAR VALUES
                     number, string, reference, glob, undef
  REFERENCES
  \     references      $$foo[1]       aka $foo->[1]
  $@%&* dereference     $$foo{bar}     aka $foo->{bar}
  []    anon. arrayref  ${$$foo[1]}[2] aka $foo->[1]->[2]
  {}    anon. hashref   ${$$foo[1]}[2] aka $foo->[1][2]
  \()   list of refs
                          NUMBERS vs STRINGS  LINKS
  OPERATOR PRECEDENCE     =          =        perl.plover.com
  ->                      +          .        search.cpan.org
  ++ --                   == !=      eq ne         cpan.org
  **                      < > <= >=  lt gt le ge   pm.org
  ! ~ \ u+ u-             <=>        cmp           tpj.com
  =~ !~                                            perldoc.com
  * / % x                 SYNTAX
  + - .                   for    (LIST) { }, for (a;b;c) { }
  << >>                   while  ( ) { }, until ( ) { }
  named uops              if     ( ) { } elsif ( ) { } else { }
  < > <= >= lt gt le ge   unless ( ) { } elsif ( ) { } else { }
  == != <=> eq ne cmp     for equals foreach (ALWAYS)
  &
  | ^              REGEX METACHARS            REGEX MODIFIERS
  &&               ^     string begin         /i case insens.
  ||               $     str. end (before \n) /m line based ^$
  .. ...           +     one or more          /s . includes \n
  ?:               *     zero or more         /x ign. wh.space
  = += -= *= etc.  ?     zero or one          /g global
  , =>             {3,7} repeat in range
  list ops         ()    capture          REGEX CHARCLASSES
  not              (?:)  no capture       .  == [^\n]
  and              []    character class  \s == [\x20\f\t\r\n]
  or xor           |     alternation      \w == [A-Za-z0-9_]
                   \b    word boundary    \d == [0-9]
                   \z    string end       \S, \W and \D negate
  DO
  use strict;        DON'T            LINKS
  use warnings;      "$foo"           perl.com
  my $var;           $$variable_name  perlmonks.org
  open() or die $!;  `$userinput`     use.perl.org
  use Modules;       /$userinput/     perl.apache.org
                                      parrotcode.org
  FUNCTION RETURN LISTS
  stat      localtime    caller         SPECIAL VARIABLES
   0 dev    0 second     0 package      $_    default variable
   1 ino    1 minute     1 filename     $0    program name
   2 mode   2 hour       2 line         $/    input separator
   3 nlink  3 day        3 subroutine   $\    output separator
   4 uid    4 month-1    4 hasargs      $|    autoflush
   5 gid    5 year-1900  5 wantarray    $!    sys/libcall error
   6 rdev   6 weekday    6 evaltext     $@    eval error
   7 size   7 yearday    7 is_require   $$    process ID
   8 atime  8 is_dst     8 hints        $.    line number
   9 mtime               9 bitmask      @ARGV command line args
  10 ctime  just use                    @INC  include paths
  11 blksz  POSIX::      3..9 only      @_    subroutine args
  12 blcks  strftime!    with EXPR      %ENV  environment




##################################################################################################################################
# URLs  : 

# Handy email attach/send scipt
http://www.experts-exchange.com/Programming/Languages/Scripting/Perl/Q_22732048.html

# OSQL (ISQL?) scipt - need to learn this so Unix scripts can be used on Windows too.
http://msmvps.com/blogs/athif/archive/2006/05/10/94205.aspx

# Use Perl to connect to JDBC data sources - on Windows
http://openbase.wikidot.com/connectivity-apis:perl-dbi
http://search.cpan.org/~vizdom/DBD-JDBC-0.70/JDBC.pod

##################################################################################################################################
# perl shell use  : 

perl -ple "s/$/\t${FILE}/" 

# 4) Using a Perl loop, pre-process the file to change the number formats :
# This replaces "," with "", "(" with "-" and  ")" with "" ie. "(163,378,527.78)" becomes "-163378527.78" .
# These are global replace statements but only in the listed (numeric) column numbers, so commas or brackets in text columns will not be affected.  

/usr/bin/perl << EOF

open(FILE,"${COLLECT_FILE}_raw.dat") || die "Cannot open input file $!\n" ; 
open(OUTPUT,"> ${COLLECT_FILE}.dat") || die "Cannot open new file for append $!\n" ; 

while(<FILE>)  
{
   @F=split/\t/;
   s/,//g, s/\(/-/g, s/\)//g for @F[16,17,18,19,20,21,23,24,25,26,27,29];
   print OUTPUT join"\t",@F;
}

close FILE ;
close OUTPUT ;

EOF


############################################################################
# string search and replace scripts : 

https://stackoverflow.com/questions/2769876/how-do-i-perform-multiple-replacements-with-perl
#!/usr/bin/perl

use strict;
use warnings;

my $s =  "The+quick+brown+fox+jumps+over+the+lazy+dog+that+is+my+dog";

my %replace = (
    "+" => " ",
    dog => "cat",
);

$s =~ s/([+]|dog)/$replace{$1}/g;

print "$s\n";

###########
https://stackoverflow.com/questions/27369418/perl-replace-multiple-strings-simultaneously-case-insensitive
%replacements = ("what" => "its", "lovely" => "bad");
($val = $sentence) =~ s/(@{[join "|", keys %replacements]})/$replacements{$1}/g;

###########
https://stackoverflow.com/questions/16826865/perl-replace-multiple-strings-simultaneously
#! /usr/bin/env perl
use common::sense;

my $sentence = "hello world what a lovely day";

my %replace = (
  what => "it's",
  lovely => 'bad'
);

$sentence =~ s/(@{[join '|', map { quotemeta($_) } keys %replace]})/$replace{$1}/g;

say $sentence;


############################################################################
# Dup fix Perl scripts : 

head -20000 VCHRISSU000642-5JSAINSBURY.dat | cut -c2-12 | sort -u | sort -k1.5  >  account_sample.txt

>  temp\/duplicates.dat
>       temp\/correct.dat

for  card_id  in  `cat account_sample.txt`
do 
   grep  $card_id correct.dat  >>       temp\/correct.dat
   grep  $card_id duplicates.dat  >>  temp\/duplicates.dat
done

for card_id in `head -1000 account_sample.txt`
do 
   echo ""   ;  echo "-------------------------------------------------------------------------------------"   
   echo  $card_id ; echo ""   
   echo  "should have sent :"
   grep  $card_id  correct_vouchers_JS.dat 
   echo  ""   
   echo  " Did send 23-Dec : "
   grep  $card_id  VCHRISSU000642-5JSAINSBURY.dat
   echo  ""   
   echo  " Duplicates : "
   grep  $card_id  output.dat  #full_duplicates_to_remove.dat
done

for card_id in `cat account_sample.txt`
do 
DEC23=`grep  $card_id  VCHRISSU000642-5JSAINSBURY.dat | wc -l`
DUPS=`grep  $card_id  output.dat   | wc -l`
#echo  $card_id"   Sent 23/12 :  "$DEC23"   Duplicates   "$DUPS   >>  temp1.txt
echo  $card_id"    "$DEC23"    "$DUPS   >>  temp1.txt
done

&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

here is a simple way that should implement your task. one way it could be improved is not to read the entire contents of the duplicates file into a hash first. for 50,000 lines of short length, this shouldn't be so bad.. but if you experience performance issues, it could be addressed. if it's just for occasional use, the 5 seconds i anticipate it taking shouldn't be so bad.

( shoot. while the code worked.. i noticed just after the post that these two lines should be switched. reverse these two lines in the code. otherwise i seem to delete the $hash value before testing/printing it. or, you could just remove the test for 'ne ""', since it should ideally never equally that, i was just being safe.

if($hash{$_} == 1){ delete $hash{$_}; } else { $hash{$_}--; }
if($hash{$_} ne ""){ print output.txt  "$_\n"; }
)


#!/usr/bin/perl

# open two files for read, one for write
open(COR,"correct.dat ") || die "cannot open file: $!";
open(DUP,"duplicates.dat ") || die "cannot open file: $!";
open(OUT,">output.dat") || die "cannot open file: $!";

# foreach line of DUP
while(<DUP>){
chomp;

# test for empty line
next if /^\s*$/;

# increment hash value for line, keeping count
if($hash{$_} eq ""){ $hash{$_} = 1; } else { $hash{$_}++; }
}

# now, foreach line of COR, with our built hash for reference
while(<COR>)
{
   chomp;
   if(defined $hash{$_})
   {
      if($hash{$_} ne ""){ print OUT "$_\n"; }
      if($hash{$_} == 1){ delete $hash{$_}; } else { $hash{$_}--; }
      next;
   }
}

# close files
close(COR);
close(DUP);
close(OUT);

From Ozo :

#!/usr/bin/perl

open(COR,"correct.dat") || die "cannot open correct.dat $!";
while( <COR> )
{
   $hash{$_}++;
}
close COR;

open(DUP,"duplicates.dat") || die "cannot open duplicates.dat $!";
open(OUT,">output.dat") || die "cannot open output.dat $!";

while( <DUP> )
{
   next if $hash{$_}-- > 0;
   print OUT;
}
close(DUP);
close(OUT);


&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

Blinkie, I tested the script further and have not got  the results I expected :

> ls
FIX_DUPS.pl*  correct.dat

Make duplicates.dat  =  3 times  correct.dat

> cat correct.dat >> duplicates.dat
> cat correct.dat >> duplicates.dat
> cat correct.dat >> duplicates.dat

> wc -l *dat                       
    1076 correct.dat
    3228 duplicates.dat

> ./FIX_DUPS.pl 

> wc -l *dat   
    1076 correct.dat
    3228 duplicates.dat
    1076 output.dat

>>I would have expected that  the script would  have had  2152  output.dat 

######################

Also - this result is not as I expcted :

> wc -l *dat
    1076 correct.dat
       0 duplicates.dat

> cat correct.dat >> duplicates.dat

> ./FIX_DUPS.pl                    

> wc -l *dat                       
    1076 correct.dat
    1076 duplicates.dat
    1076 output.dat

>>I would have expected that  the script would have had 0 output.dat 

I have used the script exactly as you said with the lines swapped as you advised. I have alos tried sorting the files with no different result. Any ideas ? my email is  simon_osborne@onetel.net.uk  if you email me I can email you back some sample files to work with.

######################

Thanks,
Simon 



############################################################################

# Multi-points perl script 

#!/bin/perl -w

sub commify 
{
   local $_  = shift;
   1 while s/^([-+]?\d+)(\d{3})/$1,$2/;
   return $_;
}

$NQ_AMT =1000000000 ;
$NQ_AMT = sprintf( "%8.2f", $NQ_AMT/100 ) ;
$NQ_COUNT =10000 ;

#print  commify($NQ_COUNT), "\n" ;
print  "\t\t    NON_QUAL: \t", commify($NQ_COUNT), "\t\t", commify($NQ_AMT), "\n"  ;
#print  \t\t    NON_QUAL: \t, commify(${NQ_COUNT}), \t\t, commify(${NQ_AMT})\n ;

head -100000 PNTSACCL004895JSAINSBURY.dat  | grep ^D  >  $HOME/temp/test.txt

#!/bin/perl -w

# Parameters are : 1 = Filename to Process
#$in_file='C:\Perl\eg\multi' ;     # Our input file.

$in_file='/export/home/sosborne/temp/test.txt'  ;     
@excl_stores=qw (0911 0912 0940 0947 6001 6002 6003 6004 9114 9115 9116 9117 9118 9119 9120 9122 9123 9124 9125 9126 9127 9128) ;
$PTS = 0 ; $NQ_COUNT=0 ;  $NQ_AMT=0 ;  $NQ_PTS =0 ;  $QUAL_COUNT =0 ; $QUAL_AMT =0 ; $QUAL_PTS  =0 ;
$TOT_MULTI_COUNT  =0 ; $TOT_MULTI_PTS  =0 ;

# Setup the format to unpack the incoming PNTSACCL format.
#                   L_ID   SL_ID    OFFER  T_NO   LOC D_T  AMT  PTS   REST
$FORMAT= 'Z12    Z25       Z10         Z20      Z10   Z12   Z9    Z9      Z37'  ;

# Open the files we want to use :
open(FILE, ${in_file});        
open(NON_QUALIFIED, ">  ${in_file}_NON_QUAL.txt") || die "Cannot open new for append $!\n";       
open(QUALIFIED, "> ${in_file}_QUAL.txt") || die "Cannot open new for append $!\n";       
open(MULTI, "> ${in_file}_MULTI.txt") || die "Cannot open new for append $!\n";       

while(<FILE>)  
{
   chomp ;
   ($L_ID, $SL_ID, $OFFER, $T_NO, $LOC, $D_T, $AMT, $PTS, $REST)=unpack($FORMAT, $_ )  ;

   $ES=0.5*100*$PTS  ;
   $LOC_4=substr($LOC,0,4) ;

   # Exclusions : TYPE != BASE, SPEND < �26.00, STORE in (excl list), DATE outside period
   #print "$OFFER $AMT $LOC $ES   $TEST\n"   ;
   if   ($OFFER ne  "SSLBASE   "  ||  ($AMT <  2600)  ||  (grep /$LOC_4/ , @excl_stores) ||  ($ES < 100)  || ($D_T < 200304230000) ||  ($D_T >= 200305130000 )  )  
   {   # write record to Non qualifying record file :
      print NON_QUALIFIED  "${L_ID}${SL_ID}${OFFER}${T_NO}${LOC}${D_T}${AMT}${PTS}${REST}\n"  ;
      $NQ_COUNT ++ ;
      $NQ_AMT +=  $AMT ;
      $NQ_PTS +=  $PTS ;
   }  
   else  
   {   # write record to Qualifying record file
      print  QUALIFIED  "${L_ID}${SL_ID}${OFFER}${T_NO}${LOC}${D_T}${AMT}${PTS}${REST}\n"  ;

      $QUAL_COUNT ++ ;
      $QUAL_AMT +=  $AMT ;
      $QUAL_PTS +=  $PTS ;

      if ( ($AMT-$ES ) < 2500 )
      {  
         $MULTI_PTS=sprintf("%u", ($AMT-2500)/100)*2 ;
         $MULTI_PTS=sprintf "%09d", $MULTI_PTS ;
      } 
      else   { $MULTI_PTS=$PTS }  ;
      $T_NO=" " x 20  ;
      $LOC=" " x 10  ;
      $REST=" " x 37   ;

      print  MULTI  "${L_ID}${SL_ID}01B0000005${T_NO}${LOC}${D_T}00000000${MULTI_PTS}${REST}\n" ;

      $TOT_MULTI_COUNT ++ ;
      $TOT_MULTI_PTS +=  $MULTI_PTS ;
   } 

} # End of While Loop

close FILE ;
close NON_QUALIFIED ;
close QUALIFIED ;
close  MULTI ;

sub commify 
{
     local $_  = shift;
     1 while s/^([-+]?\d+)(\d{3})/$1,$2/;
     return $_;
}

${NQ_AMT} = sprintf( "%8.2f", $NQ_AMT/100 ) ;
${QUAL_AMT} = sprintf( "%8.2f", $QUAL_AMT/100 ) ;

print  "\t\t\t\tRECORDS\t\tSPEND\t\tPOINTS\n" ;
print  "\t\t    NON_QUAL:\t${NQ_COUNT}\t\t${NQ_AMT}\t${NQ_PTS}\n" ;
#print  "\t\t    NON_QUAL: \t", commify($NQ_COUNT), "\t\t", commify($NQ_AMT), "\n"  ;
print  "\t\t   QUALIFIED:\t${QUAL_COUNT}\t\t${QUAL_AMT}\t${QUAL_PTS}\n" ;
print  "\t\tMULTI-POINTS:\t${TOT_MULTI_COUNT}\t\t\t\t${TOT_MULTI_PTS}\n\n" ;


# &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
# Reporting only script - no file output
 
PNTSACCL004[6-9]??JSAINSBURY.dat

./test.sh  PNTSACCL0049[2-5]?JSAINSBURY.dat

./Multi.sh   PNTSACCL0052*JS*dat
 
PNTSACCL0049%JSAINSBURY

date
cd  /i02/informa/informatica/pc/INTERFACES/ARCHIVE
#cd   /i02/informa/informatica/pc/INTERFACES/SPONSORS/JSAINSBURY/INPUT
for FILE in  $1     #PNTSACCL004[6]??JSAINSBURY.dat
do
ls -l $FILE | awk ' {print  "File_Name =  ", $9, "   &   File_Date = ", $6, $7, $8, "\n"} '
/export/home/sosborne/temp/multi_rep.pl  $FILE 
done
date

./multi_rep.pl

PNTSACCL004890

cat PNTSACCL004893JSAINSBURY.dat  | grep ^D |  ./multi_rep.pl  

./multi_rep.pl PNTSACCL004896JSAINSBURY.dat

PNTSACCL004893JSAINSBURY.dat

#!/bin/perl 

#$in_file='/export/home/sosborne/temp/test.txt'  ;     
$in_file="${ARGV[0]}";     # Our input file.
#$in_file="/i02/informa/informatica/pc/INTERFACES/SPONSORS/JSAINSBURY/INPUT/${ARGV[0]}";     # Our input file.
@excl_stores=qw (0911 0912 0940 0947 6001 6002 6003 6004 9114 9115 9116 9117 9118 9119 9120 9122 9123 9124 9125 9126 9127 9128) ;
$PTS = 0 ; $ES= 0;$NQ_COUNT=0 ;  $NQ_AMT=0 ;  $NQ_PTS =0 ;  $QUAL_COUNT =0 ; $QUAL_AMT =0 ; $QUAL_PTS  =0 ;  $TOT_MULTI_COUNT  =0 ; $TOT_MULTI_PTS  =0 ; 

#                   L_ID   SL_ID    OFFER  T_NO   LOC D_T  AMT  PTS   REST
$FORMAT= 'Z12    Z25       Z10         Z20      Z10   Z12   Z9    Z9      Z37'  ;

open(FILE, ${in_file});        

while(<FILE>)  
{
   chomp ;
   ($L_ID, $SL_ID, $OFFER, $T_NO, $LOC, $D_T, $AMT, $PTS, $REST)=unpack($FORMAT, $_ )  ;
   if (substr($L_ID,0,1) ne 'D') {next ; }  ;

   $ES=0.5*100*$PTS  ;
   $LOC_4=substr($LOC,0,4) ;
   if   ($OFFER ne  "SSLBASE   "  ||  ($AMT <  2600)  ||  (grep /$LOC_4/ , @excl_stores) ||  ($ES < 100)  || ($D_T < 200304230000) ||  ($D_T >= 200305080000 )  )  
   {   
      #print NON_QUALIFIED  "${L_ID}${SL_ID}${OFFER}${T_NO}${LOC}${D_T}${AMT}${PTS}${REST}\n"  ;
      $NQ_COUNT ++ ;
      $NQ_AMT +=  $AMT ;
      $NQ_PTS +=  $PTS ;
   }  
   else  
   {   
      #print  QUALIFIED  "${L_ID}${SL_ID}${OFFER}${T_NO}${LOC}${D_T}${AMT}${PTS}${REST}\n"  ;

      $QUAL_COUNT ++ ;
      $QUAL_AMT +=  $AMT ;
      $QUAL_PTS +=  $PTS ;

      if ( ($AMT-$ES ) < 2500 )
      {  
         $MULTI_PTS=sprintf("%u", ($AMT-2500)/100)*2 ;
         $MULTI_PTS=sprintf "%09d", $MULTI_PTS ;
      } 
      else   { $MULTI_PTS=$PTS }  ;
         #print MULTI "${L_ID}${SL_ID}01B0000005${T_NO}${LOC}${D_T}00000000${MULTI_PTS}${REST}\n" ;
         $TOT_MULTI_COUNT ++ ;
         $TOT_MULTI_PTS +=  $MULTI_PTS ;
      } 

} 
close FILE ;

${NQ_AMT} = sprintf( "%8.2f", $NQ_AMT/100 ) ;
${QUAL_AMT} = sprintf( "%8.2f", $QUAL_AMT/100 ) ;

print  "\t\t\t\tRECORDS\t\tSPEND\t\tPOINTS\n" ;
#print  "\t\t    NON_QUAL: \t", commify($NQ_COUNT), "\t\t", commify($NQ_AMT), "\n"  ;
print  "\t\t    NON_QUAL:\t${NQ_COUNT}\t\t${NQ_AMT}\t${NQ_PTS}\n" ;
print  "\t\t   QUALIFIED:\t${QUAL_COUNT}\t\t${QUAL_AMT}\t${QUAL_PTS}\n" ;
print  "\t\tMULTI-POINTS:\t${TOT_MULTI_COUNT}\t\t\t\t${TOT_MULTI_PTS}\n\n" ;



Other file reports : &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

Multi pts :

PNTSACCL003868JSAINSBURY.dat.gz  to   3882

#for FILE in  PNTSACCL0038[6-8]*JSAINSBURY.dat.gz  ;  do
for FILE in  PNTSACCL0038[6-8]*JSAINSBURY*  ;  do
echo $FILE
grep  '01B0000005'   $FILE | wc -l
done


Sum points  for  a PNTSACCL error file 

cut -c113-121 | 

cat PNTSACCL0038[6-8]*JSAINSBURY*err |  grep  '01B0000005'  |  awk ' { indx_label =  substr($1,1,14)   }
                       {  total_points[indx_label] +=  substr($4,23,30) }
                       END { for (loop_label in total_points) { 
                       printf ("%-15s%10f\n" ,loop_label, total_points[loop_label] )
                                                        } }'    

OLD  : &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&


CARD              S1                     TYPE       S2  CODE       S3  STORE S4 DATE             SPEND       POINTS   REST
CA                   1                       TP             2   CD              3    ST        4    DA                 SP              PS            REST
A12                 A25                    A7            A3 A11            A9      A4   A6  A12                 A9              A9          A4   A1 A4A28
D61934680016                         SSLBASE   00211662982         0563      200304140135000003076000000060NYNN NS02                            


#!/bin/perl -w

# Parameters are : 1 = Filename to Process

$in_file=$ARGV[0];     # Our input file.
$HOME='/export/home/sosborne' ;

# Setup the format to unpack the incoming PNTSACCL format.
#                   CA    1    TP  2   CD   3 ST   4   DA SP PS REST
$FORMAT='A12 A25 A7 A3 A11 A9 A4 A6 A12 A9 A9 A4  A1 A4 A28'  ;

# Open the files we want to use :
open(FILE, ${in_file});        
open(NON_QUALIFIED, "> $HOME/temp/${in_file}.NON_QUAL") || die "Cannot open new for append $!\n";       
open(QUALIFIED, "> $HOME/temp/${in_file}.QUAL") || die "Cannot open new for append $!\n";       

while(<FILE>)  
{
   chomp ;
   ($CARD, $SP1, $TYPE, $SP2, $CODE, $SP3, $STORE, $SP4, $DATE, $SPEND, $POINTS, $REST)=unpack($FORMAT, $_ ) ;
   #print NEWFILE "A:$aB:$b\n";

   # Exclusions : TYPE != BASE, SPEND < �26.00, STORE in (excl list), DATE outside period
   print "$TYPE $SPEND \n"   ;
   if   ($TYPE ne  "SSLBASE"  ||  $SPEND <  2600  ||  grep $STORE, (0551, 0635)  ) 
   #||  DATE < XXXX  || DATE < XXXX
   {   #write record to Non qualifying record file :
      print NON_QUALIFIED "${CARD}${SP1}${TYPE}${SP2}${CODE}${SP3}${STORE}${SP4}${DATE}${SPEND}${POINTS}${REST}\n"  ;
   }  
   else  
   {   # write record to Qualifying record file
      print QUALIFIED "${CARD}${SP1}${TYPE}${SP2}${CODE}${SP3}${STORE}${SP4}${DATE}${SPEND}${POINTS}${REST}\n"  ;
   } 

} # End of While Loop

close FILE ;
close NON_QUALIFIED ;
close QUALIFIED ;

&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&


#!/ase/sybase/bccs/perl5/bin/perl

# Parameters are : 1 = Filename to Convert
#                  2 = First SEQ number to be used

$in_file=@ARGV[0];     # Our input file.
$SEQNO=@ARGV[1];  # This is our Start Seq number.

# Setup the format to unpack the ic_cdr format.
#           SC  1 EX  2 ANO  3 BNO  4 DS  5 TS  6 DE  7 TE  8 CA  9 IN 10 IM 11 ON 12 OM 13 CA 14 DU REST
$IC_FORMAT='A2 A1 A8 A1 A20 A1 A33 A1 A8 A1 A8 A1 A4 A1 A8 A1 A1 A1 A4 A1 A4 A1 A4 A1 A4 A1 A2 A1 A6 A52';    

# Open the files we want to use.
open(FILE, ${in_file});        
open(NEWFILE, ">> /ase/pl_cdr/TRANSFERING/${in_file}.conv") || die "Cannot open new for append $!\n";       

while (<FILE>) 
{
   chomp;
   ($SC, $SP1, $EXC, $SP2, $ANO, $SP3, $BNO, $SP4, $DATE, $SP5, $TIME, $SP6, $DATEEND, $SP7, $TIMEEND, $SP8, $CAUSE, $SP9, $ITGN, $SP10, $ITGM, $SP11, $OTGN, $SP12, $OTGM, $SP13, $Category, $SP14, $DUR, $REST) = unpack($IC_FORMAT, $_); 
   #print NEWFILE "A:$aB:$b\n";

   #Only process non zero durations.
   if ($DUR ne "000000") 
   {
      $THISSEQ=sprintf "%08s",$SEQNO;
      $INCOMING=sprintf "%-8s","${ITGN}I";
      $OUTGOING=sprintf "%-8s","${OTGN}O";
      $DATE6=substr($DATE,2,6);
      $TIME6=substr($TIME,0,6);

      #Set the Duration in HHMMSS from SSSSSS
      $t=$DUR;
      $s=$t % 60; $t=($t-$s)/60;
      $m=$t % 60; $t=($t-$m)/60;
      $h=$t % 24; #; $d=($t-$h)/24;
      $DUR_NEW=sprintf "%02d%02d%02d",$h,$m,$s;
      $ANO_NEW=sprintf "%-13s",substr($ANO,0,13);

      #Do some work on the B_no If the first char is not "0" then do not replace with 48
      if (substr($BNO,0,1) eq "0") 
      {
         $BNO_NEW="48".sprintf "%-26s",substr($BNO,1,26);
      }
      else
      {
         $BNO_NEW=sprintf "%-28s",$BNO;
      }

      $ANO_RATE=sprintf "%-18s",substr($ANO,0,18);
      $ANO_BILL=sprintf "%-18s",substr($ANO,0,18);
      $BNO_RATE=sprintf "%-20s",substr($BNO,0,20);
      $BNO_BILL=sprintf "%-20s",substr($BNO,0,20);

      print NEWFILE "247EX1 ${THISSEQ}025${DATE6}${TIME6}${DUR_NEW}004822${ANO_NEW}      ${BNO_NEW}${INCOMING}${OUTGOING} 48${ANO_RATE}48${ANO_BILL}0104 00${DUR} 000000${BNO_RATE}${BNO_BILL}  00                              001   \n";

      if (${SEQNO} == 99999999)
      {
         ${SEQNO}=0;
      }
      else
      {
         ${SEQNO}=${SEQNO}+1;
      } # End of SEQ no check loop
   } # The $DUR was not 000000

} # End of While Loop
close FILE;
close NEWFILE;



############################################################################

Batch file summary Perl scripts  :


&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

Reporting only script - no file output
 
./test.sh  PNTSACCL0049[2-5]?JSAINSBURY.dat

./Multi.sh   PNTSACCL0052*JS*dat
 
PNTSACCL0049%JSAINSBURY

date

head   -200 PNTSACCL005830JSAINSBURY.dat  > /export/home/sosborne/temp/PNTSACCL005830JSAINSBURY.test

br PNTSACCL005830JSAINSBURY.dat  
br RDMNTRCK002012JSAINSBURY.dat

br PNTSACCL000317BP.dat

head  -100 PNTSACCL000317BP.dat  > $HOME/tools/PNTSACCL000317BP.dat.sample

head  -100 PNTSACCL005951JSAINSBURY.dat  > $HOME/tools/PNTSACCL005951JSAINSBURY.dat.sample

br PNTSACCL005951JSAINSBURY.dat.sample

ls  PNTSA*BP*dat
ls  PNTSA*JS*dat


./br.pl    # batch report

#!/bin/perl 

#$in_file='PNTSACCL005830JSAINSBURY.test'  ;     
#$in_file='/export/home/sosborne/temp/PNTSACCL005830JSAINSBURY.test'  ;     
$in_file="${ARGV[0]}";     # Our input file.

$BATCH=substr($in_file,0,8) ;
$SEQ=substr($in_file,8,6) ;
$SPONSOR=substr($in_file,14,10) ;

print  "\n$BATCH$SEQ$SPONSOR:\n" ;

$TOT_TXNS = 0 ;  $AMT = 0 ; $TOT_AMT = 0 ; $PTS = 0 ; $TOT_PTS = 0 ; %PTS_DAY = () ; %TXNS_DAY = ()  ; %ACCOUNTS = ()  ; $L_ID = 0 ;  $D_T = 0 ; $COLUMNS = 0 ;
  
if ($BATCH eq PNTSACCL )    
{
   #                   L_ID   SL_ID    OFFER  T_NO   LOC D_T  AMT  PTS   REST
   $FORMAT= 'Z12    Z25       Z10         Z20      Z10   Z12   Z9    Z9      Z37'  ;
   #  Can't get this to work :
   #$COLUMNS = '$L_ID, $SL_ID, $OFFER, $T_NO, $LOC, $D_T, $AMT, $PTS, $REST' 
}
elsif ($BATCH eq RDMNTRCK) 

   #                   L_ID   D_T	  RD_ID LOC   RW_ID SIGN PTS    REST
   $FORMAT= 'Z12    Z12   Z10       Z10   Z10         Z1    Z8       Z30'  ;
}

open(FILE, ${in_file});        

while(<FILE>)  
{
   chomp ;

   if (substr($_,0,1) ne 'D') {next ; }  ;

   if ($BATCH eq PNTSACCL )
   { 
      ($L_ID, $SL_ID, $OFFER, $T_NO, $LOC, $D_T, $AMT, $PTS, $REST)=unpack($FORMAT, $_ ) ; 
   } 
   #{ ${COLUMNS} =unpack($FORMAT, $_ ) ; } 
   elsif ($BATCH eq RDMNTRCK)
   { 
      ($L_ID,$D_T,$RD_ID,$LOC,$RW_ID,$SIGN,$PTS,$REST)=unpack($FORMAT, $_ ) ; 
   } 

   #print "RECORDS :${L_ID}${SL_ID}${OFFER}${T_NO}${LOC}${D_T}${AMT}${PTS}${REST}\n"  ;
   $TOT_TXNS ++ ;
   #$TOT_AMT +=  $AMT ;
   $TOT_PTS +=  $PTS ;
   $ACCOUNTS{$L_ID}++;
   $PTS_DAY{substr($D_T,0,8)}  +=  $PTS ;
   $TXNS_DAY{substr($D_T,0,8)}++ ;
} 
close FILE ;

$TOT_ACCOUNTS = keys %ACCOUNTS ;
${TOT_AMT} = sprintf( "%8.2f", $TOT_AMT/100 ) ;

print "\nFile Totals :\n" ;

print  "\t\tTXNS\t\tACCOUNTS\tPOINTS\n" ;
print  "\t\t${TOT_TXNS }\t\t$TOT_ACCOUNTS\t\t${TOT_PTS}\n" ;

print "\nTotals Per Day:\n" ;

print  "\t\tDATE\t\tTXNS\tPOINTS\n" ;

foreach $date (sort keys %TXNS_DAY ) 
{ 
print  "\t\t$date\t$TXNS_DAY{$date}\t$PTS_DAY{$date}\n"  ;
}



brl  # location report :         &&&&&&&&&&&&&&&&&&&&&&&


#!/bin/perl 

$in_file="${ARGV[0]}";     # Our input file.

$BATCH=substr($in_file,0,8) ;
$SEQ=substr($in_file,8,6) ;
$SPONSOR=substr($in_file,14,10) ;

print  "\n$BATCH$SEQ$SPONSOR:\n" ;

$TOT_TXNS = 0 ;  $AMT = 0 ; $TOT_AMT = 0 ; $PTS = 0 ; $TOT_PTS = 0 ; %PTS_DAY = () ; %TXNS_DAY = ()  ; %ACCOUNTS = ()  ; $L_ID = 0 ;  $D_T = 0 ; $COLUMNS = 0 ;
  
if ($BATCH eq PNTSACCL)    
{
   #                   L_ID   SL_ID    OFFER  T_NO   LOC D_T  AMT  PTS   REST
   $FORMAT= 'Z12    Z25       Z10         Z20      Z10   Z12   Z9    Z9      Z37'  ;
}
elsif ($BATCH eq RDMNTRCK) 
{
   #                   L_ID   D_T	  RD_ID LOC   RW_ID SIGN PTS    REST
   $FORMAT= 'Z12    Z12   Z10       Z10   Z10         Z1    Z8       Z30'  ;
}

open(FILE, ${in_file});        

while(<FILE>)  
{
   chomp ;

   if (substr($_,0,1) ne 'D') {next ; }  ;

   if ($BATCH eq PNTSACCL )
   { 
      ($L_ID, $SL_ID, $OFFER, $T_NO, $LOC, $D_T, $AMT, $PTS, $REST)=unpack($FORMAT, $_ ) ; 
   } 

   elsif ($BATCH eq RDMNTRCK)
   { 
      ($L_ID,$D_T,$RD_ID,$LOC,$RW_ID,$SIGN,$PTS,$REST)=unpack($FORMAT, $_ ) ; 
   } 

   $LOC_TXNS{substr($LOC,0,5)}++ ;
   $LOC_PTS{substr($LOC,0,5)}  +=  $PTS ;
}
close FILE ;

print "\nTotals Per Store:\n" ;

print  "\t\tSTORE\tTXNS\tPOINTS\n" ;

foreach $store (sort keys %LOC_TXNS) 
{ 
print  "\t\t$store\t$LOC_TXNS{$store}\t$LOC_PTS{$store}\n"  ;
}

bre  # error code report :         &&&&&&&&&&&&&&&&&&&&&&&

#!/bin/perl 

$in_file="${ARGV[0]}";     # Our input file.

$BATCH=substr($in_file,0,8) ;
$SEQ=substr($in_file,8,6) ;
$SPONSOR=substr($in_file,14,10) ;

#print  "\n$BATCH$SEQ$SPONSOR:\n" ;
print  "\n$in_file:\n" ;

$ERR_CODE = 0 ; %TOT_RECORDS = () ;
  
#                   ERR_CODE   REST
$FORMAT= 'Z14    Z518'  ;

open(FILE, ${in_file});        

while(<FILE>)  
{
   chomp ;

   #if (substr($_,0,1) ne 'B') {next ; }  ;

   { ($ERR_CODE, $REST)=unpack($FORMAT, $_ ) ; } 

   $TOT_RECORDS{$ERR_CODE}++ ;
} 

close FILE ;

print "\nTotals Per Error code:\n" ;

print  "\t\tERR_CODE\tERRORS\n" ;

foreach $ERR_CODE (sort keys %TOT_RECORDS) 
{ 
print  "\t\t$ERR_CODE\t$TOT_RECORDS{$ERR_CODE}\n"  ;
}



&&&&&&&&&&&&&&&&&&&&&&&

for file in BTCHENRL0002[4-7]*err  ; do
bre $file  
done


&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

Shell script that calls on these .pl scripts :

br  PNTSA  BP 000315  

#!/bin/sh
## usage eg) :  br PNTSR JSAIN  00102  

UNZIPPED=`echo ${1}'*'${3}'*'${2}'*.dat'`
ZIPPED=`echo ${1}'*'${3}'*'${2}'*.dat.gz'`
INTERFACE_DIR='/i02/informa/informatica/pc/INTERFACES/'

for  DIR in  'ARCHIVE'  'TO_OFFLINE/JSAINSBURY'  'TO_OFFLINE/BP'  'TO_OFFLINE/BARCLAYCRD' 'TO_OFFLINE/DEBENHAMSR' 'TO_OFFLINE/ECLIPSE' 'TO_OFFLINE/HOWARDHUNT'  
do
   cd  ${INTERFACE_DIR}${DIR}
   FILE_COUNT=`ls -1 $ZIPPED 2>/dev/null | wc -l`    
   if  [ $FILE_COUNT  !=  0  ]  ; then   
      FIRST=`ls -l $ZIPPED | head -1 | cut -c42-100` 
      LAST=`ls -l $ZIPPED | tail -1 | cut -c42-100` 
      #echo ""  ; echo $DIR"  : From : "$FIRST"  -to-  "$LAST ; echo ""
      for file in  $ZIPPED
      do
         ls -l $file | awk '{print "File_Date = ", $6, $7,  $8 ," &   File_Name =  ", $9 }'
         gzcat $file  > /tmp/$file
         cd  /tmp
         br.pl $file 
         #brl.pl $file 
         rm /tmp/$file 
         echo ''
      done
   fi
done

DIR=ARCHIVE
cd  ${INTERFACE_DIR}${DIR}

FILE_COUNT=`ls -1 $UNZIPPED 2>/dev/null | wc -l`    
if  [ $FILE_COUNT  !=  0  ]  ; then   
   FIRST=`ls -l $UNZIPPED | head -1 | cut -c42-100` 
   LAST=`ls -l $UNZIPPED | tail -1 | cut -c42-100` 
   #echo ""  ; echo $DIR"  : From : "$FIRST"  -to-  "$LAST ; echo ""
   for file in  $UNZIPPED
   do
      ls -l $file | awk '{print "File_Date = ", $6, $7,  $8 ," &   File_Name =  ", $9 }'
      br.pl $file 
      #brl.pl $file 
      echo ''
   done
fi


&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

RDMNTRCK

#                   L_ID   D_T	  RD_ID LOC  RW_ID SIGN PTS    REST
$FORMAT= 'Z12    Z12   Z10      Z10    Z10       Z1      Z8            Z30'  ;
12                       12                    10                     10           10                 1 8
D57468967019 200307011654 SSLELECRDT 0040       0000000000 0 00000500


PNTSACCL 

#                   L_ID   SL_ID    OFFER  T_NO   LOC D_T  AMT  PTS   REST
$FORMAT= 'Z12    Z25       Z10         Z20      Z10   Z12   Z9    Z9      Z37'  ;


SSL :D50782056015                         SSLBASE   48083000247         0076      200307040703000001000000000020YNNN NS02
BP :D51257094010                         04A0F00002020001              10138     200307071348         000000026      S000000000000000



##################################################################################################################################
# PUM Perl script : 

cat accounts.txt   | sed -e   's/,SE//g' >   accounts1.txt
mv  accounts1.txt  accounts.txt

cd  /i02/informa/informatica/pc/INTERFACES/BATCHES/B_QRTRUPDT/NODE1/WORK_4May/WORK

#!/bin/perl -w

$in_file="${ARGV[0]}";     # Our input file.
#$in_file="/export/home/sosborne/output.txt";   

open(FILE, ${in_file});        
open(LIST, "/export/home/sosborne/accounts.txt") || die "Cannot open new for append $!\n";       
open(OUTPUT, ">  ${in_file}_OUT.txt") || die "Cannot open new for append $!\n";       

while( <LIST> ) 
{
chomp ;
$hash{$_}++;
}
close  LIST ;

#                   F1       F2         F3
#$FORMAT= 'Z390    Z1       Z50' ;

while(<FILE>)  
{
   chomp ;
   if (substr($_,0,1) ne 'D') 
   {
      print  OUTPUT  "$_\n"  ;
   }  
   else 
   {
      $ACCOUNT_NO=substr($_,9,8)  ;
      if  (defined $hash{$ACCOUNT_NO} ) 
      {
         ($F1, $F2, $F3)=unpack('Z390 Z1 Z50', $_ )  ;
         print  OUTPUT "${F1}D${F3}\n"  ;
      }
      else {print  OUTPUT "$_\n" }  ;
   }  

} 
close FILE ;
close OUTPUT ;

#  &&  ($F2 eq 'Y' ) )

&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

#!/usr/bin/perl

open(COR,"correct.dat") || die "cannot open correct.dat $!";
while( <COR> )
{
   $hash{$_}++;
}
close COR;

open(DUP,"duplicates.dat") || die "cannot open duplicates.dat $!";
open(OUT,">output.dat") || die "cannot open output.dat $!";

while( <DUP> )
{
   next if $hash{$_}-- > 0;
   print OUT;
}

close(DUP);
close(OUT);

&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&


#!/usr/bin/perl

$in_file="${ARGV[0]}";     # Our input file.

open(FILE, ${in_file});        
open(LIST, "/export/home/sosborne/accounts.txt") || die "Cannot open new for append $!\n";       
open(OUTPUT, ">  ${in_file}_OUT.txt") || die "Cannot open new for append $!\n";       

while( <LIST> ) 
{
   $hash{$_}++;
}
close  LIST ;

#                   F1       F2         F3
#$FORMAT= 'Z390    Z1       Z50' ;

while(<FILE>)  
{
   chomp ;
   if (substr($_,0,1) ne 'D') 
   {
      print  OUTPUT  "$_\n"  ;
   }  
   else 
   {
         $ACCOUNT_NO=substr($_,9,8)  ;
         print   "$ACCOUNT_NO:$hash{$ACCOUNT_NO}\n" ;
         if  (defined $hash{$ACCOUNT_NO} ) 
         {
            ($F1, $F2, $F3)=unpack('Z390 Z1 Z50', $_ )  ;
            print  OUTPUT "${F1}D${F3}\n"  ;
            print  'defined :' , "$ACCOUNT_NO\n" ;
         }
         else 
         {
            print  OUTPUT "$_\n"  ;
            print  'not defined :' , "$ACCOUNT_NO:\n" ;
         }  ;
   }  

} 
close FILE ;
close OUTPUT ;



#!/bin/perl 

open(LIST, "/export/home/sosborne/accounts.txt") || die "Cannot open new for append $!\n";       

while( <LIST> ) 
{
   $hash{$_}++;
}
close  LIST ;

$i=0;
foreach  $ACCOUNT_NO(sort  keys %hash) 
{  
   if ( $i <=10) 
   {
      #print   "$ACCOUNT_NO :  $hash{$ACCOUNT_NO}\n" 
      #print  defined $hash{$ACCOUNT_NO} 
      if  (defined $hash{$ACCOUNT_NO} ) 
      { print  "defined  $ACCOUNT_NO\n"  } 
   } ;
   $i++ ;

}



Script I did 4/7 to find accounts from Intellidata error files :


#!/bin/perl -w

$in_file="${ARGV[0]}";     # Our input file.
#$in_file="/export/home/sosborne/output.txt";   

open(FILE, ${in_file});        
open(LIST, "accounts.txt") || die "Cannot open new for append $!\n";       
open(OUTPUT, ">  ${in_file}_OUT.txt") || die "Cannot open new for append $!\n";       

while( <LIST> ) 
{
   chomp ;
   $hash{$_}++;
}
close  LIST ;

while(<FILE>)  
{
   chomp ;
   $ACCOUNT_NO=substr($_,1,11)  ;
   if  (defined $hash{$ACCOUNT_NO} ) 
      {
      print  OUTPUT "$_\n"  ;
      }
  
} 
close FILE ;
close OUTPUT ;



##################################################################################################################################
# RBC IGCP profile collect pre-processing : 

#!/usr/bin/perl

open(FILE,"/home/UKRR_tst/src/igcp/test.dat") || die "Cannot open input file $!\n" ; 
open(OUTPUT,"> /home/ukrr_pm/scripts/test_out.dat") || die "Cannot open new file for append $!\n" ; 

# @arr = <FILE>;
# foreach $i (@arr){
while(<FILE>)  {
    chomp ;
    @arr = split('',$_);
    foreach $j (@arr) {
        if($j =~ /^\d+.*$/)
        {
            if( $j =~ s/,//)
            {
                $out = $j;
                #print "1.$out\n";
                print OUTPUT "$j"; 
            }
        }
        else
        {
            $out = $j;
            #print "2.$out\n";
            print OUTPUT "$j";
        }
    }
    print OUTPUT "\n";
}

close FILE ;
close OUTPUT ;




##################################################################################################################################
# RBC rframe_row_count.pl : 

#!/usr/bin/perl
#/*********************************************************************************************
#  Name     : ~ukrr_pm/scripts/rframe_row_count.pl
#  Purpose  : Counts rows per record type and system in an rFrame extract file
#  Usage    : rframe_row_count.pl
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  01/05/2007   S Osborne       Created
#*********************************************************************************************/

$in_file="${ARGV[0]}";     # Our input file.

$TOT_RECORDS = 0 ; $REC_TYPE = 0 ; $SYSTEM = 0 ; $SYSTEM_RT = 0 ; $RUBBISH = 0 ; $REST = 0 ;  %TOT_RECORDS = () ;

open(FILE, ${in_file});

while(<FILE>)  {
chomp ;

   if (substr($_,0,2) eq '00') {next ; }  ;

   if (substr($_,0,2) ne '00')   {
   #         R_T   OTHER    SYSTEM  REST
   $FORMAT= 'Z2    Z3       Z4     Z200'  ;
   }
   else       {
   #         R_T   OTHER    SYSTEM  REST
   $FORMAT= 'Z2    Z4       Z4     Z200'  ;
   }

      { ($REC_TYPE, $RUBBISH, $SYSTEM, $REST)=unpack($FORMAT, $_ ) ; }

      $SYSTEM_RT=$SYSTEM."-".$REC_TYPE ;

      # print "\n$REC_TYPE // $SYSTEM // $SYSTEM_RT" ;


      $TOT_RECORDS{$SYSTEM_RT}++ ;

   }
close FILE ;

print "\nTotals Rows for each System-RT :\n" ;

print  "\t\tSystem_RT\tROWS\n" ;

foreach $System_RT (sort keys %TOT_RECORDS)
   {
   print  "\t\t$System_RT\t$TOT_RECORDS{$System_RT}\n"  ;
   }





##################################################################################################################################
# Perl system() command testing of mutt to send notification emails  : 

# ~ukrr_pm/scripts/test.pl

#!/usr/bin/perl -w

$taskname="b_TEST_Collect" ;    
$distro_failure="simon.osborne\@rbccm.com, simon.osborne\@rbccm.com" ;
# $distro_failure="GlobalOps&FinanceSupport@rbccm.com, UKRR.support@rbccm.com" ;
$failed_msg="\n#### Automated message sent by the UKRR scheduler when a Batch job (Informatica workflow) fails #### \n\nDepending on the downstream impact, contact on-call support.\n" ;

# 

if($taskname ne "b_CollectRIMS_WK")
{
   system("echo '$failed_msg' | mutt -s 'UKRR Process failure: $taskname' '$distro_failure' ");
}




##################################################################################################################################
# Perl hash array - sort by value - for UKRR scheduler:

How To Sort Array of Hashes ??
Some one plz help me how to sort an array of hashes .....

for e.g i have an array as

@AoH = (
{
ques => 10,
marks => 32,
},
{
ques => 32,
marks => 22,
},
{
ques => 2,
marks => 41,
},
);

now i want to sort this array with increasing value of "ques" ..... plz help

@sorted = sort { $$a{'ques'} <=> $$b{'ques'} } @AoH;

@sorted = sort { $hash{$a} cmp $hash{$b} } keys %hash; 

##################################################################################################################################
# Perl hash array - sort by value - for UKRR scheduler:

#!/usr/bin/perl -w
use DBI;

use strict;

sub connect_db
{
	return DBI->connect("dbi:Sybase:server=$sybase_server;database=$sybase_db",
			$sybase_user,
			$sybase_pass,
			{PrintError => 1, RaiseError => 0, AutoCommit => 1});
}

			my $db = connect_db();

				my $query = $sqldep->{query};
					my $q = $db->prepare($query);

				my $result;

				if(defined($db))
				{
					my $q = $db->prepare($query);
					if(defined($q))
					{
						if($q->execute())
						{
							my $row=$q->fetchrow_arrayref();
							if(defined($row))
							{
								$result = $row->[0];
								$q->finish();
							}
						}
					}
				}

					defined($db) && $db->disconnect();




# Perl script to merge RIMMS TOR + LON + NY files :
 # will likely do this in Tidal now as the trailing Region column is already there.

use warnings;
use strict;

#$in_date=$ARGV[0];     # Our input date.
$in_date="20140219";     # Our input file.

$RIMMS_EBS_DATED="CDRRecon_RIMMS_$in_date.TXT"
#$RIMMS_LON_DATED="CDRRecon_RIMMS_$in_date.TXT"
#$RIMMS_TOR_DATED=
#$RIMMS_NY_DATED=

open   RIMMS_EBS, '<', "$RIMMS_EBS_DATED" or die "Can't open RIMMS_EBS: $!";
#open   RIMMS_LON, '<', "$RIMMS_LON_DATED" or die "Can't open RIMMS_LON: $!";
#open  RIMMS_TOR, '<', "$RIMMS_TOR_DATED" or die "Can't open RIMMS_TOR: $!";
#open  RIMMS_NY,  '<', "$RIMMS_NY_DATED"  or die "Can't open RIMMS_NY: $!";

my @RIMMS_LON = <$RIMMS_LON>;   #each line of the file into an array

while (my $line = <$RIMMS_LON>) {
    chomp $line;
    print $line.'RIMMS_LON';
}
close $RIMMS_LON or die "Can't close RIMMS_LON: $!";
