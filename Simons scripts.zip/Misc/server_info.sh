#!/bin/ksh
#/*********************************************************************************************
#  Name     : ${SCRIPTS_1}/server_info.sh
#  Purpose  : list DNS info for all relevant servers / alias's / Sybase servers
#  Usage    :  server_info.sh
#           :  alias srv='server_info.sh'
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  11/05/2007   S Osborne       Created
#
#*********************************************************************************************/

# banner NSLOOKUPS

HOST_LIST="lndvs341 lndvs342 lnpss152 lnpss153 lntrs418 lntrs419 usvdstgd1 usvdstgt1 usvdstgt2 usvdstgq1 uaetldbd1 uaetldbt1"
# HOST_LIST="s189 lntrs189 LDNEUR lntrs207 lntrs375 LDNEURBRP LDNEUR_TN lnbrs115 lndvs269 LDNEURDEV LDNEURDEV1_DS lndvs330 lndvs269v7 lnpss130 lnpss131" # lndvs144 lndvs123 LDNEURDEV 

for HOSTNAME in ${HOST_LIST}
do
   HOST_PREFIX=`echo ${HOSTNAME} | cut -c1-3`
   # echo "###################  ${HOSTNAME}.${DNS_SUFFIX} nslookup info ###################"
    case ${HOST_PREFIX} in 
       lnp) DNS_SUFFIX=ln.rbccm.com      ;; 
       lnd) DNS_SUFFIX=ln.rbccm.com      ;; 
       lnt) DNS_SUFFIX=ln.rbccm.com      ;; 
       usv) DNS_SUFFIX=devfg.rbc.com     ;; 
       uae) DNS_SUFFIX=devfg.rbc.com     ;; 
   esac
    IP_ADD=`nslookup  ${HOSTNAME}.${DNS_SUFFIX} | egrep -v "uklonss101|159.55.238.8|ibproduk1|authoritative" | grep Address | cut -d" " -f2`
    echo ${HOSTNAME}.${DNS_SUFFIX}  ${IP_ADD}
done

   #echo "\n###################  ${HOSTNAME} nslookup info ###################\n"
   # echo ".. and /etc/hosts :\n"
   # grep -i ${HOSTNAME} /etc/hosts 
   #echo '.. and ${SYBASE}/interfaces :\n'
   #grep -wi ${HOSTNAME} ${SYBASE}/interfaces

echo  "\n\n\n##############################################################################"
echo  "#################  Op system and platform info using uname -a then uname -x :  ###############"
echo  "##############################################################################\n"

# Version and hardware info:

uname -a   
echo "\n"
uname -X

echo  "\n##############################################################################"
echo  "#################  Applications supported by architectures info using isainfo -v :  ###############"
echo  "##############################################################################\n"

isainfo -v
echo "\n"

echo  "\n##############################################################################"
echo  "#################  Database isql connection details using isql -v :  ###############"
echo  "##############################################################################\n"

isql -v
echo "\n"


exit


lndvs342.ln.rbccm.com 172.25.76.86
lnpss153.ln.rbccm.com 172.28.123.182
lntrs419.ln.rbccm.com 172.28.92.162

usvdstgd1.devfg.rbc.com 10.241.159.53
usvdstgt1.devfg.rbc.com 10.241.158.167
usvdstgt2.devfg.rbc.com 10.241.158.191
usvdstgq1.devfg.rbc.com 10.241.159.54
uaetldbd1.devfg.rbc.com 10.241.146.146
uaetldbt1.devfg.rbc.com 10.241.146.226
