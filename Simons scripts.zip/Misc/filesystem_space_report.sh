#!/bin/ksh
#/*********************************************************************************************
#  Name     : ~/scripts/filesystem_space_report.sh
#  Purpose  : runs Ed Barlow's (http://www.edbarlow.com/document/procs/) sp__dbspace for all the listed databases on a given server
#  Usage    :  db_space_report.sh 95
#           :  alias dbs='db_space_report.sh'
#           :  daily_scripts_scheduler.sh : ${SCRIPT_DIR_2}/db_space_report.sh 95 > ${OUTPUT}
#           :  01 09,16 * * 1-5 /home/ukrr_pm/scripts/db_space_report.sh 95
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  06/06/2005   S Osborne       Created
#  14/01/2009   S Osborne       Added filesystem space check
#  17/06/2009   S Osborne       Added TEMPDB_THRESHOLD = 10 and logic to handle this
#
#*********************************************************************************************/

# . ~/.profile

# Declare variables :

#Default ALERT_THRESHOLD is 90.0 % else if parameter(1) is supplied use that.
if [[ -z ${1} ]]
then
   ALERT_THRESHOLD=95
else
   ALERT_THRESHOLD=${1}
fi

FILESYSTEM_THRESHOLD=80  # 90 in TEST

DISTR_LIST='simon.osborne@rbccm.com'

OUTPUT1=~/log/filesystem_space_report.out

DATA_DIRECTORY=/cm/ukrr_data/

> ${OUTPUT1}

########################################################################################################################################
# 2)check filesystem space :

FILESYSTEM_SPACE=`df -k ${DATA_DIRECTORY} | tail -1 | awk '{print $4}' | sed -e 's/\%//g'`
cd ${DATA_DIRECTORY}     #/UKRR_tst/

if [ ${FILESYSTEM_SPACE} -ge ${FILESYSTEM_THRESHOLD} ]
then
   echo \\n"Filesystem alert level is ${FILESYSTEM_THRESHOLD}% or around 5-10GB free as this is REQUIRED FOR ETL PROCESSING." >  ${OUTPUT1}
#   echo \\n"Run filesystem_housekeeping.sh to CLEAR DOWN SOME SPACE."        >>  ${OUTPUT1}
#   echo \\n"See this page for more info http://rbcwss.fg.rbc.com/ykl0/W99_EURUKRRSharepoint/Test%20Wiki/Housekeeping%20-%20Unix%20filesystem.aspx"        >>  ${OUTPUT1}
   echo \\n"Directory usage stats: "\\n                                                        >>  ${OUTPUT1}
   df -h ${DATA_DIRECTORY}                                                                     >>  ${OUTPUT1}
   echo \\n"biggest sub-directories :"\\n                                                      >>  ${OUTPUT1}
   du -k  | grep ^[0-9][0-9][0-9][0-9] | grep -v snapshot | sort -nr |  head -30               >>  ${OUTPUT1}
   SUBJECT="UKRR ${ENVIRONMENT} filesystem space alert for ${DATA_DIRECTORY} - space used is ${FILESYSTEM_SPACE} %"
   cat ${OUTPUT1} | mutt -s "${SUBJECT}" "${DISTR_LIST}"
fi

echo "\n files bigger than 200MB in sub-directories :"    >>  ${OUTPUT1} 
find ./?* -size   +200000000c -exec ls -l {} \;           >>  ${OUTPUT1} 

cat ${OUTPUT} | grep -iv denied | mutt -s "${SUBJECT}" "${DISTR_LIST}"

cat ${OUTPUT} | grep -iv denied

