#!/bin/ksh
###################################################################
# Script   : /opt/etl/code/bin/CDR/CDR_RECON_tools.sh  // TOOLS_SCRIPT=/opt/etl/code/bin/CDR/CDR_RECON_tools.sh 
# Purpose  : This script is a collection of misc useful functions for various ETL file operations. 
#          :   - Generally where the command is too long for a one line alias
# Usage    : TOOLS_SCRIPT=/opt/etl/code/bin/CDR/CDR_RECON_tools.sh ; export TOOLS_SCRIPT
#          : source_file_missing eg. :  ${TOOLS_SCRIPT} sfm 
#          : target_file_missing eg. :  ${TOOLS_SCRIPT} tfm 
#          : ETL_sourcefile_check eg.:  ${TOOLS_SCRIPT} esf [FILE_NAME_STRING] [FILE_HISTORY_COUNT] # eg. ICI 10 
#          : ETL_sourcefile_check eg.:  ${TOOLS_SCRIPT} esf "OPEN|YVO0|Adpus|ICI" 7  
# Modifications :
# Date         User               Description
#  -------------------------------------------------------------------------------------------
# 20/09/2012   Simon Osborne      Script created
# 07/11/2012   Simon Osborne      New version created in /opt/etl/code/bin/CDR/

###################################################################

FUNCTION_ALIAS=${1}
PARAM_1=${2}
PARAM_2=${3}
PARAM_3=${4}

MY_HOME=/opt/etl/code/bin/CDR

if [ ! -d ${MY_HOME}/logs/ ] ; then mkdir -p ${MY_HOME}/logs/ ; chmod -R 777 ${MY_HOME}/logs/ 2>/dev/null ; fi
LOG_FILE=${MY_HOME}/logs/unix_tools_${FUNCTION_ALIAS}.log  ; > ${LOG_FILE} ; chmod 777 ${LOG_FILE} 2>/dev/null

DATA_DIR=${MY_HOME}/data/temp  # DATA_DIR=/tmp     # used by 10) download_latest_files and also FTP pull via: ftp_ETL_testing_extracts.cmd
if [ ! -d ${DATA_DIR} ] ; then mkdir -p ${DATA_DIR} ; chmod -R 777 ${DATA_DIR} ; fi

typeset MY_HOME FUNCTION_ALIAS PARAM_1 LOG_FILE 

echo > ${LOG_FILE} ; date '+Run time: %Y-%m-%d at %H:%M:%S %Z' >> ${LOG_FILE} # ; echo >> ${LOG_FILE}

#### 08) ETL_sourcefile_check esf ###############################################################
function ETL_sourcefile_check {

#Default FILE_NAME_STRING is *, else use ${PARAM_1} if this parameter is supplied. 
if [[ -z ${PARAM_1} ]]
then
   FILE_NAME_STRING="*"
else
   FILE_NAME_STRING=${PARAM_1}
fi

#Default FILE_HISTORY_COUNT is 20, else use ${PARAM_2} if this parameter is supplied. 
if [[ -z ${PARAM_2} ]] ; then  FILE_HISTORY_COUNT=20
    else  FILE_HISTORY_COUNT=${PARAM_2} ; fi

echo ; echo " ${FUNCTION}: Searching for the ${FILE_HISTORY_COUNT} most recent CDR and BDR Recon source OR target files with ${FILE_NAME_STRING} in their name :"

DIR_LIST="                                    \
/data/etl/NAS/ZAS0/CDR_RECON/incoming/        \
/data/etl/NAS/ZAS0/CDR_RECON/toImatch/        \
/data/etl/NAS/ZAS0/BDR_RECON/incoming/        \
/data/etl/NAS/ZAS0/BDR_RECON/toImatch/        \
/data/etl/NAS/BDR_RECON/OPICS/                "

# /data/etl/NAS/ZAS0/CDR_RECON/archive/         \

for DIR in ${DIR_LIST}
do
   echo "##########################" ; echo ${DIR} :
   ls -lrt ${DIR} 2>/dev/null | egrep -i "${FILE_NAME_STRING}" | tail -${FILE_HISTORY_COUNT}  | sort -k 1.54 
done

#ls -lrt /data/etl/NAS/ZAS0/?DR_RECON/incoming/ /data/etl/NAS/ZAS0/?DR_RECON/toImatch/ | egrep -i "${FILE_NAME_STRING}" | tail -20  | sort -k 1.54 

}  # end function

#### 09) function source_file_missing sfm ###############################################################
function source_file_missing {
# 1) Comparing yesterday's CDR and BDR Recon files to today's

CURRENT_DATE=`ls -1rt /data/etl/NAS/ZAS0/BDR_RECON/toImatch/*txt* | egrep -v "RBCE"  | tail -1 | cut -d "/" -f8  | cut -d "_" -f5 | cut -d "." -f1` 
PREV_DATE=`ls -1rt /data/etl/NAS/ZAS0/CDR_RECON/archive/*txt* | tail -1 | cut -d "/" -f8  | cut -d "_" -f5 | cut -d "." -f1` 

echo  \\n"Comparing yesterday's (${PREV_DATE}) CDR and BDR Recon SOURCE files to today's (${CURRENT_DATE}) and showing any missing files on either day :"

ls -1rt /data/etl/NAS/ZAS0/CDR_RECON/incoming/*${PREV_DATE}*    | sed -e "s/${PREV_DATE}/${CURRENT_DATE}/g"  > ${LOG_FILE}.tmp 
ls -1rt /data/etl/NAS/ZAS0/CDR_RECON/incoming/*${CURRENT_DATE}*  >> ${LOG_FILE}.tmp 

ls -1rt /data/etl/NAS/ZAS0/BDR_RECON/incoming/*${PREV_DATE}* | egrep -v 'CI_LON_20.......ok' | sed -e "s/${PREV_DATE}/${CURRENT_DATE}/g"  >> ${LOG_FILE}.tmp 
ls -1rt /data/etl/NAS/ZAS0/BDR_RECON/incoming/*${CURRENT_DATE}* | egrep -v 'CI_LON_20.......ok' >> ${LOG_FILE}.tmp 

sort ${LOG_FILE}.tmp  | uniq -u ; sleep 5 
echo "See here for the full file list: ${LOG_FILE}.tmp \n" >> ${LOG_FILE}

# 2) For these files, searching for the 10 most recent CDR and BDR Recon files with the distinct string in their name :"
SYSTEM_NAME_STRING_LIST="" ; COUNTER=0
for SYSTEM_NAME_STRING in `sort ${LOG_FILE}.tmp | cut -d "/" -f8 | cut -d "2" -f1 | uniq -u`
do
   SYSTEM_NAME_STRING_LIST=${SYSTEM_NAME_STRING_LIST}"|"${SYSTEM_NAME_STRING} 
   COUNTER=`expr ${COUNTER} + 1 `
done

PARAM_1=`echo ${SYSTEM_NAME_STRING_LIST} | cut -c2-100` ; PARAM_2=10  # drops leading |
typeset PARAM_1 PARAM_2
if [ ${COUNTER} -ge 1 ] ; then  ETL_sourcefile_check '"'${PARAM_1}'"' ${PARAM_2} ; else echo "   ####  NO MISSING FILES FOUND ####  " ; return 0 ; fi

# 3) Optional workaround commands:
echo ; echo "In case needed, eg for Bank holidays and if it's an acceptable workaround for CDR Recon files: use the below commands to copy the previous day's file to today: "

for FILE in `sort ${LOG_FILE}.tmp | uniq -u`
do
   FILE_PREV=`echo ${FILE} | sed -e "s/${CURRENT_DATE}/${PREV_DATE}/g" `
   echo "Confirming file missing: " `ls -l ${FILE}`
   echo "cp ${FILE_PREV} ${FILE}"
done

echo  "\nTO RUN the above file copy commands : \n"
read INPUT?"--> Press enter to CONTINUE or CTRL+c to ABORT ..."

for FILE in `sort ${LOG_FILE}.tmp | uniq -u`
do
   FILE_PREV=`echo ${FILE} | sed -e "s/${CURRENT_DATE}/${PREV_DATE}/g" `
   cp ${FILE_PREV} ${FILE}
done

}  # end function

#### 09b) function target_file_missing tfm ###############################################################
function target_file_missing {
# 1) Comparing yesterday's CDR and BDR Recon files to today's

CURRENT_DATE=`ls -1rt /data/etl/NAS/ZAS0/BDR_RECON/toImatch/*txt* | egrep -v "RBCE"  | tail -1 | cut -d "/" -f8  | cut -d "_" -f5 | cut -d "." -f1` 
PREV_DATE=`ls -1rt /data/etl/NAS/ZAS0/CDR_RECON/archive/*txt* | tail -1 | cut -d "/" -f8  | cut -d "_" -f5 | cut -d "." -f1` 

echo  \\n"Comparing yesterday's (${PREV_DATE}) CDR and BDR Recon OUTPUT files to today's (${CURRENT_DATE}) and showing any missing files on either day :"

ls -1rt /data/etl/NAS/ZAS0/CDR_RECON/archive/*${PREV_DATE}*txt*  | sed -e "s/${PREV_DATE}/${CURRENT_DATE}/g" -e "s/archive/toImatch/g" -e "s/\.gz//g"  > ${LOG_FILE}.tmp 
ls -1rt /data/etl/NAS/ZAS0/CDR_RECON/toImatch/*${CURRENT_DATE}*txt*  >> ${LOG_FILE}.tmp 

ls -1rt /data/etl/NAS/ZAS0/BDR_RECON/toImatch/*${PREV_DATE}*txt*  | sed -e "s/${PREV_DATE}/${CURRENT_DATE}/g" -e "s/\.gz//g"  >> ${LOG_FILE}.tmp 
ls -1rt /data/etl/NAS/ZAS0/BDR_RECON/toImatch/*${CURRENT_DATE}*txt*  >> ${LOG_FILE}.tmp 

sort ${LOG_FILE}.tmp  | uniq -u ; sleep 5 
echo "See here for the full file list: ${LOG_FILE}.tmp \n" >> ${LOG_FILE}

# 2) For these files, searching for the 10 most recent CDR and BDR Recon files with the distinct string in their name :"
SYSTEM_NAME_STRING_LIST="" ; COUNTER=0
for SYSTEM_NAME_STRING in `sort ${LOG_FILE}.tmp  | uniq -u | cut -d "/" -f8  | cut -d "_" -f3`
do
   SYSTEM_NAME_STRING_LIST=${SYSTEM_NAME_STRING_LIST}"|"${SYSTEM_NAME_STRING} 
   COUNTER=`expr ${COUNTER} + 1 `
done

PARAM_1=`echo ${SYSTEM_NAME_STRING_LIST} | cut -c2-100` ; PARAM_2=10  # drops leading |
typeset PARAM_1 PARAM_2
if [ ${COUNTER} -ge 1 ] ; then  ETL_sourcefile_check '"'${PARAM_1}'"' ${PARAM_2} ; else echo "   ####  NO MISSING FILES FOUND ####  " ; return 0 ; fi

# 3) Optional workaround commands:
echo ; echo "In case needed, and if acceptable workaround for CDR Recon files: use the below commands to copy the previous day's file to today: "

for SYSTEM_NAME_STRING in `sort ${LOG_FILE}.tmp | uniq -u | cut -d "/" -f8 | grep "^CDR"  | cut -d "_" -f1,2,3,4`
do
   echo "gunzip -c `ls -1rt /data/etl/NAS/ZAS0/CDR_RECON/archive/${SYSTEM_NAME_STRING}* | tail -1` > `sort ${LOG_FILE}.tmp  | uniq -u | grep ${SYSTEM_NAME_STRING}` "
done

for SYSTEM_NAME_STRING in `sort ${LOG_FILE}.tmp | uniq -u | cut -d "/" -f8 | grep "^BDR"  | cut -d "_" -f1,2,3,4`
do
   echo "cp `ls -1rt /data/etl/NAS/ZAS0/BDR_RECON/toImatch/${SYSTEM_NAME_STRING}* | tail -1` `sort ${LOG_FILE}.tmp  | uniq -u | grep ${SYSTEM_NAME_STRING}` "
done

}  # end function


############################################################################
# Main - call the required function according to what input was supplied and display outputs and logs

echo "\nFUNCTION= ${FUNCTION} // PARAM_1_\$2= ${PARAM_1} // PARAM_2_\$3= ${PARAM_2} // LOG_FILE= ${LOG_FILE}" | tee -a ${LOG_FILE} 

case ${FUNCTION_ALIAS} in
        esf     )  ETL_sourcefile_check          ;;  
        sfm     )  source_file_missing           ;;  
        tfm     )  target_file_missing           ;;  
esac

cat ${LOG_FILE} | grep -v 'FUNCTION=' ;  echo
