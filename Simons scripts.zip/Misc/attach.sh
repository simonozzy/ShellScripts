#!/bin/ksh
#/*********************************************************************************************
#  Name     : attach.sh
#  Purpose  : attach a file to an email and send to the user.
#  Usage    : attach file_name
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  01/02/2005   S Osborne       Created
#*********************************************************************************************/

FILE=${1}

DISTR_LIST='simon.osborne@rbccm.com'
#DISTR_LIST='UKRR-support@rbccm.com'

# uuencode ${FILE} ${FILE} | mailx -s "File attached : ${FILE}" "${DISTR_LIST}"

echo "File sent from Unix attach.sh command attached" | mutt -s "File attached : ${FILE}" -a ${FILE} "${DISTR_LIST}"    
