

--##################################################################################################################################
--# 3)  Poller and scheduling stuff : 

SELECT ENVIRONMENT_DATA, TO_CHAR( UPDATED_ON,  'DD-MM-YYYY HH24:MI')  as " UPDATED_ON" , UPDATED_BY	
FROM ETL_HEARTBEAT
WHERE UPDATED_BY like '%ETL%' -- STN_TST.

SELECT ENVIRONMENT_DATA, TO_CHAR( UPDATED_ON,  'DD-MM-YYYY HH24:MI')  as " UPDATED_ON" , UPDATED_BY FROM ETL_HEARTBEAT        WHERE RUN_TYPE_ID=1   UNION ALL                                                                                                                                           
SELECT ENVIRONMENT_DATA, TO_CHAR( UPDATED_ON,  'DD-MM-YYYY HH24:MI')  as " UPDATED_ON" , UPDATED_BY FROM STN.ETL_HEARTBEAT     WHERE RUN_TYPE_ID=1  UNION ALL                                                                                                                                           
SELECT ENVIRONMENT_DATA, TO_CHAR( UPDATED_ON,  'DD-MM-YYYY HH24:MI')  as " UPDATED_ON" , UPDATED_BY FROM STN_TST.ETL_HEARTBEAT WHERE RUN_TYPE_ID=1 

Insert into ETL_HEARTBEAT
   (RUN_TYPE_ID, ENVIRONMENT_DATA, UPDATED_ON, UPDATED_BY, CREATED_ON, CREATED_BY)
 Values
   (1, 'usvetlt02', TO_DATE('06/24/2013 13:07:10', 'MM/DD/YYYY HH24:MI:SS'), 'ETLADM', TO_DATE('06/24/2013 13:07:10 14:23:26', 'MM/DD/YYYY HH24:MI:SS'), 
    'STN');
COMMIT;

SELECT run_type_id|| ' ' || environment_data||' ' ||to_char(updated_on,'DD-MM-YYYY HH:MI:SS')||' ' || updated_by||' '
||   CASE WHEN (updated_on > SYSDATE - 3/1440) then 'ACTIVE' else 'INACTIVE' end
FROM etl_heartbeat

call PG_ETL_SCHEDULER.UPDATE_ETL_HEARTBEAT('ETL','ulvetlt02') 

select * from stn.etl_heartbeat

select *  from all_synonyms where table_name = 'ETL_HEARTBEAT' -- user_synonyms 

SELECT * -- ENVIRONMENT_DATA, TO_CHAR( UPDATED_ON,  'DD-MM-YYYY HH24:MI')  as " UPDATED_ON" , UPDATED_BY	

--UPDATE ETL_HEARTBEAT SET ENVIRONMENT_DATA='usvdstgp1' WHERE UPDATED_BY like '%ETL%' 
SELECT * FROM fdr.fr_global_parameter  WHERE  lpg_id = 2

SELECT * FROM ETL_PROCESS_STATUS ; -- PROCESS_STATUS_ID, PROCESS_STATUS_NAME
SELECT * FROM etl_run_type WHERE TYPE_NAME = 'ETL'; -- RUN_TYPE_ID, TYPE_NAME
SELECT * FROM etl_batch_status  ; -- BATCH_STATUS_ID,BATCH_STATUS_NAME


-- Issue 1) ETL polling on BATCH_STATUS_ID instead of BATCH_STATUS_NAME from the STN.ETL_BATCH_STATUS table.
-- STN.ETL_BATCH_STATUS - ETL is expecting to see: 1=READY; 2=STARTED; 3=ERROR; 4=COMPLETE

UPDATE etl_batch_status 
SET BATCH_STATUS_ID =  BATCH_STATUS_ID - 20 
WHERE BATCH_STATUS_ID in (21,22,23,24)

-- SELECT CASE batch_status_NAME  1=READY; 2=STARTED; 3=ERROR; 4=COMPLETE

-- And breaks if the ID's are different, which they are in this stripped down environment due to sequence numbers etc�
-- We just need to keep track of these two things - they are easy enough for me to fix in Q1 and Q3.

DELETE FROM STN.ETL_RUN_TYPE WHERE RUN_TYPE_ID = 29;
COMMIT;

call STN.PG_ETL_SCHEDULER.WAIT_FOR_ETL_BATCH_RUN('LON Daily FX Positions User Extract',3600,2)

call PG_ETL_SCHEDULER.WAIT_ETL_BATCH_RUN_prevBUSDATE('Slim to Opics Reconciliation',1800,4)

call PG_ETL_SCHEDULER.EGLWORKDAY_WAIT_FOR_ETL_BATCH('Refresh Infinity Extracts',3600,2)                         ;
call PG_ETL_SCHEDULER.WAIT_FOR_ETL_BATCH_RUN('LON SLIM/Infinity Open trades Recon - Infinity Ext',2700,2)	;

call PG_ETL_SCHEDULER.WAIT_FOR_ETL_BATCH_RUN_PARAM2('eGL',1200,'90120')						;
call PG_ETL_SCHEDULER.WAIT_FOR_ETL_BATCH_RUN_PARAM2('eGL',1200,'00300')						;
call PG_ETL_SCHEDULER.WAIT_FOR_ETL_BATCH_RUN('Load Infinity slim_book table',300,4)				;
call PG_ETL_SCHEDULER.WAIT_FOR_ETL_BATCH_RUN('TOR Infinity Refresh Fixings',3600,4)				;
call PG_ETL_SCHEDULER.WAIT_FOR_ETL_BATCH_RUN('LON PnL Detail User Extract',21600,2)				;
call PG_ETL_SCHEDULER.WAIT_ETL_BATCH_RUN_prevBUSDATE('Slim Reconciliation',21600,4)				;
call PG_ETL_SCHEDULER.WAIT_ETL_BATCH_RUN_prevBUSDATE('Slim Cpty Reconciliation',10800,4)			;
call PG_ETL_SCHEDULER.WAIT_ETL_BATCH_RUN_prevBUSDATE('Slim to Opics Reconciliation',1800,4)			;
call PG_ETL_SCHEDULER.WAIT_ETL_BATCH_RUN_prevBUSDATE('Slim to Rimms Reconciliation',1800,4)			;
call PG_ETL_SCHEDULER.WAIT_ETL_BATCH_RUN_prevBUSDATE('Slim to Anvil Reconciliation',1800,4)			;
call PG_ETL_SCHEDULER.WAIT_ETL_BATCH_RUN_prevBUSDATE('TOR Bonds CUSIP User Extract',9000,4)			;
call PG_ETL_SCHEDULER.WAIT_FOR_ETL_BATCH_RUN_PARAM2('TOR eDR Extract - Monthly',5400,'00300')			;
call PG_ETL_SCHEDULER.WAIT_FOR_ETL_BATCH_RUN_PARAM2('TOR eDR Extract - Daily',5400,'00300')			;
call PG_ETL_SCHEDULER.WAIT_FOR_ETL_BATCH_RUN('TOR Infinity Reconciliation',3600,NULL,PG_ETL_SCHEDULER.GET_TODAYS_BUS_DATE(4)) ;
call PG_ETL_SCHEDULER.WAIT_FOR_ETL_BATCH_RUN('Infinity table refresh',300,2)					;

SELECT TRANSIT FROM RDR.RR_DAILY_PNL_TRANSIT

-- jobs missing:
call PG_ETL_SCHEDULER.WAIT_FOR_ETL_BATCH_RUN_PARAM2('TOR eDR Extract - Monthly',5400,'00300')			;
call PG_ETL_SCHEDULER.WAIT_FOR_ETL_BATCH_RUN_PARAM2('TOR eDR Extract - Daily',5400,'00300')			;

-- INBOUNDS:

call PG_ETL_SCHEDULER.WAIT_FOR_ETL_BATCH_prevWEEK('LON Infinity Traders - Incremental',1800,2) -- 1 job.
call PG_ETL_SCHEDULER.WAIT_FOR_ETL_BATCH_RUN('TOR Infinity Pos Incremental',3600,4) -- 1 job. Only 1 row in UAT vs 450 in PROD

call PG_ETL_SCHEDULER.WAIT_FOR_ETL_BATCH_RUN('TOR Infinity Trades Incremental',3600,4) ;
call PG_ETL_SCHEDULER.WAIT_FOR_ETL_BATCH_RUN('LON Infinity Trades - Incremental',3600,2) ;


--##################################################################################################################################
--# 4) SLIM stn.ETL_BATCH_RUN tables queries
/*  The stage steps */

select to_char(gp_yesterday_bus_date,'YYYYMMDD')           -- YESTERDAY_BUS_DATE
     , to_char(gp_todays_bus_date,'YYYYMMDD')              -- TODAY_BUS_DATE
     , to_char(gp_tomorrows_bus_date,'YYYYMMDD')           -- TOMORROW_BUS_DATE
     , to_char(gp_todays_bus_date,'YYYYMMDD')              -- BATCH_BUS_DATE
     , to_char(gp_last_month_end_date,'YYYYMMDD')          -- PREV_MONTH_END_BUS_DATE
     , to_char(gp_this_month_start_date,'YYYYMMDD')        -- THIS_MONTH_START_BUS_DATE
     , to_char(gp_this_month_end_date,'YYYYMMDD')          -- THIS_MONTH_END_BUS_DATE
     , to_char(gp_todays_bus_date,'YYYYMMDD')              -- BUS_DATE_START
  from fdr.fr_global_parameter   
 where lpg_id = 2
 
SELECT bs_object_name
       , bs_stage
       , bs_order_in_stage
       , bs_object_type
       , lpg_id
       , bs_processing_date
       , bs_step_id
-- SELECT *
  FROM fr_batch_schedule
WHERE 1=1
AND  bs_stage like '%ETL_%' --  = 'RDR_TRANS' ETL_LDN_RECON_EXTRACTS
AND    bs_hold_job <> 'Y'
--AND    lpg_id = 4
AND    rownum < 200
ORDER BY bs_processing_date DESC    
        
SELECT * FROM fdr.fr_batch_schedule WHERE bs_stage IN ('INCREMENTAL_ETL_PROCESS','LDN_INCREMENTAL_ETL_PROCESS')          
/*
** The steps in the process Run table
*/    

SELECT pr.process_run_id
--       , CASE WHEN pr.process_run_id  > 801658 THEN '8.5' ELSE '7.5' END as "version"
--       , pr.batch_run_id
       --, lpg_id
--       , TO_CHAR(br.BATCH_BUS_DATE,'YYYYMMDD')       as "BATCH_BUS_DATE"
--       , mah_process_def_id
       , pr.process_name
--       , run_type_id
       , TO_CHAR(process_start,  'DD-MM-YYYY HH24:MI')   as "process_start"
--       , TO_CHAR(process_end,  'DD-MM-YYYY HH24:MI')     as "process_end"
--       , process_start
--       , process_end
       , round((process_end-process_start)*60*24,1) Min
--       , processed_rows
       , successful_rows
       , failed_rows
--SELECT *
  FROM stn.etl_process_run pr
  JOIN stn.etl_batch_run br on pr.batch_run_id = br.batch_run_id
WHERE 1=1
AND   run_type_id = 1
--AND   br.BATCH_RUN_ID > (SELECT max( BATCH_RUN_ID) -10000 FROM stn.ETL_BATCH_RUN  )   
AND process_start > (sysdate - 6)
--AND   pr.process_run_id > 778891 --(SELECT max( process_run_id) -20000 FROM stn.etl_process_run WHERE  process_start > (sysdate - 10)  )   
--AND   UPPER(pr.process_name) like '%ONDP%' -- INFINITY_RECONCILATION SEQ_LON_%_EXTRACT SEQ_LON_%_REC  SEQ_LON_%_ SEQ_EDR_
--AND   rownum < 400
ORDER BY pr.process_run_id DESC, process_start DESC
   
SELECT * FROM fdr.fr_global_parameter

--select process_run_id, batch_run_id, process_name, (process_end-process_start)*24*60 min
-- Check ETL process average performance:

select pr.process_name, lpg_id, avg(process_end - process_start)*24*60 as avg_min, avg(processed_rows) as avg_rows
from etl_process_run pr
join etl_batch_run br on pr.batch_run_id = br.batch_run_id 
where run_type_id = 1
AND   (process_end - process_start) > 0 -- is not null
--���and process_name <> 'Jimmy Hoffa'
AND   br.BATCH_RUN_ID > ( SELECT max(BATCH_RUN_ID) -10000 FROM stn.etl_process_run  )   
group by pr.process_name, lpg_id


SELECT   ebr.BATCH_RUN_ID
--,        stn.SQETL_PROCESS_RUN.NEXTVAL
,        ert.TYPE_NAME
,        epd.PROCESS_NAME  -- DUP
,        ebs.BATCH_STATUS_NAME
,        TO_CHAR(ebr.BATCH_BUS_DATE,'YYYYMMDD')              as "BATCH_BUS_DATE" -- DUP
,        TO_CHAR(ebr.BUS_DATE_START,'YYYYMMDD')              as "BUS_DATE_START"
,        TO_CHAR(ebr.BUS_DATE_END,'YYYYMMDD')                as "BUS_DATE_END"
,        TO_CHAR(ebr.QUERY_START,'YYYYMMDDHH24:MI:SS')       as "QUERY_START"
,        TO_CHAR(ebr.QUERY_END,'YYYYMMDDHH24:MI:SS')         as "QUERY_END"
,        epd.BATCH_DEF_ID
,        epd.PROCESS_DEF_ID
,        epd.PROCESS_PRIORITY
,        epd.PROCESS_NAME
,        epd.DEST_TABLE_NAME
,        ebd.LPG_ID
,        TO_CHAR(ebr.BATCH_BUS_DATE,'YYYYMMDD')              as "BATCH_BUS_DATE"
,        TO_CHAR(ebr.PREV_MONTH_END_BUS_DATE,'YYYYMMDD')     as "PREV_MONTH_END_BUS_DATE"
,        TO_CHAR(ebr.THIS_MONTH_END_BUS_DATE,'YYYYMMDD')     as "THIS_MONTH_END_BUS_DATE"
,        TO_CHAR(ebr.THIS_MONTH_START_BUS_DATE,'YYYYMMDD')   as "THIS_MONTH_START_BUS_DATE"
,        TO_CHAR(ebr.YESTERDAY_BUS_DATE,'YYYYMMDD')          as "YESTERDAY_BUS_DATE"
,        TO_CHAR(ebr.TODAY_BUS_DATE,'YYYYMMDD')		     as "TODAY_BUS_DATE"
,        TO_CHAR(ebr.TOMORROW_BUS_DATE,'YYYYMMDD')	     as "TOMORROW_BUS_DATE"
,        trim(ebr.PARAMETER_2)				     as "PARAMETER_2"
,        trim(ebr.PARAMETER_3)                               as "PARAMETER_3"
,        TO_CHAR(ebr.PARAMETER_4_DATE,'YYYYMMDD')            as "PARAMETER_4"
,        TO_CHAR(ebr.PARAMETER_5_DATE,'YYYYMMDD')	     as "PARAMETER_5"
,        TO_CHAR(ebr.PARAMETER_6_DATE,'YYYYMMDD')	     as "PARAMETER_6"
FROM      stn.ETL_BATCH_RUN      ebr
,        stn.ETL_RUN_TYPE        ert
,        stn.ETL_BATCH_STATUS    ebs
,        stn.ETL_BATCH_DEF       ebd
,        stn.ETL_PROCESS_DEF     epd
WHERE ebr.RUN_TYPE_ID=ert.RUN_TYPE_ID
AND   ebr.BATCH_STATUS_ID=ebs.BATCH_STATUS_ID 
AND   ebr.BATCH_DEF_ID=ebd.BATCH_DEF_ID       
AND   ebd.BATCH_DEF_ID=epd.BATCH_DEF_ID       
AND   ert.TYPE_NAME='ETL'                   
AND    ebr.BATCH_RUN_ID > (SELECT max(BATCH_RUN_ID) -100 FROM stn.ETL_BATCH_RUN  )   
AND   ebs.BATCH_STATUS_NAME != 'COMPLETE' -- 'READY'           
AND NOT EXISTS (SELECT 1 FROM stn.ETL_PROCESS_RUN epr 
                WHERE epr.BATCH_RUN_ID=ebr.BATCH_RUN_ID AND epd.PROCESS_DEF_ID=epr.PROCESS_DEF_ID AND epr.PROCESS_STATUS_ID = 0 )
--AND  BATCH_BUS_DATE > (sysdate - 91)
--AND   UPPER(epd.process_name) like '%EDR%' -- INFINITY_RECONCILATION
ORDER BY ert.TYPE_NAME
,        ebr.BATCH_RUN_ID DESC


SELECT   epd1.PROCESS_DEF_ID
--,        ebd1.BATCH_NAME
--,        ebd.BATCH_DESC
,        epd1.PROCESS_NAME
,        epd1.DEST_TABLE_NAME
,        epd2.PROCESS_DEF_ID
,        epd2.PROCESS_NAME
,        epd2.DEST_TABLE_NAME
FROM     stn.ETL_PROCESS_DEF          epd1
,        stn.ETL_PROCESS_DEPENDENCY   dep
,        stn.ETL_PROCESS_DEF          epd2
WHERE   epd1.PROCESS_DEF_ID     =  dep.PROCESS_DEF_ID	
AND     epd2.PROCESS_DEF_ID     =  dep.DEPENDS_ON_ID

--AND   ebd.BATCH_DESC NOT LIKE '%onversion%'
ORDER BY 1,2,3


SELECT ebr.* 
,      '  ||  '  
,      epr.*
FROM stn.ETL_BATCH_RUN      ebr
,    stn.ETL_PROCESS_RUN    epr
WHERE 1=1
AND   epr.BATCH_RUN_ID=ebr.BATCH_RUN_ID
--AND PROCESS_END > (sysdate - 3)
AND   ebr.BATCH_RUN_ID > (SELECT max( ebr.BATCH_RUN_ID) -100 FROM stn.ETL_BATCH_RUN  )   


SELECT * 
FROM STN.ETL_BATCH_DEF       
WHERE CREATED_ON > (sysdate - 90)

SELECT * 
FROM STN.ETL_PROCESS_DEF       
WHERE CREATED_ON > (sysdate - 90)

SELECT * 
FROM STN.ETL_BATCH_RUN       
WHERE CREATED_ON > (sysdate - 2)

SELECT * 
FROM STN.ETL_PROCESS_RUN       
WHERE CREATED_ON > (sysdate - 30)

--############################################################################
-- "RRV_SLIM_RIMMS_BRIDGE"

SELECT TRANSFER_DATE,RIMMS_CAPTURE_ID,RIMMS_AMEND_ID,RIMMS_VERIFY_ID,RIMMS_VOUCHER_NUMBER,RIMMS_ACCOUNT_NAME,RIMMS_ACCOUNT_TYPE,RIMMS_CURRENCY,RIMMS_REFERENCE,RIMMS_SUB_BRANCH,RIMMS_REVERSAL_VALUE,RIMMS_REVERSAL_VALUE_DIRECTION,SLIM_ACCOUNT,SLIM_ACCOUNT_NAME,SLIM_CURRENCY,SLIM_LEGAL_ENTITY,SLIM_BOOK,SLIM_PRODUCT,SLIM_COUNTERPARTY,SLIM_SOURCE_SYSTEM,SLIM_VALUE,SLIM_VALUE_DIRECTION FROM "RDR"."RRV_SLIM_RIMMS_BRIDGE";

CREATE TABLE "RDR"."RRV_SLIM_RIMMS_BRIDGE"
(
   TRANSFER_DATE date,
   RIMMS_CAPTURE_ID varchar2(8),
   RIMMS_AMEND_ID varchar2(8),
   RIMMS_VERIFY_ID varchar2(8),
   RIMMS_VOUCHER_NUMBER decimal(8),
   RIMMS_ACCOUNT_NAME varchar2(12),
   RIMMS_ACCOUNT_TYPE varchar2(4),
   RIMMS_CURRENCY char(3),
   RIMMS_REFERENCE varchar2(3),
   RIMMS_SUB_BRANCH varchar2(6),
   RIMMS_REVERSAL_VALUE decimal(15),
   RIMMS_REVERSAL_VALUE_DIRECTION char(2),
   SLIM_ACCOUNT varchar2(20),
   SLIM_ACCOUNT_NAME varchar2(255),
   SLIM_CURRENCY char(3),
   SLIM_LEGAL_ENTITY varchar2(20),
   SLIM_BOOK varchar2(20),
   SLIM_PRODUCT varchar2(20),
   SLIM_COUNTERPARTY varchar2(20),
   SLIM_SOURCE_SYSTEM varchar2(20),
   SLIM_VALUE decimal(38),
   SLIM_VALUE_DIRECTION char(2)
)
;

--##################################################################################################################################
--# 10)  System / DBA object / ddl tables : 

SELECT  * --, VIEW_NAME 
FROM   SYS.ALL_VIEWS
WHERE VIEW_NAME  --in (SELECT SYNONYM_NAME FROM ALL_SYNONYMS WHERE OWNER = 'ETLADM')
like '%ISCA%'  OR VIEW_NAME like ('%JRNL_LINES%')

SELECT  * 
FROM   SYS.ALL_SOURCE
WHERE TYPE in ('PROCEDURE','FUNCTION','PACKAGE') 
--AND OWNER NOT in ('SYS')
AND NAME like 'PR_SLIM_ETL_INSERT%'
--AND   NAME  in ( SELECT SYNONYM_NAME FROM ALL_SYNONYMS WHERE OWNER = 'ETLADM')

SELECT * FROM ALL_TAB_COLUMNS
WHERE OWNER NOT like 'SYS%'
--WHERE ROWNUM < 100

SELECT * FROM ALL_TABLES
WHERE ROWNUM < 1000

SELECT TABLE_NAME
,      count(*) as "row_count"  
,      min(OWNER) as "min_owner" 
,      max(OWNER) as "max_owner" 
FROM ALL_TABLES 
WHERE OWNER in ('STN', 'ETLADM')
GROUP BY TABLE_NAME 
HAVING count(*) > 1

SELECT * FROM SYS.ALL_OBJECTS WHERE OBJECT_NAME like '%HEARTBEAT%'  -- '%ETL_INSERT%' ETL_BATCH PG_ETL_SCHEDULER


SELECT OWNER, OBJECT_NAME,OBJECT_TYPE,STATUS,LAST_DDL_TIME,OBJECT_ID,CREATED  FROM SYS.ALL_OBJECTS WHERE OBJECT_NAME like '%ETL_INSERT%' ORDER BY 1,2

SELECT SYNONYM_NAME as "ETLADM_SYNONYM" FROM ALL_SYNONYMS WHERE OWNER = 'ETLADM' 

SELECT sys_context('USERENV','SERVER_HOST', 'SID', 'INSTANCE_NAME') FROM dual
SELECT sys_context('USERENV','INSTANCE_NAME') FROM dual ;

select name from stn.v$database 

--##################################################################################################################################
--# 11)  commands for linked DBs  : 

--# To Create the link:
CREATE DATABASE LINK dxauf03b@stn 
CONNECT TO stn IDENTIFIED BY Testsl1m
USING 'dxauf03' ;
--USING '(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=GUEDLPDSLM001.devfg.rbc.com)(PORT=1503))(CONNECT_DATA=(SERVICE_NAME=dxauf03)))' ;
--DROP DATABASE LINK dxauf03@slr 

--#To Test the Link:

select name from v$database@dxauf03@stn
select * from dba_db_links
insert into etl_heartbeat  select * from stn.etl_heartbeat@uat4;
select * from stn.etl_heartbeat@dxauf03@stn ;

-- select STN.PG_ETL_SCHEDULER.INSERT_ETL_PROCESS_RUN('seq_LON_SLIM_DailyCash_Extract', 3462, 308350)    from dual

SELECT TO_CHAR(INPUT_TIME,  'DD-MM-YYYY HH24')  as "INPUT_TIME"  
,      PROCESS_RUN_ID
,      EVENT_STATUS
,      count(DISTINCT GLOSS_JOURNAL_NO)  as  "journal_count"     
,      count(*)                           as  "row_count"     
,      min(GLOSS_JOURNAL_NO)		as  "min_journal_no"    
,      max(GLOSS_JOURNAL_NO)		as  "max_journal_no"    
FROM STN.LDNGLOSS_SLIM_EQ_TRANS
WHERE INPUT_BY = 'ETLADM' 
AND    INPUT_TIME  > (sysdate -915)
AND  SEQUENCE_NUMBER > (SELECT max(SEQUENCE_NUMBER) - 3e4 FROM STN.LDNGLOSS_SLIM_EQ_TRANS )
--AND PROCESS_RUN_ID BETWEEN 200 AND 210
GROUP BY TO_CHAR(INPUT_TIME,  'DD-MM-YYYY HH24')  
,     PROCESS_RUN_ID
,      EVENT_STATUS

SELECT count(*)  FROM STN.LDNGLOSS_SLIM_EQ_TRANS


SELECT DECODE( SUBSTR(TN,1,20),
        'LDNINF_SLIM_CSHTRADE',       'Seq_LON_DLY_Cash'                      , 
        'LDNINF_SLIM_ETDTRADE',       'Seq_LON_DLY_ETD'                       , 
        'LDNINF_SLIM_FXSTRADE',       'Seq_LON_DLY_FX'                        , 
        'LDNINF_SLIM_LDSTRADE',       'Seq_LON_DLY_LD_Mortgages'              , 
        'LDNINF_SLIM_OTCTRADE',       'Seq_LON_DLY_OTC'                       , 
        'LDNINF_SLIM_SWPTRADE',       'Seq_LON_DLY_SWAP_FRA'                  , 
        'LDNINF_SLIM_TRADSALE',       'Seq_LON_DLY_TRADSALE'                  , 
        'LDNINF_SLIM_POSITION',       'Seq_LON_Positions_Load'                , 
        'LDNINF_SLIM_TRDSETTL',       'Seq_LON_Settlements_Load'              , 
        'LDNINF_SLIM_TRADEVAL',       'Seq_LON_Valuations_Load'               , 
        'TORINF_SLIM_SECTRADE',       'Seq_TOR_DLY_BOND'                      , 
        'TORINF_SLIM_CSHTRADE',       'Seq_TOR_DLY_Cash'                      , 
        'TORINF_SLIM_ETDTRADE',       'Seq_TOR_DLY_ETD'                       , 
        'TORINF_SLIM_ETDINSTR',       'Seq_TOR_DLY_ETD_INSTRUMENT'            , 
        'TORINF_SLIM_FXSTRADE',       'Seq_TOR_DLY_FX'                        , 
        'TORINF_SLIM_LDSTRADE',       'Seq_TOR_DLY_LD_Mortgages'              , 
        'TORINF_SLIM_OTCTRADE',       'Seq_TOR_DLY_OTC'                       , 
        'TORINF_SLIM_RPOTRADE',       'Seq_TOR_DLY_REPO'                      , 
        'TORINF_SLIM_SWPTRADE',       'Seq_TOR_DLY_SWAP'                      , 
        'TORINF_SLIM_TRADSALE',       'Seq_TOR_DLY_TRADSALE'                  , 
        'TORINF_SLIM_POSITION',       'Seq_TOR_Positions_Load'                , 
        'TORINF_SLIM_TRDSETTL',       'Seq_TOR_Settlements_Load'              , 
        'TORINF_SLIM_TRADEVAL',       'Seq_TOR_Valuations_Load'               , 
        'TORINF_SLIM_TRADEVAL',       'Seq_TOR_Valuations_Rerun'              , 
        'LDNGLOSS_SLIM_EQ_TRANS',     'seq_LON_SLIM_Gloss_EQ_Trades_Extract'  , 
        'slim_bookportfolio_rerun',   'Seq_TOR_Book_Portfolio_Rerun'          , 
        'GC_SLIM_RESPTRANSIT',        'seq_Load_Global_Client'                ,
        TN ) as "JOB_NAME"
,       TN as "TABLE_NAME" 
,       TO_CHAR(INPUT_TIME,  'DD-MM-YYYY HH24')  as "INPUT_TIME"  
,       TO_CHAR(PROCESS_RUN_ID, '999,999')  as "PROCESS_RUN_ID"  
,       sum(RC)   as        "row_count"
FROM ( 
  SELECT 'LDNINF_SLIM_CSHTRADE    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_CSHTRADE     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_CSHTRADE_PST'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_CSHTRADE_PST WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_CSHTRADE_TMP'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_CSHTRADE_TMP WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_ETDTRADE    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_ETDTRADE     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_ETDTRADE_PST'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_ETDTRADE_PST WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_ETDTRADE_TMP'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_ETDTRADE_TMP WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_FXSTRADE    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_FXSTRADE     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_FXSTRADE_PST'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_FXSTRADE_PST WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_FXSTRADE_TMP'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_FXSTRADE_TMP WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_LDSTRADE    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_LDSTRADE     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_LDSTRADE_PST'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_LDSTRADE_PST WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_LDSTRADE_TMP'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_LDSTRADE_TMP WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_OTCTRADE    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_OTCTRADE     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_OTCTRADE_PST'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_OTCTRADE_PST WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_OTCTRADE_TMP'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_OTCTRADE_TMP WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_POSITION    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_POSITION     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_SWPTRADE    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_SWPTRADE     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_SWPTRADE_PST'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_SWPTRADE_PST WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_SWPTRADE_TMP'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_SWPTRADE_TMP WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_TRADEVAL    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_TRADEVAL     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_TRADSALE    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_TRADSALE     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNINF_SLIM_TRDSETTL    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNINF_SLIM_TRDSETTL     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_CSHTRADE    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_CSHTRADE     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_CSHTRADE_PST'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_CSHTRADE_PST WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_CSHTRADE_TMP'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_CSHTRADE_TMP WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_ETDINSTR    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_ETDINSTR     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_ETDTRADE    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_ETDTRADE     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_ETDTRADE_PST'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_ETDTRADE_PST WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_ETDTRADE_TMP'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_ETDTRADE_TMP WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_FXSTRADE    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_FXSTRADE     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_FXSTRADE_PST'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_FXSTRADE_PST WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_FXSTRADE_TMP'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_FXSTRADE_TMP WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_LDSTRADE    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_LDSTRADE     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_LDSTRADE_PST'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_LDSTRADE_PST WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_LDSTRADE_TMP'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_LDSTRADE_TMP WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_OTCTRADE    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_OTCTRADE     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_OTCTRADE_PST'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_OTCTRADE_PST WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_OTCTRADE_TMP'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_OTCTRADE_TMP WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_POSITION    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_POSITION     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_RPOTRADE    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_RPOTRADE     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_RPOTRADE_PST'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_RPOTRADE_PST WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_RPOTRADE_TMP'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_RPOTRADE_TMP WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_SECTRADE    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_SECTRADE     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_SECTRADE_PST'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_SECTRADE_PST WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_SECTRADE_TMP'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_SECTRADE_TMP WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_SWPTRADE    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_SWPTRADE     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_SWPTRADE_PST'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_SWPTRADE_PST WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_SWPTRADE_TMP'   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_SWPTRADE_TMP WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_TRADEVAL    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_TRADEVAL     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_TRADSALE    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_TRADSALE     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'TORINF_SLIM_TRDSETTL    '   as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM TORINF_SLIM_TRDSETTL     WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'LDNGLOSS_SLIM_EQ_TRANS' as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM LDNGLOSS_SLIM_EQ_TRANS WHERE INPUT_TIME >(sysdate -10) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  --SELECT 'slim_bookportfolio_rerun' as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM slim_bookportfolio_rerun WHERE INPUT_TIME >(sysdate -10) GROUP BY INPUT_TIME, PROCESS_RUN_ID UNION ALL
  SELECT 'GC_SLIM_RESPTRANSIT' as "TN", INPUT_TIME, PROCESS_RUN_ID, count(*) as "RC" FROM GC_SLIM_RESPTRANSIT WHERE INPUT_TIME >(sysdate -20) GROUP BY INPUT_TIME, PROCESS_RUN_ID -- UNION ALL
)
GROUP BY DECODE( SUBSTR(TN,1,20),
        'LDNINF_SLIM_CSHTRADE',       'Seq_LON_DLY_Cash'                      , 
        'LDNINF_SLIM_ETDTRADE',       'Seq_LON_DLY_ETD'                       , 
        'LDNINF_SLIM_FXSTRADE',       'Seq_LON_DLY_FX'                        , 
        'LDNINF_SLIM_LDSTRADE',       'Seq_LON_DLY_LD_Mortgages'              , 
        'LDNINF_SLIM_OTCTRADE',       'Seq_LON_DLY_OTC'                       , 
        'LDNINF_SLIM_SWPTRADE',       'Seq_LON_DLY_SWAP_FRA'                  , 
        'LDNINF_SLIM_TRADSALE',       'Seq_LON_DLY_TRADSALE'                  , 
        'LDNINF_SLIM_POSITION',       'Seq_LON_Positions_Load'                , 
        'LDNINF_SLIM_TRDSETTL',       'Seq_LON_Settlements_Load'              , 
        'LDNINF_SLIM_TRADEVAL',       'Seq_LON_Valuations_Load'               , 
        'TORINF_SLIM_SECTRADE',       'Seq_TOR_DLY_BOND'                      , 
        'TORINF_SLIM_CSHTRADE',       'Seq_TOR_DLY_Cash'                      , 
        'TORINF_SLIM_ETDTRADE',       'Seq_TOR_DLY_ETD'                       , 
        'TORINF_SLIM_ETDINSTR',       'Seq_TOR_DLY_ETD_INSTRUMENT'            , 
        'TORINF_SLIM_FXSTRADE',       'Seq_TOR_DLY_FX'                        , 
        'TORINF_SLIM_LDSTRADE',       'Seq_TOR_DLY_LD_Mortgages'              , 
        'TORINF_SLIM_OTCTRADE',       'Seq_TOR_DLY_OTC'                       , 
        'TORINF_SLIM_RPOTRADE',       'Seq_TOR_DLY_REPO'                      , 
        'TORINF_SLIM_SWPTRADE',       'Seq_TOR_DLY_SWAP'                      , 
        'TORINF_SLIM_TRADSALE',       'Seq_TOR_DLY_TRADSALE'                  , 
        'TORINF_SLIM_POSITION',       'Seq_TOR_Positions_Load'                , 
        'TORINF_SLIM_TRDSETTL',       'Seq_TOR_Settlements_Load'              , 
        'TORINF_SLIM_TRADEVAL',       'Seq_TOR_Valuations_Load'               , 
        'TORINF_SLIM_TRADEVAL',       'Seq_TOR_Valuations_Rerun'              , 
        'LDNGLOSS_SLIM_EQ_TRANS',     'seq_LON_SLIM_Gloss_EQ_Trades_Extract'  , 
        'slim_bookportfolio_rerun',   'Seq_TOR_Book_Portfolio_Rerun'          , 
        'GC_SLIM_RESPTRANSIT',        'seq_Load_Global_Client'                ,
        TN )
,       TN
,       TO_CHAR(INPUT_TIME,  'DD-MM-YYYY HH24')  
,       TO_CHAR(PROCESS_RUN_ID, '999,999')


SELECT count(*) FROM GC_SLIM_RESPTRANSIT

SELECT 'TORINF_SLIM_LDSTRADE'   as "TN", INPUT_TIME, PROCESS_RUN_ID, BOOKCODE , replace(BOOKCODE,chr(0),'~'), count(*) as "RC" 
FROM TORINF_SLIM_LDSTRADE_TMP 
WHERE INPUT_TIME >(sysdate -10) 
AND   replace(BOOKCODE,chr(0),'~')  like '%~'
GROUP BY INPUT_TIME, BOOKCODE, replace(BOOKCODE,chr(0),'~'), PROCESS_RUN_ID 

select replace(a,chr(0),'s') from t1;


