

sp_who etladm

sp_lock 854

sp_dboption

select @@version

use tempdb
use gcplus_dev
use gcplus_preprod

SELECT '  CLIENT_ARRANGEMENT_PROPERTY  ' as 'table_name', count(*) as 'row_count' FROM    CLIENT_ARRANGEMENT_PROPERTY      UNION ALL
SELECT '  CLIENT_REGULATORY_IDENTIFIER ' as 'table_name', count(*) as 'row_count' FROM    CLIENT_REGULATORY_IDENTIFIER     UNION ALL
SELECT 'vwCLIENT_ARRANGEMENT_PROPERTY  '  as 'table_name', count(*) as 'row_count' FROM  vwCLIENT_ARRANGEMENT_PROPERTY     UNION ALL
SELECT 'vwCLIENT_REGULATORY_IDENTIFIER '  as 'table_name', count(*) as 'row_count' FROM  vwCLIENT_REGULATORY_IDENTIFIER    --UNION ALL

SELECT  name     as    "object_name"
,       type     as    "object_type"
,       crdate   as    "creation_date"
,       'tempdb..' + name     as    "temp table name"
FROM  sysobjects
WHERE type in ('U','V','P')
--AND  name like 'vwCLIENT%'
ORDER BY type, name

-- List all tables and their columns contain a certain column name or tbale name string :

SELECT Table_name = isnull(o.name, 'NULL')
,      Column_name = isnull(c.name, 'NULL')
,       Col_order = colid
,       Type = t.name
,       Length = c.length
,       Prec = c.prec
,       Scale = c.scale
,       Nulls = convert(bit, (c.status & 8))
--,       c.*
FROM  syscolumns c, systypes t, sysobjects o
WHERE c.id = o.id
AND   c.usertype = t.usertype  --AND   c.usertype *= t.usertype
AND   o.type = 'U'
--AND   t.name = 'date'
--AND   o.name like "acc"
--AND   o.name in ('al_collateral_movement','al_pool','al_profit_centre','al_stock')
ORDER BY isnull(o.name, 'NULL'), colid

-- check data dates:

SELECT ' ' as 'CDR_DB', ' ' as 'TABLE', getdate() as 'MAX_UPDATE' WHERE 1=2                     UNION ALL   --\n\
SELECT 'gcplus_preprod', 'vwCDR_ADDRESS' , convert(char(20),  max(UPDATE_DATE), 100) FROM gcplus_preprod..vwCDR_ADDRESS  UNION ALL   --\n\
SELECT 'gcplus_uat'    , 'vwCDR_ADDRESS' , substring(max(UPDATE_DATE),1,20) FROM gcplus_uat..vwCDR_ADDRESS      UNION ALL   --\n\
SELECT 'gcplus_dev'    , 'vwCDR_ADDRESS' , max(UPDATE_DATE) FROM gcplus_dev..vwCDR_ADDRESS      UNION ALL   --\n\
SELECT 'gcplus'        , 'vwCDR_ADDRESS' , max(UPDATE_DATE) FROM gcplus..vwCDR_ADDRESS          --UNION ALL   --\n\

SELECT 'vwCLIENT                 ' AS "TABLE", max(CREATE_DATE) as "MAX_CREATION" , max(UPDATE_DATE) as "MAX_UPDATE" FROM vwCLIENT                  UNION ALL
SELECT 'vwCLIENT_ARRANGEMENT     ' AS "TABLE", max(CREATE_DATE) as "MAX_CREATION" , max(UPDATE_DATE) as "MAX_UPDATE" FROM vwCLIENT_ARRANGEMENT      UNION ALL
SELECT 'vwCLIENT_ARRANGEMENT_LINK' AS "TABLE", max(CREATE_DATE) as "MAX_CREATION" , max(UPDATE_DATE) as "MAX_UPDATE" FROM vwCLIENT_ARRANGEMENT_LINK UNION ALL

SELECT 'vwCDR_ADDRESS            ' AS "TABLE", max(CREATE_DATE) as "MAX_CREATION" , max(UPDATE_DATE) as "MAX_UPDATE" FROM vwCDR_ADDRESS             -- UNION ALL


SELECT GLOSS.CLIENT_ARR_SHORT_NAME ,CHAR_LENGTH(GLOSS.CLIENT_ARR_SHORT_NAME) as "SN_CHAR_LENGTH"
FROM   vwCLIENT_ARRANGEMENT GLOSS
WHERE GLOSS.APPLICATION_USE in ('GLSLNDBCPT', 'GLSLNEQCPT','GLSLNDBISR','GLOSSMMKT')
and  GLOSS.STATUS_CODE = 'ACTIV' 
AND  GLOSS.CLIENT_ARR_SHORT_NAME like '%2013452%'

AND NOT  (GLOSS.CLIENT_ARR_SHORT_NAME LIKE '201%' AND CHAR_LENGTH(GLOSS.CLIENT_ARR_SHORT_NAME) = 10  )
AND   (GLOSS.CLIENT_ARR_SHORT_NAME LIKE '201%' AND CHAR_LENGTH(GLOSS.CLIENT_ARR_SHORT_NAME) = 10  )

SELECT GLOSS.CLIENT_ARR_SHORT_NAME ,CHAR_LENGTH(GLOSS.CLIENT_ARR_SHORT_NAME) as "SN_CHAR_LENGTH"
from vwCLIENT_ARRANGEMENT      GLOSS
left join vwCLIENT_EXTERNAL_ID CAP        on (GLOSS.CLIENT_ID = CAP.CLIENT_ID               and CAP.SOURCE_CODE='ATACR')
join vwCLIENT                  CL         on (GLOSS.CLIENT_ID = CL.CLIENT_ID   )
left join vwCDR_ADDRESS        CAD        on (GLOSS.CLIENT_ID = CAD.CLIENT_ID               and CAD.ADDRESS_TYPE_CODE='DOM')
--
left join vwCLIENT_ARRANGEMENT_LINK CAL   on ( GLOSS.CLIENT_ARR_ID=CAL.CL_ARR_PARTY2_ID and CAL.CL_ARR_LINK_TYPE_CODE ='AcSettlAc' 
          and CAL.CL_ARR_PARTY1_ID in   (select CLIENT_ARR_ID from vwCLIENT_ARRANGEMENT where STATUS_CODE = 'ACTIV' 
                  and APPLICATION_USE in ( 'ARTSACCT','BATSACCTID','FIDEUKACC','GBOIACCT','GCPISSUER','LNINFINI','MONACOCLNT','TOMSFIRMAC')) ) 
left join vwCLIENT_ARRANGEMENT      CA    on ( CA.CLIENT_ARR_ID=CAL.CL_ARR_PARTY1_ID   and   CA.STATUS_CODE = 'ACTIV' )
left join APPLICATION_USE         AU    on ( CA.APPLICATION_USE = AU.APP_USE_CODE  )
WHERE GLOSS.APPLICATION_USE in ('GLSLNDBCPT', 'GLSLNEQCPT','GLSLNDBISR','GLOSSMMKT')
and  GLOSS.STATUS_CODE = 'ACTIV' 
AND  GLOSS.CLIENT_ARR_SHORT_NAME in ('2013452798')

AND  (GLOSS.CLIENT_ARR_SHORT_NAME LIKE '201%' AND CHAR_LENGTH(GLOSS.CLIENT_ARR_SHORT_NAME) = 10  )

SELECT DISTINCT  CONVERT(char(25), UPPER(ISNULL(CA.CLIENT_ARR_SHORT_NAME       ,'')))    as Short_Name                
,        CONVERT(char(50), UPPER(ISNULL(CL.DISPLAY_NAME                 ,'')))    as Long_Name                  
,        CONVERT(char(100),UPPER(ISNULL(space(10)                       ,'')))    as Extended_Long_Name 
,        CONVERT(char(50), UPPER(ISNULL(CAD.ADDRESS_LINE1               ,'')))    as Address_Line1                    
,        CONVERT(char(50), UPPER(ISNULL(CAD.ADDRESS_LINE2               ,'')))    as Address_Line2                    
,        CONVERT(char(50), UPPER(ISNULL(CAD.ADDRESS_LINE3               ,'')))    as Address_Line3                    
,        CONVERT(char(25), UPPER(ISNULL(CAD.POSTAL_CODE                 ,'')))    as Postal_Code                      
,        CONVERT(char(10), UPPER(ISNULL(CAD.COUNTRY_SHORT_CODE          ,'')))    as Country                 
,        CONVERT(char(10), UPPER(ISNULL(CAD.CITY                        ,'')))    as Location    
,        CONVERT(char(25), UPPER(ISNULL(CA1.CLIENT_ARR_SHORT_NAME        ,'')))    as Parent_Company_Reference   
,        CONVERT(char(10), UPPER(ISNULL(CA.STATUS_CODE                 ,'')))    as Status                     
,        CONVERT(char(10), UPPER(ISNULL(space(10)                       ,'')))    as Counterparty_Type          
,        CONVERT(char(25), UPPER(ISNULL(CONVERT(char(20),CL.CLIENT_ID)  ,'')))    as UniqueClientCodeRef         
,        CONVERT(char(100),UPPER(ISNULL(CL.LEGAL_NAME                   ,'')))    as Legal_Name                  
,        CONVERT(char(25), UPPER(ISNULL(CA1.CLIENT_ARR_SHORT_NAME        ,'')))    as Artsparent_Short_Name
,        CA2.APPLICATION_USE                                                      as  Application_Use
--
--,     CONVERT(char(50), UPPER(ISNULL(AU.APP_USE_DESC                ,'')))     'APPLICATION_USE_DESC_ARR'   
,       CONVERT(char(50),UPPER(           
            CASE CA2.APPLICATION_USE
                WHEN 'ADPCAACNUM' THEN 'ADP CANADA'        
                WHEN 'ADPUSACNUM' THEN 'GLOSS LNEQ'     
                WHEN 'GLSLNEQCPT' THEN 'ADP US' 
                WHEN 'OPICSMNEMO' THEN 'OPICS'   
             ELSE ' ' END  ))                                                    'APPLICATION_USE_DESC_ARR'
,       CONVERT(char(50), UPPER(ISNULL(CA2.CLIENT_ARR_SHORT_NAME       ,'')))    'APP_SHORT_NAME_ARR'        
FROM vwCLIENT_ARRANGEMENT      CA   
JOIN vwCLIENT CL               ON (CL.CLIENT_ID = CA.CLIENT_ID )
left JOIN vwCDR_ADDRESS        CAD ON (CA.CLIENT_ID = CAD.CLIENT_ID            and CAD.ADDRESS_TYPE_CODE='DOM')
left join vwCLIENT_ARRANGEMENT_LINK CAL1 on (CA.CLIENT_ARR_ID=CAL1.CL_ARR_PARTY2_ID   and CAL1.CL_ARR_LINK_TYPE_CODE='ClAcc' 
          and CAL1.CL_ARR_PARTY1_ID in   (select CLIENT_ARR_ID from vwCLIENT_ARRANGEMENT where APPLICATION_USE in ( 'ARTSPARENT') and STATUS_CODE = 'ACTIV'  ) ) 
left join vwCLIENT_ARRANGEMENT CA1  ON (CA1.CLIENT_ARR_ID=CAL1.CL_ARR_PARTY1_ID          and CA1.APPLICATION_USE   ='ARTSPARENT'   and CA1.STATUS_CODE = 'ACTIV')
--
left join vwCLIENT_ARRANGEMENT_LINK CAL2 on (CA.CLIENT_ARR_ID=CAL2.CL_ARR_PARTY1_ID and CAL2.CL_ARR_LINK_TYPE_CODE='AcSettlAc'
          and CAL2.CL_ARR_PARTY2_ID in   (select CLIENT_ARR_ID from vwCLIENT_ARRANGEMENT where APPLICATION_USE in ('ADPCAACNUM','ADPUSACNUM','GLSLNEQCPT','OPICSMNEMO') and STATUS_CODE = 'ACTIV'  ) ) 
left join vwCLIENT_ARRANGEMENT      CA2  on (CA2.CLIENT_ARR_ID=CAL2.CL_ARR_PARTY2_ID                                    and CA2.STATUS_CODE = 'ACTIV')
--left join vwAPPLICATION_USE         AU   on (CA2.APPLICATION_USE = AU.APP_USE_CODE )
WHERE CA.APPLICATION_USE     = 'ARTSACCT' 
and  CA.STATUS_CODE = 'ACTIV'

SELECT CL_ARR_PARTY1_ID, CL_ARR_PARTY2_ID 
INTO #cal_rework
FROM vwCLIENT_ARRANGEMENT_LINK CAL    
WHERE 1 = 2

TRUNCATE TABLE #cal_rework

INSERT #cal_rework
SELECT CL_ARR_PARTY1_ID, CL_ARR_PARTY2_ID 
FROM vwCLIENT_ARRANGEMENT_LINK CAL    
WHERE CL_ARR_LINK_TYPE_CODE ='AcSettlAc' 
and CAL.CL_ARR_PARTY1_ID in  (select CLIENT_ARR_ID from vwCLIENT_ARRANGEMENT where STATUS_CODE = 'ACTIV' 
                  and APPLICATION_USE in ( 'ARTSACCT','BATSACCTID','FIDEUKACC','GBOIACCT','GCPISSUER','LNINFINI','MONACOCLNT','TOMSFIRMAC'))
and CAL.CL_ARR_PARTY2_ID in  (select CLIENT_ARR_ID from vwCLIENT_ARRANGEMENT where STATUS_CODE = 'ACTIV' 
                  and APPLICATION_USE in ( 'GLSLNDBCPT', 'GLSLNEQCPT','GLSLNDBISR','GLOSSMMKT'))
UNION ALL
SELECT CL_ARR_PARTY2_ID "CL_ARR_PARTY1_ID", CL_ARR_PARTY1_ID "CL_ARR_PARTY2_ID"
FROM vwCLIENT_ARRANGEMENT_LINK CAL    
WHERE CL_ARR_LINK_TYPE_CODE ='AcSettlAc'
and CAL.CL_ARR_PARTY2_ID in  (select CLIENT_ARR_ID from vwCLIENT_ARRANGEMENT where STATUS_CODE = 'ACTIV' 
                  and APPLICATION_USE in ( 'ARTSACCT','BATSACCTID','FIDEUKACC','GBOIACCT','GCPISSUER','LNINFINI','MONACOCLNT','TOMSFIRMAC'))
and CAL.CL_ARR_PARTY1_ID in  (select CLIENT_ARR_ID from vwCLIENT_ARRANGEMENT where STATUS_CODE = 'ACTIV' 
                  and APPLICATION_USE in ( 'GLSLNDBCPT', 'GLSLNEQCPT','GLSLNDBISR','GLOSSMMKT'))

SELECT  count(*) FROM #cal_rework

DELETE -- SELECT * INTO #cal_rework2
FROM #cal_rework WHERE convert(varchar,CL_ARR_PARTY1_ID) || convert(varchar,CL_ARR_PARTY2_ID) in (
SELECT convert(varchar,CL_ARR_PARTY1_ID) || convert(varchar,CL_ARR_PARTY2_ID) --, count(*) 
FROM #cal_rework
GROUP BY CL_ARR_PARTY1_ID, CL_ARR_PARTY2_ID 
HAVING count(*) > 1 
)

--SELECT  count(*) FROM #cal_rework2

SELECT   CONVERT(char(25), UPPER(ISNULL(GLOSS.CLIENT_ARR_SHORT_NAME     ,'')))    as Short_Name                 
,        CONVERT(char(50), UPPER(ISNULL(GLOSS.DISPLAY_NAME              ,'')))    as Long_Name                  
,        CONVERT(char(100),UPPER(ISNULL(CL.ISO_LEGAL_NAME               ,'')))    as Extended_Long_Name            
,        CONVERT(char(50), UPPER(ISNULL(CAD.ADDRESS_LINE1               ,'')))    as Address_Line1                    
,        CONVERT(char(50), UPPER(ISNULL(CAD.ADDRESS_LINE2               ,'')))    as Address_Line2                    
,        CONVERT(char(50), UPPER(ISNULL(CAD.ADDRESS_LINE3               ,'')))    as Address_Line3                    
,        CONVERT(char(25), UPPER(ISNULL(CAD.POSTAL_CODE                 ,'')))    as Postal_Code                      
,        CONVERT(char(25), UPPER(ISNULL(CAD.SUBCOUNTRY_CODE             ,'')))    as Address_Line4                  
,        CONVERT(char(10), UPPER(ISNULL(CAD.COUNTRY_SHORT_CODE          ,'')))    as Country                    
,        CONVERT(char(25), UPPER(ISNULL(CAD.CITY                        ,'')))    as Location                   
,        CONVERT(char(25), UPPER(ISNULL(CONVERT(char(12),CH.FIRST_LEGAL_PARENT_ID)  ,'')))    as Parent_Company_Reference   
,        CONVERT(char(25), UPPER(ISNULL(CRI.CLIENT_REGULATORY_ID        ,'')))    as FSA_Ref_No                       
,        CONVERT(char(25), UPPER(ISNULL(CAP2.EXT_ID_VALUE               ,'')))    as SWIFT_BIC_Code               
,        CONVERT(char(10), UPPER(ISNULL(' '                             ,'')))    as LSE_Member_Flag            
,        CONVERT(char(25), UPPER(ISNULL(CAP.EXT_ID_VALUE                ,'')))    as Alert_Acronym              
,        CONVERT(char(10), UPPER(ISNULL(GLOSS.STATUS_CODE               ,'')))    as Status                     
,        CONVERT(char(10), UPPER(ISNULL(space(10)                       ,'')))    as Counterparty_Type          
,        CONVERT(char(25), UPPER(ISNULL(CONVERT(char(20),CL.CLIENT_ID)  ,'')))    as UniqueClientCodeRef         
,        CONVERT(char(100),UPPER(ISNULL(' '                             ,'')))    as Legal_Name
--,       CONVERT(char(50), UPPER(ISNULL(AU.APP_USE_DESC                ,'')))      as APPLICATION_USE_DESC_ARR
,       CONVERT(char(50),UPPER(           
            CASE CA.APPLICATION_USE
                WHEN 'ARTSACCT'   THEN 'ARTS'        
                WHEN 'BATSACCTID' THEN 'BATS'     
                WHEN 'FIDEUKACC'  THEN 'GBOI/FID' 
                WHEN 'GBOIACCT'   THEN 'GBOI/FID'   
                WHEN 'GCPISSUER'  THEN 'GCP'      
                WHEN 'LNINFINI'   THEN 'INFL'     
                WHEN 'MONACOCLNT' THEN 'MONACO'  
                WHEN 'TOMSFIRMAC' THEN 'TOMS'    
             ELSE ' ' END  ))                                                         'APPLICATION_USE_DESC_ARR'
,       CONVERT(char(25), UPPER(ISNULL(CA.CLIENT_ARR_SHORT_NAME       ,'')))      as APP_SHORT_NAME_ARR

SELECT  UPPER(ISNULL(GLOSS.CLIENT_ARR_SHORT_NAME     ,''))    as Short_Name                 
,        GLOSS.APPLICATION_USE  
--,        UPPER(ISNULL(GLOSS.DISPLAY_NAME              ,''))    as Long_Name                  
--,        UPPER(ISNULL(CL.ISO_LEGAL_NAME               ,''))    as Extended_Long_Name            
--,        UPPER(ISNULL(CAP2.EXT_ID_VALUE                ,''))    as SWIFT_BIC_Code              
,        UPPER(ISNULL(CAP.EXT_ID_VALUE                ,''))    as Alert_Acronym              
--,        UPPER(ISNULL(GLOSS.STATUS_CODE               ,''))    as Status                     
,        UPPER(ISNULL(CONVERT(char(20),CL.CLIENT_ID)  ,''))    as UniqueClientCodeRef
--,         CA.APPLICATION_USE
--,         CA.CLIENT_ARR_SHORT_NAME   
from vwCLIENT_ARRANGEMENT      GLOSS
--left join #cl_hier_2           CH         on (GLOSS.CLIENT_ID = CH.CLIENT_ID  )
--left join vwCLIENT_REGULATORY_IDENTIFIER CRI ON ( CH.FIRST_LEGAL_PARENT_ID = CRI.CLIENT_ID  and CRI.REGULATORY_INSTITUTION='FSARg')
 join vwCLIENT_EXTERNAL_ID CAP        on (GLOSS.CLIENT_ID = CAP.CLIENT_ID               and CAP.SOURCE_CODE='ATACR')
--left join vwCLIENT_EXTERNAL_ID CAP2       on (CH.FIRST_LEGAL_PARENT_ID = CAP2.CLIENT_ID    and CAP2.SOURCE_CODE='SWIFT')
join vwCLIENT                  CL         on (GLOSS.CLIENT_ID = CL.CLIENT_ID   )
--left join vwCDR_ADDRESS        CAD        on (GLOSS.CLIENT_ID = CAD.CLIENT_ID               and CAD.ADDRESS_TYPE_CODE='DOM')
--left join #cal_rework CAL                 on ( GLOSS.CLIENT_ARR_ID=CAL.CL_ARR_PARTY2_ID )
--left join vwCLIENT_ARRANGEMENT    CA      on ( CA.CLIENT_ARR_ID=CAL.CL_ARR_PARTY1_ID        and CA.STATUS_CODE = 'ACTIV' )
WHERE GLOSS.APPLICATION_USE in ('GLSLNDBCPT', 'GLSLNEQCPT','GLSLNDBISR','GLOSSMMKT')
and  GLOSS.STATUS_CODE = 'ACTIV' 
AND CL.CLIENT_ID in ( -- (9823) --5175 
SELECT CLIENT_ID FROM vwCLIENT_EXTERNAL_ID CAP 
WHERE  CAP.SOURCE_CODE='ATACR'
GROUP BY CLIENT_ID	 HAVING count(*) > 1 
)

-- AND CA.APPLICATION_USE IS NOT NULL

--AND  NOT (GLOSS.CLIENT_ARR_SHORT_NAME LIKE '201%' AND CHAR_LENGTH(GLOSS.CLIENT_ARR_SHORT_NAME) = 10  )

SELECT * FROM vwCLIENT_EXTERNAL_ID CAP 
WHERE  CAP.SOURCE_CODE='ATACR'
AND  CAP.CLIENT_ID  in --(9823)
(
SELECT CLIENT_ID FROM vwCLIENT_EXTERNAL_ID CAP 
WHERE  CAP.SOURCE_CODE='ATACR'
GROUP BY CLIENT_ID	 HAVING count(*) > 1
)




