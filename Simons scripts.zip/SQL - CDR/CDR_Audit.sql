
SELECT @@version

use tempdb
use cdr_recon_audit_dev
use cdr_recon_audit_uat

sp_help 

select * from ETL_SourceSystem WHERE SS_Timestamp > dateadd(dd, -120, GETDATE())

select * from ETL_RunStatus  

select * from ETL_RunControl WHERE RC_StartDateTime > dateadd(dd, -2, GETDATE())

select * from ETL_AuditCounts WHERE AC_Timestamp > dateadd(dd, -2, GETDATE())

SELECT  *-- count(*) -- DELETE 
--FROM ETL_AuditCounts WHERE AC_RC_RunID in (SELECT RC_RunID FROM ETL_RunControl WHERE RC_SS_ID  BETWEEN 51 AND 58 ) 
--FROM ETL_RunControl WHERE RC_SS_ID BETWEEN 51 AND 58 
FROM ETL_SourceSystem 
WHERE SS_ID BETWEEN 51 AND 58 -- 10000004  AND 10000005 
--AND UPPER(SS_Name) like '%GB%' 
-- SS_ID BETWEEN 16 AND 32 -- AND SS_ID <> 23

set identity_insert ETL_SourceSystem on

--UPDATE ETL_SourceSystem SET SS_Type='F' , SS_FileName='CDRRecon_ICI_YYYYMMDD.txt' WHERE SS_ID = 16
UPDATE ETL_SourceSystem SET SS_FileName='CDRRecon_ICIIMPACT_YYYYMMDD.txt' WHERE SS_ID = 16 -- SS_Type='F' , 
UPDATE ETL_SourceSystem SET SS_Name='CDRLoanetCore', SS_FileName=''  WHERE SS_ID = 31 
UPDATE ETL_SourceSystem SET SS_Name='LoanetCore',    SS_FileName='CDRRecon_LOANET_YYYYMMDD.txt' WHERE SS_ID = 32 

UPDATE ETL_SourceSystem SET SS_FileName='BDR_Infinity_Tor_YYYYMMDD.ppe' WHERE SS_ID = 101 -- , SS_Name='RITor'
UPDATE ETL_SourceSystem SET SS_FileName='BDR_Infinity_Lon_YYYYMMDD.ppe' WHERE SS_ID = 103 -- , SS_Name='RILon'

UPDATE ETL_SourceSystem SET SS_Name='MUREXFXO' WHERE SS_ID = 111 -- , SS_FileName='.ppe'
UPDATE ETL_SourceSystem SET SS_Name='BDRMUREXFXO' WHERE SS_ID = 112 -- , SS_FileName=''


SELECT   convert(char(3),SS_ID)                                      as  'SS'
,        convert(char(14),SS_Name)                                   as  'SS_Name'
,        CASE SS_Type WHEN 'T' THEN 'TABLE' ELSE 'FILE' END          as  'Type'
,        convert(char(35),SS_FileName)                               as  'SS_FileName'
,        RC_RunID                                                    as  'RunID'
--,        convert(char(5),RC_RS_ID)                                   as  'RS_ID'
,        convert(char(10),RC_BusinessDate    )                       as  'Bus_Date'
,        convert(char(8),RS_Desc)                                   as  'Status'
,        convert(char(8),RC_StartDateTime, 112)                      as  'RunDate'
,        substring(convert(char(8),RC_StartDateTime, 108),1,5)       as  'Start'
--,        substring(convert(char(8),RC_FinishDateTime, 108),1,5)      as  'Finish     '
,        convert(varchar(8),dateadd(ss,datediff(ss,RC_StartDateTime, RC_FinishDateTime), '1/1/1900'),108)  as  'Elapsed'
--,        datediff(ss,RC_StartDateTime, RC_FinishDateTime)            as  'Elapsed_SS'
,        AC_SourceRecCount                                           as  'Src_rows'
,        AC_TargetRecCount                                           as  'Tgt'
,        AC_RejectCount                                              as  'Rejected'
,        AC_SourceRecCount - AC_TargetRecCount                       as  'Filtered?'
--,        round(AC_TargetRecCount / datediff(ss,RC_StartDateTime, RC_FinishDateTime),1)  as  'Rows_per_sec'
--SELECT *
FROM ETL_SourceSystem 
,    ETL_RunControl 
,    ETL_RunStatus 
,    ETL_AuditCounts 
WHERE SS_ID       = RC_SS_ID 
AND   RS_ID       = RC_RS_ID 
AND   RC_RunID    *= AC_RC_RunID
--AND   ( UPPER(SS_Name) like '%GBARR%' OR UPPER(SS_Name) like '%EBS%' OR UPPER(SS_Name) like '%RIMM%' OR UPPER(SS_Name) like '%NADB%' OR UPPER(SS_Name) like '%RNOL%'  ) -- ADP%Core% AND   RC_StartDateTime > dateadd(DD, -120, GETDATE()) -- AND SS_ID in (127) --(15,16)
AND   RC_StartDateTime > dateadd(DD, -5, GETDATE())  -- AND  SS_Timestamp > dateadd(dd, -5, GETDATE())
--AND RC_RunID in (SELECT max(RC_RunID) FROM ETL_RunControl GROUP BY RC_SS_ID )
AND  SS_ID < 100 --<> 5000002
ORDER BY RC_RunID DESC -- SS_Name, SS_Type, RC_RunID -- RC_RunID

SELECT no= 1  into #2

SELECT  name     as    "object_name"
--#,       type     as    "object_type"
,       crdate   as    "creation_date"
,       'tempdb..' + name     as    "temp table name"
FROM  sysobjects
WHERE type in ('U','V','P')
ORDER BY type, name

SELECT replicate(' ',30)

SET IDENTITY_INSERT ETL_SourceSystem ON

IF NOT EXISTS ( SELECT * FROM ETL_SourceSystem WHERE SS_ID BETWEEN 101 AND 106)
   BEGIN    
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (101, 'RITor',       'F','BDRRecon_RITOR_YYYYMMDD.txt','D',GETDATE())            
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (102, 'BDRRITor',    'T','','D',GETDATE())                                       
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (103, 'RILon',       'F','BDRRecon_RILON_YYYYMMDD.txt','D',GETDATE())            
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (104, 'BDRRILon',    'T','','D',GETDATE())                                       
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (105, 'CI',          'F','BDR_CI_Lon_YYYYMMDD.ppe','D',GETDATE())   
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (106, 'BDRCI',       'T','','D',GETDATE())                           
  END

SET IDENTITY_INSERT ETL_SourceSystem OFF
GO
IF NOT EXISTS ( SELECT * FROM ETL_SourceSystem WHERE SS_ID BETWEEN 107 AND 112)
   BEGIN    
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (107, 'FIDESSA_US',    'F','BDR_FIDESSA_US.csv','D',GETDATE())                             
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (108, 'BDRFIDESSA_US', 'T','','D',GETDATE())                                               
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (109, 'ELTA',          'F','BDR_Elta_YYYYMMDD.txt','D',GETDATE())                          
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (110, 'BDRELTA',       'T','','D',GETDATE())                                               
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (111, 'MUREX',         'F','MUREX_ZLT0_BookAccessReport_FXO.CSV','D',GETDATE()) 
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (112, 'BDRMUREX',      'T','','D',GETDATE())                                    
  END

SET IDENTITY_INSERT ETL_SourceSystem OFF


SET IDENTITY_INSERT ETL_SourceSystem ON

IF NOT EXISTS ( SELECT * FROM ETL_SourceSystem WHERE SS_ID BETWEEN 107 AND 122)
   BEGIN    
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (107, 'FIDESSA_US',   'F','BDR_FIDESSA_US_YYYYMMDD.csv','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (108, 'BDRFIDESSA_US','T','','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (111, 'MUREXFXO',     'F','YQY0_BookAccessReport_TOR_YYYYMMDD.csv','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (112, 'BDRMUREXFXO',  'T','','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (113, 'MONACO',       'F','BDR_Monaco_YYYYMMDD.txt ','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (114, 'BDRMONACO',    'T','','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (117, 'TOMSRBCN',     'F','BDR_TOMS_RBCN_YYYYMMDD.txt ','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (118, 'BDRTOMSRBCN',  'T','','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (119, 'TOMSRBCE',     'F','BDR_TOMS_RBCE_YYYYMMDD.txt ','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (120, 'BDRTOMSRBCE',  'T','','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (121, 'FIDESSA_CA',   'F','BDR_FIDESSA_CA_YYYYMMDD.psv','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (122, 'BDRFIDESSA_CA','T','','D',GETDATE())
  END

SET IDENTITY_INSERT ETL_SourceSystem OFF
GO

--August release:

SET IDENTITY_INSERT ETL_SourceSystem ON

IF NOT EXISTS ( SELECT * FROM ETL_SourceSystem WHERE SS_ID BETWEEN 137 AND 138)
   BEGIN    
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (137, 'FIDESSA_LDN',        'F', 'BDR_FIDESSA_LON_YYYYMMDD.ppe','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (138, 'BDRFIDESSA_LDN',     'T', '','D',GETDATE())
   END
SET IDENTITY_INSERT ETL_SourceSystem OFF

set identity_insert ETL_SourceSystem on

set identity_insert ETL_SourceSystem on

DELETE FROM ETL_SourceSystem WHERE SS_ID in (39,40)

--IF NOT EXISTS ( SELECT * FROM ETL_SourceSystem WHERE SS_ID in (37,38,39,40,41,42) )
IF NOT EXISTS ( SELECT * FROM ETL_SourceSystem WHERE SS_ID in (39,40,41,42) )
   BEGIN    
--INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (37, 'CDRBATSCore',    'T','','D',GETDATE())                                 
--INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (38, 'BATSCore',       'T','','D',GETDATE())                                        
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (39, 'CDRMONACOArr',  'T','','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (40, 'CDRMONACOCore', 'T','','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (41, 'MONACOArr',     'F','CDR_MONACO_YYYYMMDD.ppe','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (42, 'MONACOCore',    'F','CDR_MONACO_YYYYMMDD.ppe','D',GETDATE())
END                                                                                      
SET IDENTITY_INSERT ETL_SourceSystem OFF
GO


IF NOT EXISTS ( SELECT * FROM ETL_SourceSystem WHERE SS_ID in (139,140) )
   BEGIN    
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (139, 'OPENLINK',    'F','YVO0_Books_Access_YYYYMMDD.csv','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (140, 'BDROPENLINK', 'T','','D',GETDATE())
   END
SET IDENTITY_INSERT ETL_SourceSystem OFF

set identity_insert ETL_SourceSystem on

IF NOT EXISTS ( SELECT * FROM ETL_SourceSystem WHERE SS_ID BETWEEN 43 AND 52  )
   BEGIN    
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (43, 'CDRRNOLANCore',   'T','','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (44, 'RNOLANCore',      'F','CDRRecon_ADPCanada_YYYYMMDD.txt','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (45, 'CDRNADBCore',     'T','','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (46, 'NADBCore',        'F','CDRRecon_ADPCanada_YYYYMMDD.txt','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (47, 'CDREBSLDNCore', 'T','','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (48, 'EBSLDNCore',    'F','CDRRecon_EBS_YYYYMMDD.TXT','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (49, 'CDRRIMMSCore',    'T','','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (50, 'RIMMSCore',       'F','CDRRecon_RIMMS_YYYYMMDD.TXT','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (51, 'CDRRIBSCore',     'T','','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (52, 'RIBSCore',        'F','CDRRecon_RIBS_MERGED_YYYYMMDD.txt','D',GETDATE())
END                                                                                      
SET IDENTITY_INSERT ETL_SourceSystem OFF
GO

SET IDENTITY_INSERT ETL_SourceSystem ON
GO
IF NOT EXISTS ( SELECT * FROM ETL_SourceSystem WHERE SS_ID BETWEEN 53 AND 56  )
   BEGIN    
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (53, 'CDRGBOIClient',       'T', '','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (54, 'GBOIClient',          'F', 'CDRRecon_GBOI_XXXX_YYYYMMDD.txt','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (55, 'CDRGBOISubA',         'T', '','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (56, 'GBOISubA',            'F', 'CDRRecon_GBOI_XXXX_YYYYMMDD.txt','D',GETDATE())
  END                                                                                      
SET IDENTITY_INSERT ETL_SourceSystem OFF
GO

--INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (49, 'CDROPENLINKCore', 'T','','D',GETDATE())
--INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (50, 'OPENLINKCore',    'F','CDRRecon_ADPCanada_YYYYMMDD.txt','D',GETDATE())

UPDATE ETL_SourceSystem SET SS_FileName='CDRRecon_RNolan_YYYYMMDD.txt' WHERE SS_Name = 'RNOLANCore'
UPDATE ETL_SourceSystem SET SS_FileName='CDRRecon_NADB_YYYYMMDD.ppe'   WHERE SS_Name = 'NADBCore'

UPDATE ETL_SourceSystem SET SS_FileName='CDRRecon_RIBS_MERGED_YYYYMMDD.txt' WHERE SS_Name='RIBSCore' 



CREATE TABLE #C (A int) 

INSERT INTO #C VALUES ( 1) 
INSERT INTO #C VALUES ( 2) 
INSERT INTO #C VALUES ( 3) 
INSERT INTO #C VALUES ( 4) 

DROP TABLE #P
DROP TABLE #S

SELECT * INTO #P FROM #C WHERE A in (1,4) 
SELECT * INTO #S FROM #C WHERE A in (2,4)

SELECT CONVERT(CHAR,#P.A) + ' P'   as 'A'  FROM #P
UNION  
SELECT CONVERT(CHAR,#C.A) + ' C'   as 'A'  FROM #C
UNION  
SELECT CONVERT(CHAR,#S.A) + ' S'   as 'A'  FROM #S


SELECT  * FROM #X

SELECT #P.A   as 'P'
,      #C.A   as 'C'
,      #S.A   as 'S'
FROM   #C 
LEFT JOIN #P ON (#C.A = #P.A)
LEFT JOIN #S ON (#C.A = #S.A)

SELECT #P.A   as 'P'
,      #C.A   as 'C'
,      #S.A   as 'S'
FROM   #C 
LEFT JOIN (SELECT A FROM #P ) as #P ON (#C.A = #P.A)
LEFT JOIN #S ON (#C.A = #S.A)



set identity_insert ETL_SourceSystem on

IF NOT EXISTS ( SELECT * FROM ETL_SourceSystem WHERE SS_ID in (25,26,27,28,37,38) )
   BEGIN    
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (25, 'CDRADPCACore',     'T','','D',GETDATE())                                                
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (26, 'ADPCACore',        'F','CDRRecon_ADPCanada_YYYYMMDD.txt','D',GETDATE())                 
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (27, 'CDRADPUSCore',     'T','','D',GETDATE())                                                
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (28, 'ADPUSCore',        'F','CDRRecon_ADPUS_YYYYMMDD.txt','D',GETDATE())                     
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (37, 'CDRBATSCore',      'T','','D',GETDATE())                                 
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (38, 'BATSCore',         'T','','D',GETDATE())                                        
END                                                                                      
SET IDENTITY_INSERT ETL_SourceSystem OFF
GO

set identity_insert ETL_SourceSystem on

IF NOT EXISTS ( SELECT * FROM ETL_SourceSystem WHERE SS_ID in (37,38,39,40,41,42,139,140) )
   BEGIN    
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (37, 'CDRBATSCore',      'T','','D',GETDATE())                                 
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (38, 'BATSCore',         'T','','D',GETDATE())                                        
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (39, 'CDRMONACOArr',  'T','','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (40, 'CDRMONACOCore', 'T','','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (41, 'MONACOArr',     'F','CDR_MONACO_YYYYMMDD.ppe','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (42, 'MONACOCore',    'F','CDR_MONACO_YYYYMMDD.ppe','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (139, 'OPENLINK',    'F','YVO0_Books_Access_YYYYMMDD.csv','D',GETDATE())
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (140, 'BDROPENLINK', 'T','','D',GETDATE())
END                                                                                      
SET IDENTITY_INSERT ETL_SourceSystem OFF
GO

SET IDENTITY_INSERT ETL_SourceSystem ON

IF NOT EXISTS ( SELECT * FROM ETL_SourceSystem WHERE SS_ID BETWEEN 141 AND 150)
   BEGIN    
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (141, 'RIMMSLON',    'F', 'BDR_RIMMS_LON_YYYYMMDD.csv','D',GETDATE()) 
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (142, 'BDRRIMMSLON', 'T', '','D',GETDATE())                           
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (143, 'RIMMSTOR',    'F', 'BDR_RIMMS_TOR_YYYYMMDD.csv','D',GETDATE()) 
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (144, 'BDRRIMMSTOR', 'T', '','D',GETDATE())                           
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (145, 'RIMMSEBS',    'F', 'BDR_RIMMS_EBS_YYYYMMDD.csv','D',GETDATE()) 
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (146, 'BDRRIMMSEBS', 'T', '','D',GETDATE())                           
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (147, 'RIMMSNY',     'F','BDR_RIMMS_NY_YYYYMMDD.csv','D',GETDATE())   
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (148, 'BDRRIMMSNY',  'T', '','D',GETDATE())                           
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (149, 'SLIM',        'F','BDR_SLIM_YYYYMMDD.csv','D',GETDATE())       
INSERT INTO ETL_SourceSystem (SS_ID,SS_Name,SS_Type,SS_FileName,SS_Frequency,SS_Timestamp) VALUES (150, 'BDRSLIM',     'T','','D',GETDATE())                            
  END

SET IDENTITY_INSERT ETL_SourceSystem OFF
GO

UPDATE ETL_SourceSystem SET SS_FileName='BDR_RIMMS_LON_YYYYMMDD.CSV' WHERE SS_Name = 'RIMMSLON' 
UPDATE ETL_SourceSystem SET SS_FileName='BDR_RIMMS_TOR_YYYYMMDD.CSV' WHERE SS_Name = 'RIMMSTOR' 
UPDATE ETL_SourceSystem SET SS_FileName='BDR_RIMMS_EBS_YYYYMMDD.CSV' WHERE SS_Name = 'RIMMSEBS' 
UPDATE ETL_SourceSystem SET SS_FileName='BDR_RIMMS_NY_YYYYMMDD.CSV'  WHERE SS_Name = 'RIMMSNY' 

UPDATE ETL_SourceSystem SET SS_FileName='CDRRecon_GBXREF_YYYYMMDD.TXT' WHERE SS_Name='GBArr' 

