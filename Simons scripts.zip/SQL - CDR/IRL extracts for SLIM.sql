
use report10_ldn --montage10_ldn
use montage10_ldn

isql -S ASED909 -Uslimetladm -PRoyal\$123 -c -w2000

use report10
use montage10

select db_name()
select @@version

SELECT DBName, BackupStartTime FROM master..monOpenDatabases WHERE DBName in ('montage10','montage10_ldn','report10','report10_ldn') ORDER BY 1

-- Check max dates:
SELECT 'sec' as 'TABLE', max(update_datetime) as 'MAX_UPDATE' FROM montage10..sec  UNION ALL       
SELECT 'sec' as 'TABLE', max(update_datetime) as 'MAX_UPDATE' FROM montage10_ldn..sec  

SELECT max(fixing_date) FROM report10_ldn.dbo.slim_mtm_fixing_trade_leg


SELECT 'slim_mtm_fixing_trade_leg' as 'TABLE', max(fixing_date) as 'MAX_UPDATE', count(*) as 'ROW_COUNT' FROM slim_mtm_fixing_trade_leg  UNION ALL
SELECT 'slim_book'                 as 'TABLE' , max(booktakeon) as 'MAX_UPDATE', count(*) as 'ROW_COUNT' FROM slim_book                  UNION ALL
SELECT 'slim_bookportfolio'        as 'TABLE' , ''              as 'MAX_UPDATE', count(*) as 'ROW_COUNT' FROM slim_bookportfolio         UNION ALL 
SELECT 'RBC_book_transit_mapping'  as 'TABLE' , ' ' as 'MAX_UPDATE', count(*) as 'ROW_COUNT'             FROM RBC_book_transit_mapping 

SELECT * FROM RBC_book_transit_mapping

SELECT * FROM report10..slim_book WHERE booktakeon IS NULL OR booktakeon  > '20130401'


SELECT 'report10_ldn..slim_book' as 'TABLE' 
,      convert(char(4),  ISNULL(booktakeon,'1/1/1800'), 112)    as "booktakeon_YYYY"
,      max(booktakeon) as 'MAX_UPDATE'
,      count(*) as 'ROW_COUNT'        
FROM   report10_ldn..slim_book
GROUP BY convert(char(4),  ISNULL(booktakeon,'1/1/1800'), 112)    
UNION ALL
SELECT 'report10..slim_book' as 'TABLE' 
,      convert(char(4),ISNULL(booktakeon,'1/1/1800'), 112)    as "booktakeon_YYYY"
,      max(booktakeon) as 'MAX_UPDATE'
,      count(*) as 'ROW_COUNT'        
FROM   report10..slim_book
GROUP BY convert(char(4),ISNULL(booktakeon,'1/1/1800'), 112)    
ORDER BY 1,2




SELECT top 10 *  FROM report10_ldn..slim_bookportfolio -- slim_book

--##################################################################################################################################
--# 1)  IRL trade and trade_status tables : 

--1a) check what time trades of a certain type changed status

use montage10_ldn --_ldn

SELECT t.trade_info_code 
,      ts.trade_status_code 
,      convert(char(9),  ts.status_datetime, 112) + convert(char(2),  ts.status_datetime, 108)  as "status_datetime_hh"
,      min(ts.trade_id)   as trade_id_sample_1 
,      max(ts.trade_id)   as trade_id_sample_2 
,      count(*) as 'row_count'
FROM  trade_status  ts
,     trade         t
WHERE ts.trade_id = t.trade_id 
AND   ts.trade_status_code in ('XXBOOKED','MATURED') -- ('MATURED','BOOKED', 'CANCELLED','ASSIGNED' ) --  ('BUY_OUT','EXPIRED','EXERCISED')
AND   ts.status_datetime BETWEEN '20131106' AND '20131109' -- >= dateadd(dd,-7,'20120419')  -- dateadd(dd,@BACK_DAYS,@BUS_DATE_START)
--AND   t.trade_date     >= '20130101' --AND '20131109'
AND   t.trade_info_code in ('BOND' ) -- ( 'SWAP','SWAPTION','CASH_TRANSFER') -- 'BOND' 
GROUP BY t.trade_info_code 
,      ts.trade_status_code 
,      convert(char(9),  ts.status_datetime, 112) + convert(char(2),  ts.status_datetime, 108)  
ORDER BY 1,2,3

--,      convert(char(6),  t.settlement_date , 112) as "settlement_date_mm"
--,      convert(char(6),  t.settlement_date , 112) as "settlement_date_mm"
--,      convert(char(8),  ts.status_datetime, 112) as "status_datetime"

--1b) check what time trades of a certain type changed status. I've seen mass maturities before for BONDS.


-- find the first time when a book became PENDING / BOOKED etc
-- from RBC_Slim_Daily_OTC.sql for LDN

--,      convert(char(9),  ts.status_datetime, 112) + convert(char(5),  ts.status_datetime, 108)  as "status_datetime_hh:mm"

SELECT ts.trade_id 
,      t.trade_info_code
,      t.trade_status_code 
,      ts.trade_status_code as trade_status_code_ts
,      ts.status_datetime
FROM  trade_status as ts
,     trade        as  t
WHERE 1 = 1 
AND   ts.trade_id in (1128980, 1129384) -- (1129542,1129543,1129544) --1056083, 1076885, 1099738,2253920,2253920, 208454,1016768 )
AND   ts.trade_id = t.trade_id 
ORDER BY 1, 2,5

--,     ( SELECT trade_id, trade_status_code, min(status_datetime) as status_datetime 
--        FROM  montage10_ldn..trade_status ts2 WHERE trade_id in (2148408,2516892) GROUP BY trade_id, trade_status_code ) tsm

--AND   ts.trade_id = tsm.trade_id  AND   ts.trade_status_code = tsm.trade_status_code  AND   ts.status_datetime = tsm.status_datetime  
--and  ts.trade_status_code in ('CANCELLED','ASSIGNED','BUY_OUT','EXPIRED','EXERCISED','MATURED')
--AND        trade_info_code = 'BOND' 
--AND   ts.status_datetime BETWEEN '20131106' AND '20131110' -- >= dateadd(dd,-120, getdate() ) --'20120419')  -- dateadd(dd,@BACK_DAYS,@BUS_DATE_START)
-- check out books in slim_book

SELECT TOP 10 * FROM report10_ldn..slim_book sb 

SELECT * 
FROM report10_ldn..slim_mtm_fixing_trade_leg
WHERE trade_id in (1128980, 1129384)
AND fixing_date =  '20131107'

SELECT convert(char(6),  sb.booktakeon, 112) as "booktakeon_mm"
--,      booktype
,      count(*) 
FROM report10_ldn..slim_book sb
GROUP BY convert(char(6),  sb.booktakeon, 112) 
ORDER BY 1

-- from RBC_Slim_Daily_OTC.sql for TOR

select convert(char(8),  status_datetime, 112) as "status_datetime"
,      count(*) as 'row_count'
--,      trade_id 
from montage10..trade_status as trade_status
,    montage10..trade        as trade  
where trade_status.trade_id = trade.trade_id 
and  trade_status.trade_status_code in ('BOOKED')
and     trade_info_code in ('BOND_FUTURE','BOND_FUT_OPT','FUTURE','FUTURE_OPT')
and  status_datetime >= dateadd(dd,-7,'20121012')  -- dateadd(dd,@BACK_DAYS,@BUS_DATE_START)
--AND  trade_status.status_datetime >= sb.booktakeon)
GROUP BY convert(char(8),  status_datetime, 112)
ORDER BY 1

SELECT max(booktakeon), count(*) FROM report10..slim_book

--##################################################################################################################################
--# -- RBC_Slim_Daily_Bond_Main.sql (TOR)

select 
    rtrim(trdbk.book_name)                      --as BookCode
,   convert(numeric(28,8),str_replace(trdattn.remark,'$',''))                             --as BrokerFinAmt
,   case 
        when tlg1.rec_org_short_name in ('RBCTRDTOR','RBCTRDTORI') 
        then 'B'
        else 'S'
    end                                         --as BuySellIndicator
,    convert(numeric(28,8),tlg2.trade_amount - tlg1.accrued_interest_amount)        --as CleanConsidAmount
,   sec1.currency_code                          --as CurrencyCodeClean
,   rtrim(bond_header.identification_str)                                       --as IDENTIFICATIONSTR 
,   case
        when tlg1.pay_org_short_name in ('RBCTRDTOR','RBCTRDTORI')
        then tlg1.rec_org_short_name
        else tlg1.pay_org_short_name
    end                                         --as InfinityCounterpartyShortName
,   rtrim(sec1.leg_type_code)                   --as InfinityProductLegType
,   rtrim(sec1.sec_type_code)                   --as InfinityProductSecType
,   trade_info_code                             --as InfinityProductType
,   convert(numeric(28,8),tlg1.accrued_interest_amount)                --as InitialCashAccrued
, '19000101'
,   convert(numeric(28,8),tlg1.trade_amount)                           --as Nominal
--,   str_replace(str_replace(str_replace(str_replace(str_replace(str_replace(str_replace(ltrim(rtrim(trade.remark)),'       ',' '),'  ',' '),'  ',' '),'  ',' '),'  ',' '),'  ',' '),'  ',' ')
,   trade.remark                               --as Remark
,   sec1.sec_id                                 --as SecurityIdentifier
,   trade.entered_datetime                      --as SourceSystemInputTime
,   trade.trade_id                              --as TradeID
,   trade.trade_date                            --as TradeDate
,   convert(numeric(28,8),trade.quote_price)                           --as TradePrice
,   trade.trader_prsn_id                        --as TraderID
,   trade.trade_status_code                     --as TradeStatus
,   trade.trans_id                              --as TransID
,   trade.settlement_date                       --as ValueDate
,   case when bond_header.when_issued_flag = 1 then 'Y' else 'N' end


SELECT trade_info_code                             --as InfinityProductType
--,    rtrim(trdbk.book_name)
,    trade.trade_status_code                     --as TradeStatus
--,    sec1.sec_id                                 --as SecurityIdentifier
,      count(*) as 'row_count'
FROM
    trade trade inner join trade_leg as tlg1
    on  trade.trade_id = tlg1.trade_id
    and 1              = tlg1.trade_leg_id
        inner join sec as sec1
        on tlg1.sec_id = sec1.sec_id
            inner join trading_book trdbk
            on tlg1.book_id = trdbk.book_id
                left outer join trade_attention as trdattn
                on  trade.trade_id = trdattn.trade_id
                and trdattn.trade_attention_code = 'BOND_COMMISSION'
                    left outer join bond_header
                    on tlg1.sec_id = bond_header.sec_id
                      inner join trade_leg as tlg2
                      on  trade.trade_id = tlg2.trade_id
                      and 2              = tlg2.trade_leg_id
                          join report10..slim_book as sb
                          on trdbk.book_name = sb.book
where
            trade_info_code = 'BOND' 
AND  (( trade.trade_status_code = 'XXBOOKED' )
         or ( exists (select trade_id from trade_status where trade_status.trade_id = trade.trade_id 
--         and trade_status.trade_status_code in ( 'CANCELLED','ASSIGNED') and trade.trade_status_code in ( 'CANCELLED','ASSIGNED') 
         and trade_status.trade_status_code NOT in ( 'BOOKED','PENDING') and trade.trade_status_code NOT in ( 'BOOKED','BOOKED') 
         and status_datetime >= dateadd(dd,-7,'20131107')  -- @BUS_DATE_START
             AND  trade_status.status_datetime >= sb.booktakeon ) --@CONV_DATE)
))
--AND settlement_date >= sb.booktakeon
GROUP BY trade_info_code     
--,    rtrim(trdbk.book_name)
,    trade.trade_status_code 


select trade_id 
from trade_status 
where trade_status.trade_id = trade.trade_id 
         and trade_status.trade_status_code in ( 'CANCELLED','ASSIGNED') and trade.trade_status_code in ( 'CANCELLED','ASSIGNED') 
         and status_datetime >= dateadd(dd,-7,'20131107')  -- @BUS_DATE_START
             ) --AND  trade_status.status_datetime >= sb.booktakeon )


--##################################################################################################################################
--# 


sp_help RBC_Slim_Daily_OTC
-- LDN testing:
exec RBC_Slim_Daily_LD_Mortgages '20120419', -7, 0
exec RBC_Slim_Daily_OTC '20120419', -7, 0

exec RBC_Slim_Daily_Positions '20131212', '20131211', '20131212'
exec RBC_Slim_Daily_Settlements '20120419'
 
exec RBC_Slim_Daily_Swap '20120419', -7, 0
exec RBC_Slim_Daily_Valuations '20140226'
exec RBC_Slim_Daily_FX '20120419', -7, 0

exec RBC_Slim_Infinity_Recon '20120419'

-- TOR testing:
exec dbo.RBC_Slim_Daily_ETD_Trade '20091012', '20131212', -7
-- ( @CONV_DATE, @BUS_DATE_START , @BACK_DAYS )

exec RBC_Slim_Daily_Cash '20091012',  '20121012', -7
exec RBC_Slim_Daily_BOND_MBS '20091012',  '20121012', -7
exec RBC_Slim_Daily_Bond_Main '20091012',  '20121012', -7
exec RBC_Slim_Daily_ETD_Trade '20091012',  '20121012', -7
exec RBC_Slim_Daily_FX_Swap '20091012',  '20121012', -7
exec RBC_Slim_Daily_LD_Mortgages '20091012',  '20121012', -7
exec RBC_Slim_Daily_OTC '20091012',  '20121012', -7
exec RBC_Slim_Daily_Positions '20131212', '20131211', '20131212'
exec RBC_Slim_Daily_Repo_main '20091012',  '20121012', -7
exec RBC_Slim_Daily_Settlements '20121012'
exec RBC_Slim_Daily_Valuations '20091012',  '20121012', -7
exec RBC_Slim_INI_BOND_MBS '20091012',  '20121012', -7
exec RBC_Slim_Daily_Swap '20091012',  '20121012', -7

exec RBC_Slim_Daily_Valuations '20091012',  '20140226', -7

exec RBC_Slim_Daily_Cash '20131107', -7, 0
exec RBC_Slim_Daily_Bond_Main '20091012',  '20131107', -7
exec RBC_Slim_Daily_BOND_MBS '20091012',  '20131107', -7


--##################################################################################################################################
--#  TOR_DLY_TRADSALE -> TORINF_SLIM_TRADSALE    (8.5 missing 17 records)

select 
	    [&PROCESS_RUN_ID],
	    [&LPG_ID],
	    (CASE WHEN ISNULL(middle_name,'null')='INACTIVE' THEN 'I' ELSE 'A' END) as ActiveCode,
	    first_name FirstName,
	    last_name LastName,
	    prsn_id PersonCode,
	    inf_datetime
	from
	   csa.prsn 
	where inf_datetime >= convert(datetime,'[&QUERY_START]') 
	 and  inf_datetime < convert(datetime, '[&QUERY_END]')
	 and inf_afterimage = 1

Inifinity csa.prsn table is being queried WHERE inf_datetime BETWEEN '[&QUERY_START]' '[&QUERY_END]
And these are being passed from the SLIM batch process 20140130 - 20140206
, so it's just a case of SLIM batch process not being deisigned for reruns of old data

QUERY_START = 20140130 10:52:37
QUERY_END  = 20140206 10:52:37

--##################################################################################################################################'
--# LON_Valuations_Load -> LDNINF_SLIM_TRADEVAL    (8.5 missing 2 records)

SELECT * FROM report10_ldn..slim_bookportfolio WHERE book in ('RBCJVG') AND portfolio in ('FAS-NZD')
   
SELECT * 
FROM report10_ldn..slim_mtm_fixing_trade_leg
WHERE trade_id in (1128980, 1129384)
AND fixing_date =  '20131107'

SELECT trade_id, trade_leg_id, trans_id, sec_id, convert(char(20),portfolio_name) portfolio_name,	fixing_date, trade_info_code	
FROM montage10_ldn..mtm_fixing_trade_leg
--FROM report10_ldn..slim_mtm_fixing_trade_leg
WHERE trade_id in (1128980, 1129384)
AND fixing_date BETWEEN '20131101' AND '20131231'
AND trade_leg_id = 1 

SELECT fixing_date
,      SUM(CASE WHEN portfolio_name = 'FAS-NZD' THEN 1 ELSE 0 END )  as FAS_NZD_count
,      SUM(CASE WHEN portfolio_name like 'FAS-%' THEN 1 ELSE 0 END ) as FAS_count
,     count(*)  as ALL_count
FROM montage10_ldn..mtm_fixing_trade_leg
WHERE fixing_date BETWEEN '20131020' AND '20131201' 
GROUP BY  fixing_date

SELECT fixing_date
,     count(*)  as ALL_count
FROM report10..mtm_fixing_trade_leg
--WHERE fixing_date BETWEEN '20131020' AND '20131201' 
GROUP BY  fixing_date

update all statistics report10..mtm_fixing_trade_leg 
update all statistics montage10_ldn..mtm_fixing_trade_leg 

--##################################################################################################################################
--# sysobjects etc
-- 1) CHECKS for valid SLIM sysobjects setup before starting batch: 
   -- a) RBC_book_transit_mapping must exist in both report* DB's and NOT as a "proxy table"
  
SELECT DB, type , name FROM (
SELECT 'montage10'     as DB, type , name, crdate FROM   montage10..sysobjects     UNION ALL
SELECT 'montage10_ldn' as DB, type , name, crdate FROM   montage10_ldn..sysobjects UNION ALL
--SELECT 'uat3_report10_ldn'      as DB, type , name, crdate FROM   uat3_report10_ldn..sysobjects      UNION ALL
--SELECT 'uat3_montage10_ldn'      as DB, type , name, crdate FROM   uat3_montage10_ldn..sysobjects      UNION ALL
SELECT 'report10'      as DB, type , name, crdate FROM   report10..sysobjects      UNION ALL
SELECT 'report10_ldn'  as DB, type , name, crdate FROM   report10_ldn..sysobjects --UNION ALL
)  so WHERE  type in ('U','P','V')  
--AND   UPPER(name) like '%RBC_SLIM_INFINITY_RECON%' --'%DE_KEYW%'
--AND name = 'RBC_book_transit_mapping'
--AND  (   name like '%slim_infinity_recon%' OR name like '%RBC_Slim%'  OR name like 'slim_%' OR name = 'RBC_book_transit_mapping' OR name like '%mtm_fixing_%'  ) 
AND name NOT like '%_Conv'  
ORDER BY DB, type, name

 -- 2) CHECKS for valid SLIM SYSINDEXES setup before starting batch:   
   -- one KEY index is report10..XAK2mtm_fixing_trade_leg forthe  RBC_Slim_Daily_Valuations proc
SELECT DB, type , name, crdate FROM (
SELECT 'report10_ldn' as DB, 'I' as type , name, crdate FROM  report10_ldn..sysindexes UNION ALL
SELECT 'report10'     as DB, 'I' as type , name, crdate FROM  report10..sysindexes     UNION ALL
SELECT 'montage10'    as DB, 'I' as type , name, crdate FROM  montage10..sysindexes    UNION ALL
SELECT 'montage10_ldn' as DB, 'I' as type, name, crdate FROM montage10_ldn..sysindexes --UNION ALL
) so 
WHERE  (   name like 'XAK2mtm_fixing_trade_leg' OR name like '%xx_mtm_fixing_trade%' OR name like '%xx_RBC_Slim%'    ) -- AND name NOT like 'tmp_%'  
ORDER BY DB, type, name


SELECT   name
,        dbid 
,        suid        --logptr, --,   crdate,        convert(char(9),  dumptrdate, 112) + convert(char(8),  dumptrdate, 108)  as "dumptrdate"
--,        convert(char(9),  crdate, 112) + convert(char(8),  crdate, 108)  as "crdate"
FROM    master..sysdatabases
WHERE   (suid != 1111 OR name = 'tempdb' ) -- suid != 1
AND   ( name like 'montage10%' OR name like 'report10%' )

sp_helpdb

-- List all tables and their columns contain a certain column name or tbale name string :

SELECT Table_name = isnull(o.name, 'NULL')
,      Column_name = isnull(c.name, 'NULL')
,       Col_order = colid
,       Type = t.name
,       Length = c.length
,       Prec = c.prec
,       Scale = c.scale
,       Nulls = convert(bit, (c.status & 8))
--,       c.*
FROM  syscolumns c, systypes t, sysobjects o
WHERE c.id = o.id
AND   c.usertype = t.usertype  --AND   c.usertype *= t.usertype
AND   o.type = 'U'
--AND   t.name = 'date'
--AND   o.name like "acc"
--AND   o.name in ('al_collateral_movement','al_pool','al_profit_centre','al_stock')
ORDER BY isnull(o.name, 'NULL'), colid


--##################################################################################################################################
--# 8) Inbound query analysis / debugging

SELECT DISTINCT 
    p.first_name   as FirstName
,   p.last_name    as LastName
,   p.prsn_id      as PersonCode
FROM montage10_ldn..prsn                 p
JOIN montage10_ldn..emp_prsn_login_name  l  ON p.prsn_id    = l.emp_prsn_id 
JOIN montage10_ldn..user_system_info     s  ON l.login_name = s.user_login_name
WHERE p.last_name like 'O%noghue'
ORDER BY LastName, FirstName

USE montage10_ldn

SELECT trade_id                              as TradeID
,      trans_id                              as TransID
,      remark                                as Remark
--,      *
FROM montage10_ldn..trade 
WHERE trans_id in (755692, 857683, 857167, 857169)

SELECT trade_id, trade_keyword_code + '-XX'  FROM trade_keyword  WHERE trade_id in (258277, 1016794) ORDER BY trade_id

--##################################################################################################################################
--# 9) System tables - running processes

sp_who
sp_who slimetladm

SELECT spid
,      a.status
--,      hostname
--,      hostprocess
--,      program_name
,      cmd
,      substring(b.name,1,15) 'database'
--,      substring(tran_name,1,20) as tran_name
,      cpu
,      physical_io
,      memusage
,      blocked
--,      time_blocked 
FROM master..sysprocesses a, master..sysdatabases b
WHERE hostprocess > ' '
  AND b.dbid = a.dbid
  AND physical_io > 0
--  AND NOT (program_name = 'PowerMart' and hostname = ' ')
ORDER by spid

sp_lock 168
--sp_showplan 341


select object_name(831602301)

sp_helptext RBC_Slim_Infinity_Recon

use report10_ldn 

declare @in_recdate datetime
set @in_recdate = '20131107'
exec RBC_Slim_Infinity_Recon @in_recdate

use report10

declare @in_recdate datetime
declare @convdate datetime
set @in_recdate = '20131107'                                                                                                            
set @convdate ='20090601'
exec slim_infinity_recon @in_recdate, @convdate






