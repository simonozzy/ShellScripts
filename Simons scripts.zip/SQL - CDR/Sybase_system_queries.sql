
--also see in here 
-- H:\Scripts\SQL\stored procs\Ed barlows procs - selected

SELECT DB, type , name
FROM (
SELECT 'montage10'     as DB, type , name, crdate FROM   montage10..sysobjects     UNION ALL
SELECT 'montage10_ldn' as DB, type , name, crdate FROM   montage10_ldn..sysobjects UNION ALL
--SELECT 'uat3_report10_ldn'      as DB, type , name, crdate FROM   uat3_report10_ldn..sysobjects      UNION ALL
--SELECT 'uat3_montage10_ldn'      as DB, type , name, crdate FROM   uat3_montage10_ldn..sysobjects      UNION ALL
SELECT 'report10'      as DB, type , name, crdate FROM   report10..sysobjects      UNION ALL
SELECT 'report10_ldn'  as DB, type , name, crdate FROM   report10_ldn..sysobjects --UNION ALL
)  so 
WHERE UPPER(name) like '%RBC_SLIM_INFINITY_RECON%' --'%DE_KEYW%'
AND   type in ('U','P','V') 
--AND  (  name like '%slim_infinity_recon%' OR name like '%RBC_Slim%' )
ORDER BY DB, type, name

SELECT   name
,        dbid 
,        suid        --logptr, --,   crdate,        convert(char(9),  dumptrdate, 112) + convert(char(8),  dumptrdate, 108)  as "dumptrdate"
--,        convert(char(9),  crdate, 112) + convert(char(8),  crdate, 108)  as "crdate"
FROM    master..sysdatabases
WHERE   (suid != 1111 OR name = 'tempdb' ) -- suid != 1
AND   ( name like 'montage10%' OR name like 'report10%' )

sp_helpdb

-- List all objects :

SELECT  name     as    "object_name"
,       type     as    "object_type"
,       crdate   as    "creation_date"
,       'tempdb..' + name     as    "temp table name"
FROM  sysobjects
WHERE type in ('U','V','P')
ORDER BY type, name


-- List all tables and their columns contain a certain column name or tbale name string :

SELECT Table_name = isnull(o.name, 'NULL')
,      Column_name = isnull(c.name, 'NULL')
,       Col_order = colid
,       Type = t.name
,       Length = c.length
,       Prec = c.prec
,       Scale = c.scale
,       Nulls = convert(bit, (c.status & 8))
--,       c.*
FROM  syscolumns c, systypes t, sysobjects o
WHERE c.id = o.id
AND   c.usertype = t.usertype  --AND   c.usertype *= t.usertype
AND   o.type = 'U'
--AND   t.name = 'date'
--AND   o.name like "acc"
--AND   o.name in ('al_collateral_movement','al_pool','al_profit_centre','al_stock')
ORDER BY isnull(o.name, 'NULL'), colid


--##################################################################################################################################
--# 9) System tables - running processes

sp_who
sp_who slimetladm

SELECT spid
,      a.status
--,      hostname
--,      hostprocess
--,      program_name
,      cmd
,      substring(b.name,1,15) 'database'
--,      substring(tran_name,1,20) as tran_name
,      cpu
,      physical_io
,      memusage
,      blocked
--,      time_blocked 
FROM master..sysprocesses a, master..sysdatabases b
WHERE hostprocess > ' '
  AND b.dbid = a.dbid
  AND physical_io > 0
--  AND NOT (program_name = 'PowerMart' and hostname = ' ')
ORDER by spid

sp_lock 231
--sp_showplan 341


select object_name(831602301)
