/*********************************************************************************************
#  Name     :  ~ukrr_pm/scripts/sql/REP_info.sql
#  Purpose  : .sql report / update to Informtica repository to ...
#  Usage    :  call_sql.sh REP_info.sql ${SN} "simon.osborne@rbccm.com"
#           :
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  29/08/2008   S Osborne       Created
#
#*********************************************************************************************/

SET NOCOUNT ON 

--use powermart_7
use pc_rep
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT ' 1) pc_rep..OPB_REPOSIT_INFO :'
PRINT '-------------------------------------------------'
PRINT ''

SELECT  convert(varchar(15),REPOSITORY_NAME)   as 'REPOSITORY_NAME'
--,       REPOSITORY_ID
--,       REPOSITORY_TYPE
--,       substring(DOMAIN_NAME,1,10)    as   'DOMAIN_NAME'
,       convert(varchar(15),DB_USER)     as 'DB_USER'
,       convert(varchar(20),DB_PASSWD)   as 'DB_PASSWD'
,       convert(varchar(30),DB_ODBC_CONNECT)   as 'DB_ODBC_CONNECT'
,       convert(varchar(30),DB_NATIVE_CONNECT)   as 'DB_NATIVE_CONNECT'
--,       DB_TYPE   as   'DB_TYPE'
FROM    pc_rep..OPB_REPOSIT_INFO
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT ' 2) pc_rep..OPB_CNX_ATTR  -  Database connection attributes '
PRINT '-------------------------------------------------'
PRINT ''

SELECT ATTR_ID
,      convert(varchar(25),ATTR_VALUE) as 'ATTR_VALUE'
FROM   pc_rep..OPB_CNX_ATTR
WHERE  ATTR_ID  = 11
AND   convert(char(3),ATTR_VALUE) in ( 'LDN','LNP','LNU','LND' )
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT ' 3) pc_rep..OPB_SERVER_INFO , though this seems to not be used in V8 any longer:'
PRINT '-------------------------------------------------'
PRINT ''

SELECT  SERVER_ID
,       substring(SERVER_NAME,1,10)    as   'SERVER_NAME'
,       PROTOCOL
,       substring(HOST_INFO,1,25)    as   'HOST_INFO'
,       convert(varchar(25),HOSTNAME)    as   'HOSTNAME'
,       substring(IP_ADDRESS,1,20)    as   'IP_ADDRESS'
FROM  pc_rep..OPB_SERVER_INFO
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT ' 4) pc_domain..PCSF_DOMAIN , the only Domain table that is of any use - contains the name:'
PRINT '-------------------------------------------------'
PRINT ''

SELECT domain_name = convert(char(50),name )
FROM pc_domain..PCSF_DOMAIN                 
go


quit


