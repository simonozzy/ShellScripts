/*********************************************************************************************
#  Name     : ~ukrr_pm/scripts/sql/ukrr_batch_performance.sql
#  Purpose  : 
#  Usage    :  call_sql.sh ukrr_batch_performance.sql ${SN} "simon.osborne@rbccm.com"
#           :  00 10 * * 1-5 /home/ukrr_pm/scripts/report_master.sh ukrr_batch_performance.sql email "simon.osborne@rbccm.com" 'UKRR batch performance overview'
#           :  alias ubf='call_sql.sh ukrr_batch_performance.sql ${SN} "simon.osborne@rbccm.com"'
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  09/05/2008   S Osborne       Created
#
#*********************************************************************************************/

SET nocount ON

SELECT  SUBJECT_AREA
,       WORKFLOW_NAME
,       WORKFLOW_ID
--,       WORKFLOW_RUN_ID
,       START_TIME
,       END_TIME
,       datediff(mi,START_TIME, END_TIME)  as 'DURATION'
,       RUN_STATUS_CODE
INTO   #REP_WF_RUN 
FROM   pc_rep..REP_WFLOW_RUN 
WHERE  1  = 2
go

ALTER TABLE #REP_WF_RUN add WORKFLOW_RUN_ID int identity
go

INSERT #REP_WF_RUN
SELECT  SUBJECT_AREA
,       WORKFLOW_NAME
,       WORKFLOW_ID
--,       WORKFLOW_RUN_ID
,       START_TIME
,       END_TIME
,       DURATION = datediff(mi,START_TIME, END_TIME)
,       RUN_STATUS_CODE
FROM   pc_rep..REP_WFLOW_RUN 
WHERE  RUN_STATUS_CODE = 1 
AND    START_TIME  >= dateadd(DD, -35, getdate()) 
AND   WORKFLOW_NAME NOT  IN ('b_CollectINFT_InterestCurve','b_GED_Collect','s_CollectGCPInfinityProfile','s_CollectGCPInfinityCDO',
                               's_CollectType1_OrgUnitDimension','b_CollectRIMS_WK' ) -- 'b_Perm_Acc_Daily', 'b_Perm_Acc_Monthly',
ORDER BY START_TIME
go

CREATE TABLE #times (time_min datetime)

DECLARE @batch_end_time     datetime
,       @batch_start_time   datetime
,       @current_min   datetime
--,       @start_time    datetime
,       @end_time       datetime
,       @message        varchar(255) 

SELECT @batch_end_time = dateadd(hh,24+21,max(calendar_date)) FROM ukrr_mart..date_dimension WHERE calendar_date < convert(char(8),getdate(),112) AND working_day_flag = 'Y'
SELECT @batch_start_time = dateadd(hh,21 ,max(calendar_date)) FROM ukrr_mart..date_dimension WHERE calendar_date < convert(char(8),getdate(),112) AND working_day_flag = 'Y'
--21h00 on the day after the previous working day - might as well allow for really late runs and take it till 9pm

-- Create the tmp table to be used for concurrency reporting for hours between 10pm and 8am:
SELECT @current_min = dateadd(DD, -35, @batch_end_time)  --@batch_start_time 
SELECT @end_time = dateadd(HH,14,@batch_start_time) -- @batch_end_time 

WHILE @current_min <=  @end_time
BEGIN  
        INSERT #times 
        SELECT @current_min 
        WHERE ( datepart(HH,@current_min) < 8   AND  datepart(dw,@current_min) NOT in (1,2) ) --# Before 9am except Sun / Mon morning
        OR    ( datepart(HH,@current_min) >= 22  AND datepart(dw,@current_min) NOT in (1,7) ) --# after 10pm except Sat / Sun night ) 
        SELECT @current_min = dateadd(mi,1,@current_min) 
END    

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '1) Selected batch milestones for the last few days : '
PRINT '-------------------------------------------------'
PRINT ''

SELECT  convert(char(35),WORKFLOW_NAME) as 'WORKFLOW_NAME' 
--,       WORKFLOW_ID     
,       MAX(CASE WHEN END_TIME > dateadd(DD, -1, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5)                                      END)          as 'latest'
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -2 , @batch_end_time) AND dateadd(DD, -1 , @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p1'        
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -3 , @batch_end_time) AND dateadd(DD, -2 , @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p2'        
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -4 , @batch_end_time) AND dateadd(DD, -3 , @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p3'        
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -5 , @batch_end_time) AND dateadd(DD, -4 , @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p4'        
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -6 , @batch_end_time) AND dateadd(DD, -5 , @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p5'        
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -7 , @batch_end_time) AND dateadd(DD, -6 , @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p6'        
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -8 , @batch_end_time) AND dateadd(DD, -7 , @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p7'        
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -9 , @batch_end_time) AND dateadd(DD, -8 , @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p8'        
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -10, @batch_end_time) AND dateadd(DD, -9 , @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p9'        
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -11, @batch_end_time) AND dateadd(DD, -10, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p10'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -12, @batch_end_time) AND dateadd(DD, -11, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p11'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -13, @batch_end_time) AND dateadd(DD, -12, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p12'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -14, @batch_end_time) AND dateadd(DD, -13, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p13'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -15, @batch_end_time) AND dateadd(DD, -14, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p14'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -16, @batch_end_time) AND dateadd(DD, -15, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p15'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -17, @batch_end_time) AND dateadd(DD, -16, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p16'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -18, @batch_end_time) AND dateadd(DD, -17, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p17'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -19, @batch_end_time) AND dateadd(DD, -18, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p18'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -20, @batch_end_time) AND dateadd(DD, -19, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p19'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -21, @batch_end_time) AND dateadd(DD, -20, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p20'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -22, @batch_end_time) AND dateadd(DD, -21, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p21'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -23, @batch_end_time) AND dateadd(DD, -22, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p22'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -24, @batch_end_time) AND dateadd(DD, -23, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p23'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -25, @batch_end_time) AND dateadd(DD, -24, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p24'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -26, @batch_end_time) AND dateadd(DD, -25, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p25'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -27, @batch_end_time) AND dateadd(DD, -26, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p26'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -28, @batch_end_time) AND dateadd(DD, -27, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p27'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -29, @batch_end_time) AND dateadd(DD, -28, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p28'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -30, @batch_end_time) AND dateadd(DD, -29, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p29'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -31, @batch_end_time) AND dateadd(DD, -30, @batch_end_time) THEN substring(convert(char(8),END_TIME, 108),1,5) END) as 'p30'       
INTO  #milestones
FROM   #REP_WF_RUN   --pc_rep..REP_WFLOW_RUN 
WHERE  START_TIME  > dateadd(DD, -35, @batch_end_time)  -- 'Mmm dd yyyy  hh:mm[AM|PM]'
AND  WORKFLOW_NAME IN ('b_MART_MIST_Qualification','b_InternalExtracts_Daily','b_RFRM_Daily') -- ,'b_OFFS_Collection' ,'b_MART_RIMS_Qualification_Trade','b_MKTD_SecurityRating'
--AND    RUN_STATUS_CODE = 1
GROUP BY convert(char(35),WORKFLOW_NAME) 
--,       WORKFLOW_ID     
ORDER BY 1
--go

--Get the batch date into the milestones table for reference:

INSERT INTO  #milestones
SELECT  WORKFLOW_NAME = '(bus_date)' 
,       MAX(CASE WHEN END_TIME > dateadd(DD, -1, @batch_end_time)                                               THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'latest'
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -2 , @batch_end_time) AND dateadd(DD, -1 , @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p1'        
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -3 , @batch_end_time) AND dateadd(DD, -2 , @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p2'        
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -4 , @batch_end_time) AND dateadd(DD, -3 , @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p3'        
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -5 , @batch_end_time) AND dateadd(DD, -4 , @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p4'        
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -6 , @batch_end_time) AND dateadd(DD, -5 , @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p5'        
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -7 , @batch_end_time) AND dateadd(DD, -6 , @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p6'        
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -8 , @batch_end_time) AND dateadd(DD, -7 , @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p7'        
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -9 , @batch_end_time) AND dateadd(DD, -8 , @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p8'        
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -10, @batch_end_time) AND dateadd(DD, -9 , @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p9'        
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -11, @batch_end_time) AND dateadd(DD, -10, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p10'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -12, @batch_end_time) AND dateadd(DD, -11, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p11'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -13, @batch_end_time) AND dateadd(DD, -12, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p12'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -14, @batch_end_time) AND dateadd(DD, -13, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p13'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -15, @batch_end_time) AND dateadd(DD, -14, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p14'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -16, @batch_end_time) AND dateadd(DD, -15, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p15'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -17, @batch_end_time) AND dateadd(DD, -16, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p16'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -18, @batch_end_time) AND dateadd(DD, -17, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p17'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -19, @batch_end_time) AND dateadd(DD, -18, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p18'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -20, @batch_end_time) AND dateadd(DD, -19, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p19'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -21, @batch_end_time) AND dateadd(DD, -20, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p20'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -22, @batch_end_time) AND dateadd(DD, -21, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p21'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -23, @batch_end_time) AND dateadd(DD, -22, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p22'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -24, @batch_end_time) AND dateadd(DD, -23, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p23'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -25, @batch_end_time) AND dateadd(DD, -24, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p24'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -26, @batch_end_time) AND dateadd(DD, -25, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p25'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -27, @batch_end_time) AND dateadd(DD, -26, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p26'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -28, @batch_end_time) AND dateadd(DD, -27, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p27'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -29, @batch_end_time) AND dateadd(DD, -28, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p28'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -30, @batch_end_time) AND dateadd(DD, -29, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p29'       
,       MAX(CASE WHEN END_TIME BETWEEN  dateadd(DD, -31, @batch_end_time) AND dateadd(DD, -30, @batch_end_time) THEN ' ' + substring(convert(char(8),END_TIME, 103),1,2) END) as 'p30'       
FROM   #REP_WF_RUN   --pc_rep..REP_WFLOW_RUN
WHERE  START_TIME  > dateadd(DD, -35, @batch_end_time)  -- 'Mmm dd yyyy  hh:mm[AM|PM]'
AND  WORKFLOW_NAME IN ('b_GCLT_Collection') 

SELECT  WORKFLOW_NAME 
,       latest
,       p1        
,       p2        
,       p3        
,       p4        
,       p5        
,       p6        
,       p7        
,       p8        
,       p9        
,       p10       
,       p11       
,       p12       
,       p13       
,       p14       
FROM   #milestones
ORDER BY 1

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '2a) running time stats for workflows running longer than 10 minutes in previous batch run : '
PRINT '-------------------------------------------------'
PRINT ''

SELECT  --convert(char(20),SUBJECT_AREA)  as 'SUBJECT_AREA'
        convert(char(50),WORKFLOW_NAME) as 'WORKFLOW_NAME' 
,       MAX(CASE WHEN START_TIME BETWEEN  dateadd(DD, -1, @batch_end_time) AND dateadd(DD, -0, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )       as 'latest_min'
,       MAX(CASE WHEN START_TIME BETWEEN  dateadd(DD, -2, @batch_end_time) AND dateadd(DD, -1, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )     as 'prev_run'
,       AVG(CASE WHEN START_TIME BETWEEN  dateadd(DD, -8, @batch_end_time) AND dateadd(DD, -7, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )     as 'week_ago'
,       AVG(CASE WHEN START_TIME BETWEEN  dateadd(DD, -8, @batch_end_time) AND dateadd(DD, -1, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )     as 'wk_avg'
,       AVG(CASE WHEN START_TIME BETWEEN dateadd(DD, -15, @batch_end_time) AND dateadd(DD, -8, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )     as 'wk_avg_prev'
,       AVG(CASE WHEN START_TIME BETWEEN dateadd(DD, -31, @batch_end_time) AND dateadd(DD, -1, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END)     as 'month_avg'
,       MIN(CASE WHEN START_TIME BETWEEN  dateadd(DD, -8, @batch_end_time) AND dateadd(DD, -1, @batch_end_time) THEN substring(convert(char(8),START_TIME, 108),1,5) END) as 'min_start'
,       MAX(CASE WHEN START_TIME BETWEEN  dateadd(DD, -2, @batch_end_time) AND dateadd(DD, -1, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )       as 'p1'
,       MAX(CASE WHEN START_TIME BETWEEN  dateadd(DD, -3, @batch_end_time) AND dateadd(DD, -2, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )       as 'p2'
,       MAX(CASE WHEN START_TIME BETWEEN  dateadd(DD, -4, @batch_end_time) AND dateadd(DD, -3, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )       as 'p3'
,       MAX(CASE WHEN START_TIME BETWEEN  dateadd(DD, -5, @batch_end_time) AND dateadd(DD, -4, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )       as 'p4'
,       MAX(CASE WHEN START_TIME BETWEEN  dateadd(DD, -6, @batch_end_time) AND dateadd(DD, -5, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )      as 'p5'
,       MAX(CASE WHEN START_TIME BETWEEN  dateadd(DD, -7, @batch_end_time) AND dateadd(DD, -6, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )     as 'p6'
,       MAX(CASE WHEN START_TIME BETWEEN  dateadd(DD, -8, @batch_end_time) AND dateadd(DD, -7, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )     as 'p7'
--,       AVG(CASE datepart(wk,START_TIME)  WHEN @week_no_current THEN datediff(mi,START_TIME, END_TIME) END ) as 'this_week_avg'
--,       AVG(CASE datepart(wk,START_TIME)  WHEN @week_no_1 THEN datediff(mi,START_TIME, END_TIME) END )      as 'last_week_avg'
INTO  #run_avg
FROM  #REP_WF_RUN   --pc_rep..REP_WFLOW_RUN 
--WHERE  RUN_STATUS_CODE = 1
--AND    START_TIME  >= dateadd(DD, -14, @batch_end_time)  -- 'Mmm dd yyyy  hh:mm[AM|PM]'
--AND    WORKFLOW_NAME = 'b_MART_MIST_Qualification'
GROUP BY --convert(char(20),SUBJECT_AREA) 
        convert(char(50),WORKFLOW_NAME)
--HAVING  AVG(CASE WHEN START_TIME > dateadd(DD, -1, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END ) >= 5
ORDER BY 2 DESC
--go

--# Link to batch_master to get system and type info and summarise for the last 2 months :

SELECT  bm.type
--,       bm.system
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -1 , @batch_end_time) AND dateadd(DD, -0 , @batch_end_time) THEN DURATION END )   as 'latest_min'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -2 , @batch_end_time) AND dateadd(DD, -1 , @batch_end_time) THEN DURATION END )   as 'p1'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -3 , @batch_end_time) AND dateadd(DD, -2 , @batch_end_time) THEN DURATION END )   as 'p2'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -4 , @batch_end_time) AND dateadd(DD, -3 , @batch_end_time) THEN DURATION END )   as 'p3'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -5 , @batch_end_time) AND dateadd(DD, -4 , @batch_end_time) THEN DURATION END )   as 'p4'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -6 , @batch_end_time) AND dateadd(DD, -5 , @batch_end_time) THEN DURATION END )   as 'p5'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -7 , @batch_end_time) AND dateadd(DD, -6 , @batch_end_time) THEN DURATION END )   as 'p6'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -8 , @batch_end_time) AND dateadd(DD, -7 , @batch_end_time) THEN DURATION END )   as 'p7'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -9 , @batch_end_time) AND dateadd(DD, -8 , @batch_end_time) THEN DURATION END )   as 'p8'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -10, @batch_end_time) AND dateadd(DD, -9 , @batch_end_time) THEN DURATION END )   as 'p9'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -11, @batch_end_time) AND dateadd(DD, -10, @batch_end_time) THEN DURATION END )   as 'p10'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -12, @batch_end_time) AND dateadd(DD, -11, @batch_end_time) THEN DURATION END )   as 'p11'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -13, @batch_end_time) AND dateadd(DD, -12, @batch_end_time) THEN DURATION END )   as 'p12'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -14, @batch_end_time) AND dateadd(DD, -13, @batch_end_time) THEN DURATION END )   as 'p13'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -15, @batch_end_time) AND dateadd(DD, -14, @batch_end_time) THEN DURATION END )   as 'p14'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -16, @batch_end_time) AND dateadd(DD, -15, @batch_end_time) THEN DURATION END )   as 'p15'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -17, @batch_end_time) AND dateadd(DD, -16, @batch_end_time) THEN DURATION END )   as 'p16'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -18, @batch_end_time) AND dateadd(DD, -17, @batch_end_time) THEN DURATION END )   as 'p17'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -19, @batch_end_time) AND dateadd(DD, -18, @batch_end_time) THEN DURATION END )   as 'p18'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -20, @batch_end_time) AND dateadd(DD, -19, @batch_end_time) THEN DURATION END )   as 'p19'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -21, @batch_end_time) AND dateadd(DD, -20, @batch_end_time) THEN DURATION END )   as 'p20'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -22, @batch_end_time) AND dateadd(DD, -21, @batch_end_time) THEN DURATION END )   as 'p21'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -23, @batch_end_time) AND dateadd(DD, -22, @batch_end_time) THEN DURATION END )   as 'p22'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -24, @batch_end_time) AND dateadd(DD, -23, @batch_end_time) THEN DURATION END )   as 'p23'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -25, @batch_end_time) AND dateadd(DD, -24, @batch_end_time) THEN DURATION END )   as 'p24'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -26, @batch_end_time) AND dateadd(DD, -25, @batch_end_time) THEN DURATION END )   as 'p25'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -27, @batch_end_time) AND dateadd(DD, -26, @batch_end_time) THEN DURATION END )   as 'p26'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -28, @batch_end_time) AND dateadd(DD, -27, @batch_end_time) THEN DURATION END )   as 'p27'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -29, @batch_end_time) AND dateadd(DD, -28, @batch_end_time) THEN DURATION END )   as 'p28'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -30, @batch_end_time) AND dateadd(DD, -29, @batch_end_time) THEN DURATION END )   as 'p29'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -31, @batch_end_time) AND dateadd(DD, -30, @batch_end_time) THEN DURATION END )   as 'p30'
--,      convert(char(8),dateadd(ss,sum(avg_elapsed_seconds), '1/1/1900'),108) as total_elapsed_time  
INTO  #type_sum
FROM #REP_WF_RUN     bt  
,    tempdb..so_batch_master  bm
WHERE bm.batch_name = bt.WORKFLOW_NAME
GROUP BY bm.type
--,       bm.system
--go

INSERT #type_sum
SELECT  "5) ALL"
--,       bm.system
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -1 , @batch_end_time) AND dateadd(DD, -0 , @batch_end_time) THEN DURATION END )     as 'latest_min'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -2 , @batch_end_time) AND dateadd(DD, -1 , @batch_end_time) THEN DURATION END )     as 'p1'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -3 , @batch_end_time) AND dateadd(DD, -2 , @batch_end_time) THEN DURATION END )     as 'p2'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -4 , @batch_end_time) AND dateadd(DD, -3 , @batch_end_time) THEN DURATION END )   as 'p3'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -5 , @batch_end_time) AND dateadd(DD, -4 , @batch_end_time) THEN DURATION END )   as 'p4'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -6 , @batch_end_time) AND dateadd(DD, -5 , @batch_end_time) THEN DURATION END )   as 'p5'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -7 , @batch_end_time) AND dateadd(DD, -6 , @batch_end_time) THEN DURATION END )   as 'p6'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -8 , @batch_end_time) AND dateadd(DD, -7 , @batch_end_time) THEN DURATION END )   as 'p7'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -9 , @batch_end_time) AND dateadd(DD, -8 , @batch_end_time) THEN DURATION END )   as 'p8'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -10, @batch_end_time) AND dateadd(DD, -9 , @batch_end_time) THEN DURATION END )   as 'p9'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -11, @batch_end_time) AND dateadd(DD, -10, @batch_end_time) THEN DURATION END )   as 'p10'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -12, @batch_end_time) AND dateadd(DD, -11, @batch_end_time) THEN DURATION END )   as 'p11'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -13, @batch_end_time) AND dateadd(DD, -12, @batch_end_time) THEN DURATION END )   as 'p12'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -14, @batch_end_time) AND dateadd(DD, -13, @batch_end_time) THEN DURATION END )   as 'p13'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -15, @batch_end_time) AND dateadd(DD, -14, @batch_end_time) THEN DURATION END )   as 'p14'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -16, @batch_end_time) AND dateadd(DD, -15, @batch_end_time) THEN DURATION END )   as 'p15'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -17, @batch_end_time) AND dateadd(DD, -16, @batch_end_time) THEN DURATION END )   as 'p16'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -18, @batch_end_time) AND dateadd(DD, -17, @batch_end_time) THEN DURATION END )   as 'p17'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -19, @batch_end_time) AND dateadd(DD, -18, @batch_end_time) THEN DURATION END )   as 'p18'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -20, @batch_end_time) AND dateadd(DD, -19, @batch_end_time) THEN DURATION END )   as 'p19'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -21, @batch_end_time) AND dateadd(DD, -20, @batch_end_time) THEN DURATION END )   as 'p20'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -22, @batch_end_time) AND dateadd(DD, -21, @batch_end_time) THEN DURATION END )   as 'p21'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -23, @batch_end_time) AND dateadd(DD, -22, @batch_end_time) THEN DURATION END )   as 'p22'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -24, @batch_end_time) AND dateadd(DD, -23, @batch_end_time) THEN DURATION END )   as 'p23'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -25, @batch_end_time) AND dateadd(DD, -24, @batch_end_time) THEN DURATION END )   as 'p24'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -26, @batch_end_time) AND dateadd(DD, -25, @batch_end_time) THEN DURATION END )   as 'p25'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -27, @batch_end_time) AND dateadd(DD, -26, @batch_end_time) THEN DURATION END )   as 'p26'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -28, @batch_end_time) AND dateadd(DD, -27, @batch_end_time) THEN DURATION END )   as 'p27'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -29, @batch_end_time) AND dateadd(DD, -28, @batch_end_time) THEN DURATION END )   as 'p28'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -30, @batch_end_time) AND dateadd(DD, -29, @batch_end_time) THEN DURATION END )   as 'p29'
,       SUM(CASE WHEN START_TIME BETWEEN  dateadd(DD, -31, @batch_end_time) AND dateadd(DD, -30, @batch_end_time) THEN DURATION END )   as 'p30'
--,      convert(char(8),dateadd(ss,sum(avg_elapsed_seconds), '1/1/1900'),108) as total_elapsed_time  
FROM #REP_WF_RUN     bt  

SELECT t1.time_min
,      SUM( CASE WHEN t1.time_min BETWEEN START_TIME AND END_TIME THEN 1 ELSE 0 END) as 'job_count'
INTO  #concurrency_1
FROM   #REP_WF_RUN   --pc_rep..REP_WFLOW_RUN 
,      #times                t1
WHERE t1.time_min BETWEEN START_TIME AND END_TIME 
--AND   START_TIME  > dateadd(DD, -5, getdate() )  -- 'Mmm dd yyyy  hh:mm[AM|PM]'
GROUP  BY t1.time_min
--HAVING SUM( CASE WHEN time_min BETWEEN START_TIME AND END_TIME THEN 1 ELSE 0 END) > 0
ORDER BY t1.time_min

INSERT INTO  #concurrency_1
SELECT t1.time_min
,      0  as 'job_count'
FROM   #times                t1
WHERE NOT EXISTS (SELECT 1 FROM #REP_WF_RUN RWR WHERE t1.time_min BETWEEN RWR.START_TIME AND RWR.END_TIME )
GROUP BY t1.time_min
ORDER BY 1,2

SELECT  job_count
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -1 , @batch_end_time) AND dateadd(DD, -0 , @batch_end_time) THEN 1 END )   as 'latest_count'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -2 , @batch_end_time) AND dateadd(DD, -1 , @batch_end_time) THEN 1 END )   as 'p1'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -3 , @batch_end_time) AND dateadd(DD, -2 , @batch_end_time) THEN 1 END )   as 'p2'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -4 , @batch_end_time) AND dateadd(DD, -3 , @batch_end_time) THEN 1 END )   as 'p3'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -5 , @batch_end_time) AND dateadd(DD, -4 , @batch_end_time) THEN 1 END )   as 'p4'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -6 , @batch_end_time) AND dateadd(DD, -5 , @batch_end_time) THEN 1 END )   as 'p5'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -7 , @batch_end_time) AND dateadd(DD, -6 , @batch_end_time) THEN 1 END )   as 'p6'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -8 , @batch_end_time) AND dateadd(DD, -7 , @batch_end_time) THEN 1 END )   as 'p7'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -9 , @batch_end_time) AND dateadd(DD, -8 , @batch_end_time) THEN 1 END )   as 'p8'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -10, @batch_end_time) AND dateadd(DD, -9 , @batch_end_time) THEN 1 END )   as 'p9'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -11, @batch_end_time) AND dateadd(DD, -10, @batch_end_time) THEN 1 END )   as 'p10'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -12, @batch_end_time) AND dateadd(DD, -11, @batch_end_time) THEN 1 END )   as 'p11'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -13, @batch_end_time) AND dateadd(DD, -12, @batch_end_time) THEN 1 END )   as 'p12'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -14, @batch_end_time) AND dateadd(DD, -13, @batch_end_time) THEN 1 END )   as 'p13'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -15, @batch_end_time) AND dateadd(DD, -14, @batch_end_time) THEN 1 END )   as 'p14'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -16, @batch_end_time) AND dateadd(DD, -15, @batch_end_time) THEN 1 END )   as 'p15'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -17, @batch_end_time) AND dateadd(DD, -16, @batch_end_time) THEN 1 END )   as 'p16'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -18, @batch_end_time) AND dateadd(DD, -17, @batch_end_time) THEN 1 END )   as 'p17'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -19, @batch_end_time) AND dateadd(DD, -18, @batch_end_time) THEN 1 END )   as 'p18'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -20, @batch_end_time) AND dateadd(DD, -19, @batch_end_time) THEN 1 END )   as 'p19'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -21, @batch_end_time) AND dateadd(DD, -20, @batch_end_time) THEN 1 END )   as 'p20'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -22, @batch_end_time) AND dateadd(DD, -21, @batch_end_time) THEN 1 END )   as 'p21'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -23, @batch_end_time) AND dateadd(DD, -22, @batch_end_time) THEN 1 END )   as 'p22'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -24, @batch_end_time) AND dateadd(DD, -23, @batch_end_time) THEN 1 END )   as 'p23'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -25, @batch_end_time) AND dateadd(DD, -24, @batch_end_time) THEN 1 END )   as 'p24'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -26, @batch_end_time) AND dateadd(DD, -25, @batch_end_time) THEN 1 END )   as 'p25'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -27, @batch_end_time) AND dateadd(DD, -26, @batch_end_time) THEN 1 END )   as 'p26'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -28, @batch_end_time) AND dateadd(DD, -27, @batch_end_time) THEN 1 END )   as 'p27'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -29, @batch_end_time) AND dateadd(DD, -28, @batch_end_time) THEN 1 END )   as 'p28'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -30, @batch_end_time) AND dateadd(DD, -29, @batch_end_time) THEN 1 END )   as 'p29'
,       SUM(CASE WHEN time_min BETWEEN  dateadd(DD, -31, @batch_end_time) AND dateadd(DD, -30, @batch_end_time) THEN 1 END )   as 'p30'
--,      convert(char(8),dateadd(ss,sum(avg_elapsed_seconds), '1/1/1900'),108) as total_elapsed_time  
INTO  #conc_rep
FROM  #concurrency_1
GROUP BY job_count

SELECT   WORKFLOW_NAME 
,        latest_min
,        prev_run
,        wk_avg
,        month_avg
--,        CASE WHEN ra.latest_min - ra.wk_avg     > 5 THEN convert(char(7),ra.latest_min - ra.wk_avg)    ELSE '' END as 'wk_dev'
--,        CASE WHEN ra.latest_min - ra.month_avg  > 5 THEN convert(char(7),ra.latest_min - ra.month_avg) ELSE '' END as 'month_dev'
,        CASE WHEN abs(ra.latest_min - ra.wk_avg)     >= 5 THEN convert(char(7),ra.latest_min - ra.wk_avg)    ELSE '' END as 'wk_dev'
,        CASE WHEN abs(ra.latest_min - ra.month_avg)  >= 5 THEN convert(char(7),ra.latest_min - ra.month_avg) ELSE '' END as 'month_dev'
FROM #run_avg  ra
WHERE latest_min >= 10
--go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '2b) Last nights workflows that have had significant performance swings : '
PRINT '   - wk_dev and month_dev are deviations from averages, only shown when >= 5 min '
PRINT '-------------------------------------------------'
PRINT ''

SELECT convert(char(50),t1.WORKFLOW_NAME) as 'WORKFLOW_1'
,      convert(char(50),t2.WORKFLOW_NAME) as 'WORKFLOW_2'
--,      convert(char(20),t2.SUBJECT_AREA)  as 'SUBJECT_AREA'
,       t2.WORKFLOW_RUN_ID
,       t2.RUN_STATUS_CODE
,       t1.START_TIME                      as "START_TIME_1"  
,       t1.END_TIME                        as "END_TIME_1"   
,       t2.START_TIME                      as "START_TIME_2" 
,       t2.END_TIME                        as "END_TIME_2"   
,       datediff(mi,t1.END_TIME, t2.START_TIME)               as 'idle_minutes'
INTO #run_current 
FROM #REP_WF_RUN  t1
,    #REP_WF_RUN  t2
WHERE t2.WORKFLOW_RUN_ID *= t1.WORKFLOW_RUN_ID + 1
AND    t1.START_TIME  > dateadd(DD, -1, @batch_end_time)  -- 'Mmm dd yyyy  hh:mm[AM|PM]'
AND    t2.START_TIME  > dateadd(DD, -1, @batch_end_time)  -- 'Mmm dd yyyy  hh:mm[AM|PM]'
--AND    datediff(mi,t1.END_TIME, t2.START_TIME) > 1
--AND    t2.WORKFLOW_ID NOT IN (5181,4964,5543,4965,6281,5215)
--AND    t1.WORKFLOW_ID NOT IN (5181,4964,5543,4965,6281,5215)
go

SELECT   convert(char(35),rc.WORKFLOW_2) as 'workflow_name'  
,        convert(char(6),rc.RUN_STATUS_CODE)   as 'status'
,        CASE WHEN idle_minutes  > 1 THEN convert(char(7),idle_minutes) ELSE '' END  as 'idle min'
,        substring(convert(char(8),rc.START_TIME_2, 108),1,5)     as  'start'
,        substring(convert(char(8),rc.END_TIME_2, 108),1,5)     as  'finsh'
,        convert(char(7),ra.latest_min)     as 'run_min'
,        convert(char(7),ra.prev_run)       as  'prev_run'     
--,        convert(char(7),ra.week_ago)     as  'week_ago' 
,        convert(char(7),ra.wk_avg)         as  'wk_avg'     
--,        convert(char(7),ra.wk_avg_prev)    as  'wk_avg_prev'
,        convert(char(7),ra.month_avg)      as  'month_avg'  
,        CASE WHEN abs(ra.latest_min - ra.wk_avg)     >= 5 THEN convert(char(7),ra.latest_min - ra.wk_avg)    ELSE '' END as 'wk_dev'
,        CASE WHEN abs(ra.latest_min - ra.month_avg)  >= 5 THEN convert(char(7),ra.latest_min - ra.month_avg) ELSE '' END as 'month_dev'
FROM #run_current  rc
,    #run_avg      ra
WHERE rc.WORKFLOW_2 = ra.WORKFLOW_NAME 
AND  (abs(ra.latest_min - ra.wk_avg)     >= 5 
      OR  abs(ra.latest_min - ra.month_avg)  >= 5 )
--AND  rc.WORKFLOW_RUN_ID >= (SELECT max(WORKFLOW_RUN_ID) - 40 FROM #run_current )
ORDER BY rc.START_TIME_2
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '3) any idle time between workflows in previous batch run: '
PRINT '-------------------------------------------------'
PRINT ''

SELECT   convert(char(30),WORKFLOW_1)  as 'WORKFLOW_1'
,        convert(char(30),WORKFLOW_2)  as 'WORKFLOW_2'
--,        SUBJECT_AREA
--,        substring(convert(char(8),START_TIME_1, 108),1,5)   as  'START_TIME_1'
,        substring(convert(char(8),END_TIME_1, 108),1,5)     as  'END_TIME_1'
,        substring(convert(char(8),START_TIME_2, 108),1,5)   as  'START_TIME_2'
,        idle_minutes
FROM  #run_current
WHERE idle_minutes > 1
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '4a) Incomplete batches from last nights run : '
PRINT '-------------------------------------------------'
PRINT ''

SELECT ra.WORKFLOW_NAME 
INTO #unrun 
FROM #run_avg  ra
WHERE NOT EXISTS (SELECT 1 FROM #run_current rc WHERE rc.WORKFLOW_2 = ra.WORKFLOW_NAME )
--WHERE ra.WORKFLOW_NAME  in ( 'b_RFRM_Daily_AEQF_Anvil','b_RFRM_Daily','b_RFRM_LargeExposure','b_RFRM_Monthly_AEQF_Anvil','b_RFRM_Monthly','b_InternalExtracts_Daily', 'b_MART_MIST_Qualification','b_MART_RIMS_Qualification_Account','b_MART_RIMS_Qualification_Trade'  )  -- test sample data
go

SELECT   ra.WORKFLOW_NAME 
,        prev_run     
,        week_ago 
,        wk_avg
,        month_avg
,        round(1.05 * month_avg,0)  as 'month_avg_est'  -- note 5% used for this report, not 10%
,        min_start
INTO  #unrun_2
FROM  #run_avg      ra
WHERE ra.WORKFLOW_NAME in (SELECT WORKFLOW_NAME FROM #unrun)
ORDER BY ra.min_start
go

SELECT   convert(char(35),ra.WORKFLOW_NAME) as 'workflow_name'
,        convert(char(7),ra.prev_run)       as  'prev_run'     
,        convert(char(7),ra.week_ago)       as  'week_ago' 
,        convert(char(7),ra.wk_avg)         as  'wk_avg'     
,        convert(char(7),ra.month_avg)      as  'month_avg'
,        min_start
FROM   #unrun_2 ra
ORDER BY min_start
go

SELECT  ra.WORKFLOW_NAME
,        round(1.10 *  ra.month_avg,0)                     as 'month_avg_est'
,        datediff(mi,rc.START_TIME_1, getdate() )          as 'run_portion_min'
,        round(1.10 *  ra.month_avg,0) - datediff(mi,rc.START_TIME_1, getdate() )  as 'unrun_portion_min'
INTO #running
FROM #run_avg  ra
,    #run_current rc 
WHERE rc.WORKFLOW_2 = ra.WORKFLOW_NAME 
AND   rc.RUN_STATUS_CODE in (6) 
go

CREATE TABLE #etas ( 
         WORKFLOW_NAME   varchar(35)
,        run_minutes     int      NULL
,        minutes_to_go   int      NULL
)
go

INSERT #etas
SELECT   WORKFLOW_NAME  = 'Currently running job'
,        run_minutes    = CASE WHEN unrun_portion_min < 0 THEN 1 ELSE unrun_portion_min END
,        minutes_to_go  = CASE WHEN unrun_portion_min < 0 THEN 1 ELSE unrun_portion_min END
FROM #running
go

INSERT #etas
SELECT   WORKFLOW_NAME  = 'Any unrun datamart jobs'
,        run_minutes    = ISNULL(sum(month_avg_est),0)
,        minutes_to_go  = ISNULL(sum(month_avg_est),0) + (SELECT sum(run_minutes) FROM #etas)
FROM #unrun_2
WHERE WORKFLOW_NAME NOT LIKE '%RFRM%'
AND   WORKFLOW_NAME NOT LIKE '%Extract%'
AND   WORKFLOW_NAME NOT LIKE '%Recon%'
go

INSERT #etas
SELECT   WORKFLOW_NAME  = 'b_InternalExtracts_Daily'
,        run_minutes    = month_avg_est
,        minutes_to_go  = ISNULL(month_avg_est,0) + (SELECT sum(run_minutes) FROM #etas)
FROM #unrun_2
WHERE WORKFLOW_NAME = 'b_InternalExtracts_Daily'
go

INSERT #etas
SELECT   WORKFLOW_NAME  = 'b_RFRM_Daily_AEQF_Anvil'
,        run_minutes    = ISNULL(month_avg_est,0)
,        minutes_to_go  = ISNULL(month_avg_est,0) + (SELECT sum(run_minutes) FROM #etas)
FROM #unrun_2
WHERE WORKFLOW_NAME = 'b_RFRM_Daily_AEQF_Anvil'
go

INSERT #etas
SELECT   WORKFLOW_NAME  = 'b_RFRM_Daily'
,        run_minutes    = month_avg_est
,        minutes_to_go  = ISNULL(month_avg_est,0) + (SELECT sum(run_minutes) FROM #etas)
FROM #unrun_2
WHERE WORKFLOW_NAME = 'b_RFRM_Daily'
go

INSERT #etas
SELECT   WORKFLOW_NAME  = 'b_RFRM_Monthly_AEQF_Anvil'
,        run_minutes    = month_avg_est
,        minutes_to_go  = ISNULL(month_avg_est,0) + (SELECT sum(run_minutes) FROM #etas)
FROM #unrun_2
WHERE WORKFLOW_NAME = 'b_RFRM_Monthly_AEQF_Anvil'
AND ((SELECT working_day_of_month FROM ukrr_mart..date_dimension WHERE calendar_date = convert(char(8),dateadd(dd,-1,getdate()),112) ) BETWEEN 1 AND 7
     OR (SELECT last_day_of_month_flag FROM ukrr_mart..date_dimension WHERE calendar_date = convert(char(8),dateadd(dd,-1,getdate()),112) ) = 'Y'   )
go

INSERT #etas
SELECT   WORKFLOW_NAME  = 'b_RFRM_Monthly'
,        run_minutes    = month_avg_est
,        minutes_to_go  = ISNULL(month_avg_est,0) + (SELECT sum(run_minutes) FROM #etas)
FROM #unrun_2
WHERE WORKFLOW_NAME = 'b_RFRM_Monthly'
AND ((SELECT working_day_of_month FROM ukrr_mart..date_dimension WHERE calendar_date = convert(char(8),dateadd(dd,-1,getdate()),112) ) BETWEEN 1 AND 7
     OR (SELECT last_day_of_month_flag FROM ukrr_mart..date_dimension WHERE calendar_date = convert(char(8),dateadd(dd,-1,getdate()),112) ) = 'Y'   )
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '4b) ETAs for these incomplete batches from last nights run : '
PRINT '-------------------------------------------------'
PRINT ''

SELECT convert(char(35),WORKFLOW_NAME) as 'workflow_name' 
,      run_minutes
,      minutes_to_go = substring(convert(char(8),dateadd(mi,minutes_to_go, '1/1/1900'), 108),1,5)   
,      now =  substring(convert(char(8),getdate(), 108),1,5)   
,      eta =  substring(convert(char(8),dateadd(mi,minutes_to_go, getdate()), 108),1,5)   
FROM #etas
WHERE WORKFLOW_NAME NOT LIKE 'b_RFRM_%_AEQF%'  -- shown for this report 
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '5) all batches from last nights run : '
PRINT '-------------------------------------------------'
PRINT ''

SELECT   convert(char(35),rc.WORKFLOW_2) as 'workflow_name'  
,        substring(convert(char(8),rc.START_TIME_2, 108),1,5)     as  'start'
,        substring(convert(char(8),rc.END_TIME_2, 108),1,5)     as  'finsh'
,        CASE WHEN idle_minutes  > 1 THEN convert(char(4),idle_minutes) ELSE '' END  as 'idle'
,        convert(char(7),ra.latest_min)     as 'run_min'
,        ISNULL(convert(char(6),ra.prev_run),'')       as  'prev_1'     
,        ISNULL(convert(char(6),ra.week_ago),'')       as  'wk_ago' 
,        convert(char(6),ra.wk_avg)         as  'wk_av'     
,        convert(char(6),ra.wk_avg_prev)    as  'wk_av_prev'
,        convert(char(6),ra.month_avg)      as  'mon_avg'  
,        CASE WHEN ra.latest_min - ra.wk_avg     >= 5 THEN convert(char(7),ra.latest_min - ra.wk_avg)    ELSE '' END as 'wk_dev'
,        CASE WHEN ra.latest_min - ra.month_avg  >= 5 THEN convert(char(7),ra.latest_min - ra.month_avg) ELSE '' END as 'mon_dev'
,        ISNULL(convert(varchar(3),ra.p1),'')      as  'p1'  
,        ISNULL(convert(varchar(3),ra.p2),'')      as  'p2'  
,        ISNULL(convert(varchar(3),ra.p3),'')      as  'p3'  
,        ISNULL(convert(varchar(3),ra.p4),'')      as  'p4'  
,        ISNULL(convert(varchar(3),ra.p5),'')      as  'p5'  
,        ISNULL(convert(varchar(3),ra.p6),'')      as  'p6'  
,        ISNULL(convert(varchar(3),ra.p7),'')      as  'p7'  
FROM #run_current  rc
,    #run_avg      ra
WHERE rc.WORKFLOW_2 = ra.WORKFLOW_NAME 
ORDER BY rc.START_TIME_2
--,        ra.latest_min DESC

go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '6) minute duration summary by job type : '
PRINT '-------------------------------------------------'
PRINT ''

SELECT  convert(char(13),type )                 as 'type'
,   latest_min                                  as 'latest' 
,   ISNULL(convert(char(4),p1  ) , ' ')         as 'p1'
,   ISNULL(convert(char(4),p2  ) , ' ')         as 'p2'
,   ISNULL(convert(char(4),p3  ) , ' ')         as 'p3'
,   ISNULL(convert(char(4),p4  ) , ' ')         as 'p4'
,   ISNULL(convert(char(4),p5  ) , ' ')         as 'p5'
,   ISNULL(convert(char(4),p6  ) , ' ')         as 'p6'
,   ISNULL(convert(char(4),p7  ) , ' ')         as 'p7'
,   ISNULL(convert(char(4),p8  ) , ' ')         as 'p8'
,   ISNULL(convert(char(4),p9  ) , ' ')         as 'p9'
,   ISNULL(convert(char(4),p10 ) , ' ')           as 'p10'
,   ISNULL(convert(char(4),p11 ) , ' ')           as 'p11'
,   ISNULL(convert(char(4),p12 ) , ' ')           as 'p12'
,   ISNULL(convert(char(4),p13 ) , ' ')           as 'p13'
,   ISNULL(convert(char(4),p14 ) , ' ')           as 'p14'
,   ISNULL(convert(char(4),p15 ) , ' ')           as 'p15'
,   ISNULL(convert(char(4),p16 ) , ' ')           as 'p16'
--,   ISNULL(convert(char(4),p17 ) , ' ')           as 'p17'  - this week removed to make fit in screen width as now char(4)
--,   ISNULL(convert(char(4),p18 ) , ' ')           as 'p18'
--,   ISNULL(convert(char(4),p19 ) , ' ')           as 'p19'
--,   ISNULL(convert(char(4),p20 ) , ' ')           as 'p20'
--,   ISNULL(convert(char(4),p21 ) , ' ')           as 'p21'
--,   ISNULL(convert(char(4),p22 ) , ' ')           as 'p22'
--,   ISNULL(convert(char(4),p23 ) , ' ')           as 'p23'
,   ISNULL(convert(char(4),p24 ) , ' ')           as 'p24'
,   ISNULL(convert(char(4),p25 ) , ' ')           as 'p25'
,   ISNULL(convert(char(4),p26 ) , ' ')           as 'p26'
,   ISNULL(convert(char(4),p27 ) , ' ')           as 'p27'
,   ISNULL(convert(char(4),p28 ) , ' ')           as 'p28'
,   ISNULL(convert(char(4),p29 ) , ' ')           as 'p29'
,   ISNULL(convert(char(4),p30 ) , ' ')           as 'p30'
FROM  #type_sum
ORDER BY type
--go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '7a) Concurrency report'
PRINT '  - shows the number of (concurrent if > 1) Informatica workflows running at 1 minute sample points through the batch window'
PRINT '  - reporting for hours between 10pm and 8am'
PRINT '  - idle time shows as 0'
PRINT '  - The last row is the delivery time of the Internal Liquidity report shows as H:M for space ie 07:45-> 7:4, 10:24->0:2 - should work.. '
PRINT '-------------------------------------------------'
PRINT ''

SELECT WORKFLOW_NAME = CASE WORKFLOW_NAME WHEN 'b_InternalExtracts_Daily' THEN 'ILR_done' WHEN 'b_RFRM_Daily' THEN 'RFRM_done' ELSE SUBSTRING(WORKFLOW_NAME,1,10) END
,   latest  = ISNULL(SUBSTRING(latest ,2,3) , ' ')
,   p1  = ISNULL(SUBSTRING(p1 ,2,3) , ' ')
,   p2  = ISNULL(SUBSTRING(p2 ,2,3) , ' ')
,   p3  = ISNULL(SUBSTRING(p3 ,2,3) , ' ')
,   p4  = ISNULL(SUBSTRING(p4 ,2,3) , ' ')
,   p5  = ISNULL(SUBSTRING(p5 ,2,3) , ' ')
,   p6  = ISNULL(SUBSTRING(p6 ,2,3) , ' ')
,   p7  = ISNULL(SUBSTRING(p7 ,2,3) , ' ')
,   p8  = ISNULL(SUBSTRING(p8 ,2,3) , ' ')
,   p9  = ISNULL(SUBSTRING(p9 ,2,3) , ' ')
,   p10 = ISNULL(SUBSTRING(p10,2,3) , ' ')
,   p11 = ISNULL(SUBSTRING(p11,2,3) , ' ')
,   p12 = ISNULL(SUBSTRING(p12,2,3) , ' ')
,   p13 = ISNULL(SUBSTRING(p13,2,3) , ' ')
,   p14 = ISNULL(SUBSTRING(p14,2,3) , ' ')
,   p15 = ISNULL(SUBSTRING(p15,2,3) , ' ')
,   p16 = ISNULL(SUBSTRING(p16,2,3) , ' ')
,   p17 = ISNULL(SUBSTRING(p17,2,3) , ' ')
,   p18 = ISNULL(SUBSTRING(p18,2,3) , ' ')
,   p19 = ISNULL(SUBSTRING(p19,2,3) , ' ')
,   p20 = ISNULL(SUBSTRING(p20,2,3) , ' ')
,   p21 = ISNULL(SUBSTRING(p21,2,3) , ' ')
,   p22 = ISNULL(SUBSTRING(p22,2,3) , ' ')
,   p23 = ISNULL(SUBSTRING(p23,2,3) , ' ')
,   p24 = ISNULL(SUBSTRING(p24,2,3) , ' ')
,   p25 = ISNULL(SUBSTRING(p25,2,3) , ' ')
,   p26 = ISNULL(SUBSTRING(p26,2,3) , ' ')
,   p27 = ISNULL(SUBSTRING(p27,2,3) , ' ')
,   p28 = ISNULL(SUBSTRING(p28,2,3) , ' ')
,   p29 = ISNULL(SUBSTRING(p29,2,3) , ' ')
,   p30 = ISNULL(SUBSTRING(p30,2,3) , ' ')
INTO #milestones_2
FROM #milestones
go

SELECT  convert(char(10),job_count )            as 'job_count'
,   ISNULL(convert(char(3),latest_count  ) , ' ')         as 'latest_min_count'
,   ISNULL(convert(char(3),p1  ) , ' ')         as 'p1'
,   ISNULL(convert(char(3),p2  ) , ' ')         as 'p2'
,   ISNULL(convert(char(3),p3  ) , ' ')         as 'p3'
,   ISNULL(convert(char(3),p4  ) , ' ')         as 'p4'
,   ISNULL(convert(char(3),p5  ) , ' ')         as 'p5'
,   ISNULL(convert(char(3),p6  ) , ' ')         as 'p6'
,   ISNULL(convert(char(3),p7  ) , ' ')         as 'p7'
,   ISNULL(convert(char(3),p8  ) , ' ')         as 'p8'
,   ISNULL(convert(char(3),p9  ) , ' ')         as 'p9'
,   ISNULL(convert(char(3),p10 ) , ' ')           as 'p10'
,   ISNULL(convert(char(3),p11 ) , ' ')           as 'p11'
,   ISNULL(convert(char(3),p12 ) , ' ')           as 'p12'
,   ISNULL(convert(char(3),p13 ) , ' ')           as 'p13'
,   ISNULL(convert(char(3),p14 ) , ' ')           as 'p14'
,   ISNULL(convert(char(3),p15 ) , ' ')           as 'p15'
,   ISNULL(convert(char(3),p16 ) , ' ')           as 'p16'
,   ISNULL(convert(char(3),p17 ) , ' ')           as 'p17'  -- this week removed to make fit in screen width as now char(4)
,   ISNULL(convert(char(3),p18 ) , ' ')           as 'p18'
,   ISNULL(convert(char(3),p19 ) , ' ')           as 'p19'
,   ISNULL(convert(char(3),p20 ) , ' ')           as 'p20'
,   ISNULL(convert(char(3),p21 ) , ' ')           as 'p21'
,   ISNULL(convert(char(3),p22 ) , ' ')           as 'p22'
,   ISNULL(convert(char(3),p23 ) , ' ')           as 'p23'
,   ISNULL(convert(char(3),p24 ) , ' ')           as 'p24'
,   ISNULL(convert(char(3),p25 ) , ' ')           as 'p25'
,   ISNULL(convert(char(3),p26 ) , ' ')           as 'p26'
,   ISNULL(convert(char(3),p27 ) , ' ')           as 'p27'
,   ISNULL(convert(char(3),p28 ) , ' ')           as 'p28'
,   ISNULL(convert(char(3),p29 ) , ' ')           as 'p29'
,   ISNULL(convert(char(3),p30 ) , ' ')           as 'p30'
FROM  #conc_rep
UNION
SELECT * FROM #milestones_2 WHERE WORKFLOW_NAME in ('ILR_done', '(bus_date)' ) 
ORDER BY 1
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '7b) expands the first count by hour so last nights periods of highest concurrency and idle time can be seen'
PRINT '-------------------------------------------------'
PRINT ''

SELECT  convert(char(9),  time_min, 112) + substring(convert(char(8),  time_min, 108),1,3) + '00'  as "hour"
,      job_count
,      count(*)  as 'minute_instance_count'
FROM   #concurrency_1
WHERE  time_min > (SELECT dateadd(hh,21 ,max(calendar_date)) FROM ukrr_mart..date_dimension WHERE calendar_date < convert(char(8),getdate(),112) AND working_day_flag = 'Y' )
GROUP BY convert(char(9),  time_min, 112) + substring(convert(char(8),  time_min, 108),1,3) + '00'
,        job_count
ORDER BY 1,2
go

quit

/*
