/*********************************************************************************************
#  Name     : ~ukrr_pm/scripts/sql/db_check.sql
#  Purpose  : .sql report to check all UKRR DBs on a newly built / loaded ASE instance have been loaded and onlined correctly.
#           : Also checks user suid's have been added to the required DBs
#  Usage    :  call_sql.sh db_check ${SN} "name.surname@rbccm.com"
#           :  alias dbc='call_sql.sh db_check ${SN} "simon.osborne@rbccm.com"'
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  01/11/2010   S Osborne       Created
#
#*********************************************************************************************/

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT 'HOW TO INTERPRET THIS REPORT:'
PRINT '  - if there are errors in section 1), then fix those first and then rerun the report'
PRINT '  - as the errors in the first section will cause the later sections to not run correctly'
PRINT '-------------------------------------------------'
PRINT ''

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '1) checking the DBs are onlined on a newly built / loaded ASE instance: '
PRINT '  - EXPECTED RESULTS : blank = no errors '
PRINT '-------------------------------------------------'
PRINT ''

SET nocount ON
go

USE ukrr_rims
go

USE ukrr_ribs
go

USE ukrr_offs
go

USE ukrr_acbs
go

USE ukrr_igcp
go

USE ukrr_inft
go

USE ukrr_mktd
go

USE ukrr_anvl
go

USE ukrr_ccms
go

USE ukrr_gclt
go

USE ukrr_mart
go

USE ukrr_geqd
go

USE ukrr_slim
go

USE ukrr_obi
go

USE pc_rep
go

USE pc_domain
go

--DROP TABLE #users
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '2) checking that all the required usernames in master.dbo.syslogins are in sync with PROD: '
PRINT '  - EXPECTED RESULTS : all OK = no errors  / no rows with "OUT_OF_SYNC" '
PRINT '-------------------------------------------------'
PRINT ''

CREATE TABLE #prod_suids ( name varchar(20), suid int )
go

INSERT #prod_suids VALUES ('pm_repo'  , 13 )
INSERT #prod_suids VALUES ('slim'     , 82 )
INSERT #prod_suids VALUES ('srdr'     , 60 )
INSERT #prod_suids VALUES ('ukrr'     ,  7 )
INSERT #prod_suids VALUES ('ukrr_pm'  , 20 )
go

SELECT
        Server_name = convert(char(17), @@servername),
        Login_name = convert(char(12), m.name),
        Default_db = convert(char(12), m.dbname),
        --Is_Alias   = NULL,
        status = CASE m.status WHEN 2 THEN 'locked' WHEN 4 then 'expired' ELSE 'current' END,  
        local_suid = m.suid,
        PROD_suid  = tp.suid,
        sync_check = CASE WHEN m.suid <> tp.suid THEN 'OUT_OF_SYNC' ELSE 'OK' END
FROM    master.dbo.syslogins m
,       #prod_suids          tp
WHERE   m.name in ('ukrr','ukrr_pm','pm_repo','slim','srdr'  ) 
AND     tp.name = m.name 
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '3) usernames that have not been added to the required DBs - fix with sp_adduser : '
PRINT '  - EXPECTED RESULTS : blank = no errors '
PRINT '-------------------------------------------------'
PRINT ''

SELECT  db_name    = 'ukrr_ctrl', User_name  = u.name, Group_name = g.name, u.uid, u.suid
INTO  #users
FROM    ukrr_ctrl..sysusers u, ukrr_ctrl..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
go

INSERT #users
SELECT  db_name    = 'ukrr_acbs', User_name  = u.name, Group_name = g.name, u.uid, u.suid
FROM    ukrr_acbs..sysusers u, ukrr_acbs..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
UNION ALL
SELECT  db_name    = 'ukrr_anvl', User_name  = u.name, Group_name = g.name, u.uid, u.suid
FROM    ukrr_anvl..sysusers u, ukrr_anvl..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
UNION ALL
SELECT  db_name    = 'ukrr_ccms', User_name  = u.name, Group_name = g.name, u.uid, u.suid
FROM    ukrr_ccms..sysusers u, ukrr_ccms..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
UNION ALL
SELECT  db_name    = 'ukrr_ebs', User_name  = u.name, Group_name = g.name, u.uid, u.suid
FROM    ukrr_ebs..sysusers u, ukrr_ebs..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
UNION ALL
SELECT  db_name    = 'ukrr_gclt', User_name  = u.name, Group_name = g.name, u.uid, u.suid
FROM    ukrr_gclt..sysusers u, ukrr_gclt..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
UNION ALL
SELECT  db_name    = 'ukrr_geqd', User_name  = u.name, Group_name = g.name, u.uid, u.suid
FROM    ukrr_geqd..sysusers u, ukrr_geqd..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
UNION ALL
SELECT  db_name    = 'ukrr_igcp', User_name  = u.name, Group_name = g.name, u.uid, u.suid
FROM    ukrr_igcp..sysusers u, ukrr_igcp..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
UNION ALL
SELECT  db_name    = 'ukrr_inft', User_name  = u.name, Group_name = g.name, u.uid, u.suid
FROM    ukrr_inft..sysusers u, ukrr_inft..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
UNION ALL
SELECT  db_name    = 'ukrr_mart', User_name  = u.name, Group_name = g.name, u.uid, u.suid
FROM    ukrr_mart..sysusers u, ukrr_mart..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
UNION ALL
SELECT  db_name    = 'ukrr_mist', User_name  = u.name, Group_name = g.name, u.uid, u.suid
FROM    ukrr_mist..sysusers u, ukrr_mist..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
UNION ALL
SELECT  db_name    = 'ukrr_mktd', User_name  = u.name, Group_name = g.name, u.uid, u.suid
FROM    ukrr_mktd..sysusers u, ukrr_mktd..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
UNION ALL
SELECT  db_name    = 'ukrr_obi', User_name  = u.name, Group_name = g.name, u.uid, u.suid
FROM    ukrr_obi..sysusers u, ukrr_obi..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
UNION ALL
SELECT  db_name    = 'ukrr_offs', User_name  = u.name, Group_name = g.name, u.uid, u.suid
FROM    ukrr_offs..sysusers u, ukrr_offs..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
UNION ALL
SELECT  db_name    = 'ukrr_ribs', User_name  = u.name, Group_name = g.name, u.uid, u.suid
FROM    ukrr_ribs..sysusers u, ukrr_ribs..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
UNION ALL
SELECT  db_name    = 'ukrr_slim', User_name  = u.name, Group_name = g.name, u.uid, u.suid
FROM    ukrr_slim..sysusers u, ukrr_slim..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
UNION ALL
SELECT  db_name    = 'ukrr_rims', User_name  = u.name, Group_name = g.name, u.uid, u.suid
FROM    ukrr_rims..sysusers u, ukrr_rims..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
UNION ALL
SELECT  db_name    = 'pc_domain', User_name  = u.name, Group_name = g.name, u.uid, u.suid
FROM    pc_domain..sysusers u, pc_domain..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
UNION ALL
SELECT  db_name    = 'pc_rep', User_name  = u.name, Group_name = g.name, u.uid, u.suid
FROM    pc_rep..sysusers u, pc_rep..sysusers g  where   u.gid  = g.uid and     u.uid  != u.gid
go

select
        Server_name = convert(char(17), @@servername),
        Login_name = convert(char(12), m.name),
        User_name  = convert(char(12), u.User_name),
        Group_name = convert(char(12), u.Group_name),
        db_name    = convert(char(12), u.db_name),
        Default_db = convert(char(12), m.dbname),
        --Is_Alias   = NULL,
        u.uid,
        m.suid,
        status = CASE m.status WHEN 2 THEN 'locked' WHEN 4 then 'expired' ELSE 'current' END  
INTO #users2
from   #users u, master.dbo.syslogins m
where   u.suid = m.suid
AND    m.name in ('ukrr','ukrr_pm','pm_repo','slim','srdr'  ) 
ORDER BY 1,2,3,4


--user ukrr checks:
SELECT Username  = 'ukrr', 'not_in_this_db' = name 
FROM master..sysdatabases sd
WHERE suid != 1 
AND name NOT in ('tempdb','master_temp','pc_mr','powermart','powermart_7','ukrr_rats' )  
AND NOT EXISTS (SELECT 1 FROM #users2 t1 WHERE sd.name = t1.db_name AND Login_name = 'ukrr' )
UNION ALL
--user ukrr_pm checks:
SELECT Username  = 'ukrr_pm', 'not_in_this_db' = name 
FROM master..sysdatabases sd
WHERE suid != 1 
AND name NOT in ('tempdb','master_temp','pc_mr','powermart','powermart_7','ukrr_rats' )  
AND name NOT in ('pc_domain','pc_rep' )  
AND NOT EXISTS (SELECT 1 FROM #users2 t1 WHERE sd.name = t1.db_name AND Login_name = 'ukrr_pm' )
UNION ALL
--user slim checks:
SELECT Username  = 'slim', 'not_in_this_db' = name 
FROM master..sysdatabases sd
WHERE name in ('ukrr_obi','ukrr_slim' )  
AND NOT EXISTS (SELECT 1 FROM #users2 t1 WHERE sd.name = t1.db_name AND Login_name = 'slim' )
UNION ALL
--user srdr checks:
SELECT Username  = 'srdr', 'not_in_this_db' = name 
FROM master..sysdatabases sd
WHERE name in ('ukrr_mktd' )  
AND NOT EXISTS (SELECT 1 FROM #users2 t1 WHERE sd.name = t1.db_name AND Login_name = 'srdr' )
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '4) all UKRR batch / system users : '
PRINT '  - EXPECTED RESULTS : users ukrr, ukrr_pm, pm_repo, slim and srdr existing in correct databases with suid being the same as on PROD'
PRINT '  - EXPECTED RESULTS : user ukrr being DBO for all ukrr_* DBs and user pm_repo being DBO for all pm_* DBs as on PROD'
PRINT '-------------------------------------------------'
PRINT ''

SELECT * FROM #users2
go

quit

/*

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '5) Getting the max dates of each database to check correct dumps have been loaded  : '
PRINT '  - note the four remote DB pull databases that should have data for an extra day are: ukrr_ccms, ukrr_gclt, ukrr_igcp, ukrr_srdr'
PRINT '  - EXPECTED RESULTS: max_date = one day before the dumps were taken  '
PRINT '-------------------------------------------------'
PRINT ''

 SELECT 'db_name  ' ,  'max_date'
 SELECT 'ukrr_rims' ,  convert(char(8), max(data_load_date),112)     FROM ukrr_rims..cnld
UNION
 SELECT 'ukrr_ribs' ,  convert(char(8), max(DW_Data_Load_Date),112)  FROM ukrr_ribs..ribs_cnld
UNION
 SELECT 'ukrr_ebs' ,  convert(char(8), max(DW_Data_Load_Date),112)  FROM ukrr_ebs..ebs_cnld
UNION
 SELECT 'ukrr_offs' ,  convert(char(8), max(dw_data_load_date),112)  FROM ukrr_offs..guernsey_placements
UNION
 SELECT 'ukrr_acbs' ,  convert(char(8), max(DW_Data_Load_Date),112)  FROM ukrr_acbs..acbs_cnld
UNION
 SELECT 'ukrr_igcp' ,  convert(char(8), max(dw_data_load_date),112)  FROM ukrr_igcp..gcp_infinity_report_summary
UNION
 SELECT 'ukrr_inft' ,  convert(char(8), max(dw_data_load_date),112)  FROM ukrr_inft..infinity52_tradesecxref
UNION
 SELECT 'ukrr_mktd' , convert(char(8), max(update_datetime),112)     FROM ukrr_mktd..srdr_ratings_landing
UNION
 SELECT 'ukrr_anvl' , convert(char(8), max(data_load_date),112)      FROM ukrr_anvl..anvil_extract
UNION
 SELECT 'ukrr_ccms' , convert(char(8), max(dw_data_load_date),112)   FROM ukrr_ccms..cid_facility_extract
UNION
 SELECT 'ukrr_gclt' , convert(char(8), max(data_load_date),112)      FROM ukrr_gclt..global_client_extract
UNION
 SELECT 'ukrr_mart' , convert(char(8), max(dw_data_load_date),112)   FROM ukrr_mart..security_dimension
UNION
 SELECT 'ukrr_geqd' , convert(char(8), max(dw_data_load_date),112)   FROM ukrr_geqd..security_adr_eq_bond
 ORDER BY 2, 1

go


PROD :

 Server_name       Login_name   Default_db   suid        status
 ----------------- ------------ ------------ ----------- -------
 LNPEUR2_DS        pm_repo      pc_domain             13 current
 LNPEUR2_DS        slim         ukrr_slim             82 current
 LNPEUR2_DS        srdr         ukrr_mktd             60 current
 LNPEUR2_DS        ukrr         ukrr_mart              7 current
 LNPEUR2_DS        ukrr_pm      ukrr_mart             20 current


