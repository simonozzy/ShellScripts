/*********************************************************************************************
#  Name     : ~ukrr_pm/scripts/sql/batch_status_report.sql
#  Purpose  : .sql report to finish times of key UKRR jobs compared to their 'SLA' times
#  Usage    :  call_sql.sh batch_status_report.sql ${SN}  "simon.osborne@rbccm.com"
#           :  00 7,8,9 * * 2-6 /home/ukrr_pm/scripts/report_master.sh batch_status_report.sql email "simon.osborne@rbccm.com GlobalOps&FinanceSupport@rbccm.com" 'UKRR batch status report'  # +GlobalOperations&FinanceApplicationSupport
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  10/01/2008   S Osborne       Created
#
#*********************************************************************************************/

SET nocount ON

SELECT  SUBJECT_AREA
,       WORKFLOW_NAME
,       WORKFLOW_ID
--,       WORKFLOW_RUN_ID
,       START_TIME
,       END_TIME
,       RUN_STATUS_CODE
INTO   #REP_WF_RUN 
FROM   pc_rep..REP_WFLOW_RUN 
WHERE  1  = 2
go

ALTER TABLE #REP_WF_RUN add WORKFLOW_RUN_ID int identity
go

INSERT #REP_WF_RUN
SELECT  SUBJECT_AREA
,       WORKFLOW_NAME
,       WORKFLOW_ID
--,       WORKFLOW_RUN_ID
,       START_TIME
,       END_TIME
,       RUN_STATUS_CODE
FROM   pc_rep..REP_WFLOW_RUN 
WHERE  START_TIME  >= dateadd(DD, -35, getdate())  
--AND    RUN_STATUS_CODE in ( 1, 6) 
AND   WORKFLOW_NAME NOT  IN ('b_CollectINFT_InterestCurve','b_GED_Collect','s_CollectGCPInfinityProfile','s_CollectGCPInfinityCDO','s_CollectType1_OrgUnitDimension','b_CollectRIMS_WK' ) 
--AND   WORKFLOW_NAME NOT  LIKE '%Perm_Acc%'  AND   WORKFLOW_NAME NOT  LIKE '%Trade_Daily%'  
ORDER BY START_TIME
go

DECLARE @batch_end_time   datetime
SELECT @batch_end_time = dateadd(hh,24+21,max(calendar_date)) FROM ukrr_mart..date_dimension WHERE calendar_date < convert(char(8),getdate(),112) AND working_day_flag = 'Y'
--21h00 on the day after the previous working day - might as well allow for really late runs and take it till 9pm

--SET nocount OFF

SELECT  --convert(char(20),SUBJECT_AREA)  as 'SUBJECT_AREA'
        convert(char(50),WORKFLOW_NAME) as 'WORKFLOW_NAME' 
,       AVG(CASE WHEN START_TIME > dateadd(DD, -1, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )  as 'latest_min'
,       AVG(CASE WHEN START_TIME BETWEEN  dateadd(DD, -2, @batch_end_time) AND dateadd(DD, -1, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )     as 'prev_run'
,       AVG(CASE WHEN START_TIME BETWEEN  dateadd(DD, -8, @batch_end_time) AND dateadd(DD, -7, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )     as 'week_ago'
,       AVG(CASE WHEN START_TIME BETWEEN  dateadd(DD, -8, @batch_end_time) AND dateadd(DD, -1, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )     as 'wk_avg'
,       AVG(CASE WHEN START_TIME BETWEEN dateadd(DD, -15, @batch_end_time) AND dateadd(DD, -8, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )     as 'wk_avg_prev'
,       AVG(CASE WHEN START_TIME BETWEEN dateadd(DD, -31, @batch_end_time) AND dateadd(DD, -1, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END)     as 'month_avg'
,       MIN(CASE WHEN START_TIME BETWEEN  dateadd(DD, -8, @batch_end_time) AND dateadd(DD, -1, @batch_end_time) THEN substring(convert(char(8),START_TIME, 108),1,5) END) as 'min_start'
INTO  #run_avg
FROM  #REP_WF_RUN   --pc_rep..REP_WFLOW_RUN 
GROUP BY convert(char(50),WORKFLOW_NAME)
ORDER BY 2 DESC
--go

SELECT convert(char(50),t1.WORKFLOW_NAME) as 'WORKFLOW_1'
,      convert(char(50),t2.WORKFLOW_NAME) as 'WORKFLOW_2'
--,      convert(char(20),t2.SUBJECT_AREA)  as 'SUBJECT_AREA'
,       t2.WORKFLOW_RUN_ID
,       t2.RUN_STATUS_CODE
,       t1.START_TIME                      as "START_TIME_1"  
,       t1.END_TIME                        as "END_TIME_1"   
,       t2.START_TIME                      as "START_TIME_2" 
,       t2.END_TIME                        as "END_TIME_2"   
,       datediff(mi,t1.END_TIME, t2.START_TIME)               as 'idle_minutes'
INTO #run_current 
FROM #REP_WF_RUN  t1
,    #REP_WF_RUN  t2
WHERE t2.WORKFLOW_RUN_ID *= t1.WORKFLOW_RUN_ID + 1
AND    t1.START_TIME  > dateadd(DD, -1, @batch_end_time)  
AND    t2.START_TIME  > dateadd(DD, -1, @batch_end_time)  
--AND   t1.RUN_STATUS_CODE in ( 1, 6) 
go

-- '2) Incomplete batches from last nights run : '

SELECT ra.WORKFLOW_NAME 
INTO #unrun 
FROM #run_avg  ra
WHERE NOT EXISTS (SELECT 1 FROM #run_current rc WHERE rc.WORKFLOW_2 = ra.WORKFLOW_NAME AND rc.RUN_STATUS_CODE = 1 )
--WHERE ra.WORKFLOW_NAME  in ( 'b_RFRM_Daily_AEQF_Anvil','b_RFRM_Daily','b_RFRM_LargeExposure','b_RFRM_Monthly_AEQF_Anvil','b_RFRM_Monthly','b_InternalExtracts_Daily', 'b_MART_MIST_Qualification','b_MART_RIMS_Qualification_Account','b_MART_RIMS_Qualification_Trade'  )  -- test sample data
go

SELECT   ra.WORKFLOW_NAME 
,        prev_run     
,        week_ago 
,        wk_avg
,        month_avg
,        round(1.10 * month_avg,0)  as 'month_avg_est'
,        min_start
INTO  #unrun_2
FROM  #run_avg      ra
WHERE ra.WORKFLOW_NAME in (SELECT WORKFLOW_NAME FROM #unrun)
ORDER BY ra.min_start
go

CREATE TABLE #etas ( 
         WORKFLOW_NAME   varchar(35)
,        run_minutes     int      NULL
,        minutes_to_go   int      NULL
)
go

SELECT  ra.WORKFLOW_NAME 
,        round(1.10 *  ra.month_avg,0)                     as 'month_avg_est'
,        datediff(mi,rc.START_TIME_1, getdate() )          as 'run_portion_min'
,        round(1.10 *  ra.month_avg,0) - datediff(mi,rc.START_TIME_1, getdate() )  as 'unrun_portion_min'
INTO #running
FROM #run_avg  ra
,    #run_current rc 
WHERE rc.WORKFLOW_2 = ra.WORKFLOW_NAME 
AND   rc.RUN_STATUS_CODE in (6) 
go

INSERT #etas
SELECT   WORKFLOW_NAME  = 'Currently running job'
,        run_minutes    = CASE WHEN unrun_portion_min < 0 THEN 1 ELSE unrun_portion_min END
,        minutes_to_go  = CASE WHEN unrun_portion_min < 0 THEN 1 ELSE unrun_portion_min END
FROM #running
go

INSERT #etas
SELECT   WORKFLOW_NAME  = 'Any unrun datamart jobs'
,        run_minutes    = ISNULL(sum(month_avg_est),0)
,        minutes_to_go  = ISNULL(sum(month_avg_est),0) + (SELECT sum(run_minutes) FROM #etas)
FROM #unrun_2
WHERE WORKFLOW_NAME NOT LIKE '%RFRM%'
AND   WORKFLOW_NAME NOT LIKE '%Extract%'
AND   WORKFLOW_NAME NOT LIKE '%Recon%'
go

INSERT #etas
SELECT   WORKFLOW_NAME  = 'b_InternalExtracts_Daily'
,        run_minutes    = month_avg_est
,        minutes_to_go  = ISNULL(month_avg_est,0) + (SELECT sum(run_minutes) FROM #etas)
FROM #unrun_2
WHERE WORKFLOW_NAME = 'b_InternalExtracts_Daily'
go

INSERT #etas
SELECT   WORKFLOW_NAME  = 'b_RFRM_Daily_AEQF_Anvil'
,        run_minutes    = ISNULL(month_avg_est,0)
,        minutes_to_go  = ISNULL(month_avg_est,0) + (SELECT sum(run_minutes) FROM #etas)
FROM #unrun_2
WHERE WORKFLOW_NAME = 'b_RFRM_Daily_AEQF_Anvil'
go

INSERT #etas
SELECT   WORKFLOW_NAME  = 'b_RFRM_Daily'
,        run_minutes    = month_avg_est
,        minutes_to_go  = ISNULL(month_avg_est,0) + (SELECT sum(run_minutes) FROM #etas)
FROM #unrun_2
WHERE WORKFLOW_NAME = 'b_RFRM_Daily'
go

INSERT #etas
SELECT   WORKFLOW_NAME  = 'b_RFRM_Monthly_AEQF_Anvil'
,        run_minutes    = month_avg_est
,        minutes_to_go  = ISNULL(month_avg_est,0) + (SELECT sum(run_minutes) FROM #etas)
FROM #unrun_2
WHERE WORKFLOW_NAME = 'b_RFRM_Monthly_AEQF_Anvil'
AND ((SELECT working_day_of_month FROM ukrr_mart..date_dimension WHERE calendar_date = convert(char(8),dateadd(dd,-1,getdate()),112) ) BETWEEN 1 AND 7
     OR (SELECT last_day_of_month_flag FROM ukrr_mart..date_dimension WHERE calendar_date = convert(char(8),dateadd(dd,-1,getdate()),112) ) = 'Y'   )
go

INSERT #etas
SELECT   WORKFLOW_NAME  = 'b_RFRM_Monthly'
,        run_minutes    = month_avg_est
,        minutes_to_go  = ISNULL(month_avg_est,0) + (SELECT sum(run_minutes) FROM #etas)
FROM #unrun_2
WHERE WORKFLOW_NAME = 'b_RFRM_Monthly'
AND ((SELECT working_day_of_month FROM ukrr_mart..date_dimension WHERE calendar_date = convert(char(8),dateadd(dd,-1,getdate()),112) ) BETWEEN 1 AND 7
     OR (SELECT last_day_of_month_flag FROM ukrr_mart..date_dimension WHERE calendar_date = convert(char(8),dateadd(dd,-1,getdate()),112) ) = 'Y'   )
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '1) ETAs for these incomplete batches from last nights run : '
PRINT '-------------------------------------------------'
PRINT ''

SELECT convert(char(35),WORKFLOW_NAME) as 'workflow_name' 
,      run_minutes
,      minutes_to_go = substring(convert(char(8),dateadd(mi,minutes_to_go, '1/1/1900'), 108),1,5)   
,      now =  substring(convert(char(8),getdate(), 108),1,5)   
,      eta =  substring(convert(char(8),dateadd(mi,minutes_to_go, getdate()), 108),1,5)   
FROM #etas
WHERE WORKFLOW_NAME NOT LIKE 'b_RFRM_%_AEQF%'  -- NOT shown for this report 
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT 'THINGS TO NOTE :'
PRINT '-------------------------------------------------'
PRINT ' - This report is now automated to run to at 7,8 and 9 am to give progress updates through the morning.'
PRINT " - If there is a long (say 10 min+) job running at the time of the report (will show in section 2), it's completed portion IS now taken into account for ETAs"
PRINT " - The ETAs are based on the averages for these jobs over the last month PLUS 10 percent"
PRINT "     - This shouldn't be too optimistic unless things are running really slowly on the day."
PRINT " - The 'Any unrun datamart jobs' section just sums any pre-extract jobs. Their individual ETAs can't be given as their running order is not fixed."
PRINT ' - The month end jobs will drop off the ETAs after the 8th working day of the month, so please remove them from any advisory emails as well.'
PRINT '-------------------------------------------------'
PRINT ''
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '2) The most recent 20 workflows and some stats on them: '
PRINT '-------------------------------------------------'
PRINT ''

SELECT   convert(char(35),rc.WORKFLOW_2) as 'workflow_name'  
,        substring(convert(char(8),rc.START_TIME_2, 108),1,5)     as  'start'
,        substring(convert(char(8),rc.END_TIME_2, 108),1,5)     as  'finsh'
,        CASE WHEN idle_minutes  > 1 THEN convert(char(7),idle_minutes) ELSE '' END  as 'idle min'
,        convert(char(7),ra.latest_min)     as 'run_min'
,        convert(char(7),ra.prev_run)       as  'prev_run'     
,        convert(char(7),ra.week_ago)     as  'week_ago' 
,        convert(char(7),ra.wk_avg)         as  'wk_avg'     
,        convert(char(7),ra.wk_avg_prev)    as  'wk_avg_prev'
,        convert(char(7),ra.month_avg)      as  'month_avg'  
,        CASE WHEN abs(ra.latest_min - ra.wk_avg)     >= 5 THEN convert(char(7),ra.latest_min - ra.wk_avg)    ELSE '' END as 'wk_dev'
,        CASE WHEN abs(ra.latest_min - ra.month_avg)  >= 5 THEN convert(char(7),ra.latest_min - ra.month_avg) ELSE '' END as 'month_dev'
FROM #run_current  rc
,    #run_avg      ra
WHERE rc.WORKFLOW_2 = ra.WORKFLOW_NAME 
AND  rc.WORKFLOW_RUN_ID >= (SELECT max(WORKFLOW_RUN_ID) - 20 FROM #run_current )
ORDER BY rc.START_TIME_2
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '3) Incomplete batches from last nights run : '
PRINT '-------------------------------------------------'
PRINT ''

SELECT   convert(char(35),ra.WORKFLOW_NAME) as 'workflow_name'
,        convert(char(7),ra.prev_run)       as  'prev_run'     
,        convert(char(7),ra.week_ago)       as  'week_ago' 
,        convert(char(7),ra.wk_avg)         as  'wk_avg'     
,        convert(char(7),ra.month_avg)      as  'month_avg'
,        min_start
FROM   #unrun_2 ra
ORDER BY min_start
go


PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '4) Last nights workflows that have had significant performance swings : '
PRINT '   - wk_dev and month_dev are deviations from averages, only shown when >= 5 min '
PRINT '-------------------------------------------------'
PRINT ''

SELECT   convert(char(35),rc.WORKFLOW_2) as 'workflow_name'  
,        convert(char(6),RUN_STATUS_CODE)   as 'status'
,        CASE WHEN idle_minutes  > 1 THEN convert(char(7),idle_minutes) ELSE '' END  as 'idle min'
,        substring(convert(char(8),rc.START_TIME_2, 108),1,5)     as  'start'
,        substring(convert(char(8),rc.END_TIME_2, 108),1,5)     as  'finsh'
,        convert(char(7),ra.latest_min)     as 'run_min'
,        convert(char(7),ra.prev_run)       as  'prev_run'     
--,        convert(char(7),ra.week_ago)     as  'week_ago' 
,        convert(char(7),ra.wk_avg)         as  'wk_avg'     
--,        convert(char(7),ra.wk_avg_prev)    as  'wk_avg_prev'
,        convert(char(7),ra.month_avg)      as  'month_avg'  
,        CASE WHEN abs(ra.latest_min - ra.wk_avg)     >= 5 THEN convert(char(7),ra.latest_min - ra.wk_avg)    ELSE '' END as 'wk_dev'
,        CASE WHEN abs(ra.latest_min - ra.month_avg)  >= 5 THEN convert(char(7),ra.latest_min - ra.month_avg) ELSE '' END as 'month_dev'
FROM #run_current  rc
,    #run_avg      ra
WHERE rc.WORKFLOW_2 = ra.WORKFLOW_NAME 
AND  (abs(ra.latest_min - ra.wk_avg)     >= 5 
      OR  abs(ra.latest_min - ra.month_avg)  >= 5 )
--AND  rc.WORKFLOW_RUN_ID >= (SELECT max(WORKFLOW_RUN_ID) - 40 FROM #run_current )
ORDER BY rc.START_TIME_2
go


PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '5) any idle time between workflows in previous batch run: '
PRINT '-------------------------------------------------'
PRINT ''

SELECT   convert(char(30),WORKFLOW_1)  as 'WORKFLOW_1'
,        convert(char(30),WORKFLOW_2)  as 'WORKFLOW_2'
--,        SUBJECT_AREA
--,        substring(convert(char(8),START_TIME_1, 108),1,5)   as  'START_TIME_1'
,        substring(convert(char(8),END_TIME_1, 108),1,5)     as  'END_TIME_1'
,        substring(convert(char(8),START_TIME_2, 108),1,5)   as  'START_TIME_2'
,        idle_minutes
FROM  #run_current
WHERE idle_minutes > 1
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '6) Most likely causes of UKRR batch delays : '
PRINT '-------------------------------------------------'
PRINT 'i)   Slow running processes - these will show in the deviation from avg durations columns in section 4)'
PRINT 'ii)  late file delivery'
PRINT 'iii) A batch processing failure'
PRINT '   - ii) and iii) will ONLY  have impact if either the workflow is on critical path OR the delay was enough to cause idle time'
PRINT '   - see any the idle times in section 5) '
PRINT '-------------------------------------------------'
PRINT ''

go


quit


/*

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '4a) running time stats for workflows running longer than 10 minutes in previous batch run : '
PRINT '-------------------------------------------------'
PRINT ''

SELECT   WORKFLOW_NAME 
,        latest_min
,        prev_run
,        wk_avg
,        month_avg
,        CASE WHEN ra.latest_min - ra.wk_avg     > 5 THEN convert(char(7),ra.latest_min - ra.wk_avg)    ELSE '' END as 'wk_dev'
,        CASE WHEN ra.latest_min - ra.month_avg  > 5 THEN convert(char(7),ra.latest_min - ra.month_avg) ELSE '' END as 'month_dev'
FROM #run_avg  ra
WHERE latest_min >= 10
go

PRINT "     - In this case, either subtract it's time off ETAs or re-run the script after it completes"


SELECT WORKFLOW_NAME
,       START_TIME                      
,       END_TIME                        
,       END_TIME
--,       RUN_STATUS_CODE
INTO   #running
FROM   pc_rep..REP_WFLOW_RUN 
WHERE  RUN_STATUS_CODE = 6 
AND    START_TIME  >= dateadd(HH, -1, getdate())  
AND    WORKFLOW_NAME NOT  IN ('b_CollectINFT_InterestCurve','b_GED_Collect','s_CollectGCPInfinityProfile','s_CollectGCPInfinityCDO','b_Perm_Acc_Daily','s_CollectType1_OrgUnitDimension','b_CollectRIMS_WK' ) 
go


INSERT #etas
SELECT   WORKFLOW_NAME  = 'b_RFRM_Monthly_AEQF_Anvil'
,        run_minutes    = month_avg_est
,        minutes_to_go  = (SELECT sum(run_minutes) FROM #etas) + month_avg_est
FROM #unrun_2
WHERE WORKFLOW_NAME = 'b_RFRM_Monthly_AEQF_Anvil'
AND ((SELECT working_day_of_month FROM ukrr_mart..date_dimension WHERE calendar_date = convert(char(8),dateadd(dd,-1,getdate()),112) ) BETWEEN 1 AND 7
     OR (SELECT last_day_of_month_flag FROM ukrr_mart..date_dimension WHERE calendar_date = convert(char(8),dateadd(dd,-1,getdate()),112) ) = 'Y'   )
go
