/*********************************************************************************************
#  Name     : ~ukrr_pm/scripts/sql/batch_status_current.sql
#  Purpose  : .sql report to finish times of key UKRR jobs compared to their 'SLA' times
#  Usage    :  call_sql.sh batch_status_current.sql ${SN}  "simon.osborne@rbccm.com"
#           :  alias bse='call_sql.sh batch_status_current.sql ${SN}'
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  10/01/2008   S Osborne       Created
#
#*********************************************************************************************/

SET nocount ON

SELECT  SUBJECT_AREA
,       WORKFLOW_NAME
,       WORKFLOW_ID
--,       WORKFLOW_RUN_ID
,       START_TIME
,       END_TIME
,       RUN_STATUS_CODE
INTO   #REP_WF_RUN 
FROM   pc_rep..REP_WFLOW_RUN 
WHERE  1  = 2
go

ALTER TABLE #REP_WF_RUN add WORKFLOW_RUN_ID int identity
go

INSERT #REP_WF_RUN
SELECT  SUBJECT_AREA
,       WORKFLOW_NAME
,       WORKFLOW_ID
--,       WORKFLOW_RUN_ID
,       START_TIME
,       END_TIME
,       RUN_STATUS_CODE
FROM   pc_rep..REP_WFLOW_RUN 
WHERE  START_TIME  >= dateadd(DD, -35, getdate())  
--AND    RUN_STATUS_CODE in ( 1, 6) 
AND   WORKFLOW_NAME NOT  IN ('b_CollectINFT_InterestCurve','b_GED_Collect','s_CollectGCPInfinityProfile','s_CollectGCPInfinityCDO','s_CollectType1_OrgUnitDimension','b_CollectRIMS_WK' ) 
--AND   WORKFLOW_NAME NOT  LIKE '%Perm_Acc%'  AND   WORKFLOW_NAME NOT  LIKE '%Trade_Daily%'  
ORDER BY START_TIME
go

DECLARE @batch_end_time   datetime
SELECT @batch_end_time = dateadd(hh,24+21,max(calendar_date)) FROM ukrr_mart..date_dimension WHERE calendar_date < convert(char(8),getdate(),112) AND working_day_flag = 'Y'
--21h00 on the day after the previous working day - might as well allow for really late runs and take it till 9pm

--SET nocount OFF

SELECT  --convert(char(20),SUBJECT_AREA)  as 'SUBJECT_AREA'
        convert(char(50),WORKFLOW_NAME) as 'WORKFLOW_NAME' 
,       AVG(CASE WHEN START_TIME > dateadd(DD, -1, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )  as 'latest_min'
,       AVG(CASE WHEN START_TIME BETWEEN  dateadd(DD, -2, @batch_end_time) AND dateadd(DD, -1, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )     as 'prev_run'
,       AVG(CASE WHEN START_TIME BETWEEN  dateadd(DD, -8, @batch_end_time) AND dateadd(DD, -7, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )     as 'week_ago'
,       AVG(CASE WHEN START_TIME BETWEEN  dateadd(DD, -8, @batch_end_time) AND dateadd(DD, -1, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )     as 'wk_avg'
,       AVG(CASE WHEN START_TIME BETWEEN dateadd(DD, -15, @batch_end_time) AND dateadd(DD, -8, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END )     as 'wk_avg_prev'
,       AVG(CASE WHEN START_TIME BETWEEN dateadd(DD, -31, @batch_end_time) AND dateadd(DD, -1, @batch_end_time) THEN datediff(mi,START_TIME, END_TIME) END)     as 'month_avg'
,       MIN(CASE WHEN START_TIME BETWEEN  dateadd(DD, -8, @batch_end_time) AND dateadd(DD, -1, @batch_end_time) THEN substring(convert(char(8),START_TIME, 108),1,5) END) as 'min_start'
INTO  #run_avg
FROM  #REP_WF_RUN   --pc_rep..REP_WFLOW_RUN 
WHERE RUN_STATUS_CODE in (1) 
GROUP BY convert(char(50),WORKFLOW_NAME)
ORDER BY 2 DESC
--go

SELECT convert(char(50),t1.WORKFLOW_NAME) as 'WORKFLOW_1'
,      convert(char(50),t2.WORKFLOW_NAME) as 'WORKFLOW_2'
--,      convert(char(20),t2.SUBJECT_AREA)  as 'SUBJECT_AREA'
,       t2.WORKFLOW_RUN_ID
,       t2.RUN_STATUS_CODE
,       t1.START_TIME                      as "START_TIME_1"  
,       t1.END_TIME                        as "END_TIME_1"   
,       t2.START_TIME                      as "START_TIME_2" 
,       t2.END_TIME                        as "END_TIME_2"   
,       datediff(mi,t1.END_TIME, t2.START_TIME)               as 'idle_minutes'
INTO #run_current 
FROM #REP_WF_RUN  t1
,    #REP_WF_RUN  t2
WHERE t2.WORKFLOW_RUN_ID *= t1.WORKFLOW_RUN_ID + 1
AND    t1.START_TIME  > dateadd(DD, -1, @batch_end_time)  
AND    t2.START_TIME  > dateadd(DD, -1, @batch_end_time)  
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '2) All of last nights workflows and some stats on them: '
PRINT '   - wk_dev and month_dev are deviations from averages, only shown when >= 5 min '
PRINT 'STATUS key: 1 = Succeeded // 3 = Failed  // 5 = Aborted // 6 = Running // 15 = Terminated '
PRINT '-------------------------------------------------'
PRINT ''

SELECT   convert(char(35),rc.WORKFLOW_2) as 'workflow_name'  
,        convert(char(6),RUN_STATUS_CODE)   as 'status'
,        CASE WHEN idle_minutes  > 1 THEN convert(char(7),idle_minutes) ELSE '' END  as 'idle min'
,        substring(convert(char(8),rc.START_TIME_2, 108),1,5)     as  'start'
,        substring(convert(char(8),rc.END_TIME_2, 108),1,5)     as  'finsh'
,        convert(char(7),ra.latest_min)     as 'run_min'
,        convert(char(7),ra.prev_run)       as  'prev_run'     
--,        convert(char(7),ra.week_ago)     as  'week_ago' 
,        convert(char(7),ra.wk_avg)         as  'wk_avg'     
--,        convert(char(7),ra.wk_avg_prev)    as  'wk_avg_prev'
,        convert(char(7),ra.month_avg)      as  'month_avg'  
,        CASE WHEN abs(ra.latest_min - ra.wk_avg)     >= 5 THEN convert(char(7),ra.latest_min - ra.wk_avg)    ELSE '' END as 'wk_dev'
,        CASE WHEN abs(ra.latest_min - ra.month_avg)  >= 5 THEN convert(char(7),ra.latest_min - ra.month_avg) ELSE '' END as 'month_dev'
FROM #run_current  rc
,    #run_avg      ra
WHERE rc.WORKFLOW_2 = ra.WORKFLOW_NAME 
--AND  rc.WORKFLOW_RUN_ID >= (SELECT max(WORKFLOW_RUN_ID) - 40 FROM #run_current )
ORDER BY rc.START_TIME_2
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '3) Last nights workflows that have had significant performance swings : '
PRINT '   - wk_dev and month_dev are deviations from averages, only shown when >= 5 min '
PRINT '-------------------------------------------------'
PRINT ''

SELECT   convert(char(35),rc.WORKFLOW_2) as 'workflow_name'  
,        convert(char(6),RUN_STATUS_CODE)   as 'status'
,        CASE WHEN idle_minutes  > 1 THEN convert(char(7),idle_minutes) ELSE '' END  as 'idle min'
,        substring(convert(char(8),rc.START_TIME_2, 108),1,5)     as  'start'
,        substring(convert(char(8),rc.END_TIME_2, 108),1,5)     as  'finsh'
,        convert(char(7),ra.latest_min)     as 'run_min'
,        convert(char(7),ra.prev_run)       as  'prev_run'     
--,        convert(char(7),ra.week_ago)     as  'week_ago' 
,        convert(char(7),ra.wk_avg)         as  'wk_avg'     
--,        convert(char(7),ra.wk_avg_prev)    as  'wk_avg_prev'
,        convert(char(7),ra.month_avg)      as  'month_avg'  
,        CASE WHEN abs(ra.latest_min - ra.wk_avg)     >= 5 THEN convert(char(7),ra.latest_min - ra.wk_avg)    ELSE '' END as 'wk_dev'
,        CASE WHEN abs(ra.latest_min - ra.month_avg)  >= 5 THEN convert(char(7),ra.latest_min - ra.month_avg) ELSE '' END as 'month_dev'
FROM #run_current  rc
,    #run_avg      ra
WHERE rc.WORKFLOW_2 = ra.WORKFLOW_NAME 
AND  (abs(ra.latest_min - ra.wk_avg)     >= 5 
      OR  abs(ra.latest_min - ra.month_avg)  >= 5 )
--AND  rc.WORKFLOW_RUN_ID >= (SELECT max(WORKFLOW_RUN_ID) - 40 FROM #run_current )
ORDER BY rc.START_TIME_2
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '4) running time stats for workflows running longer than 10 minutes in previous batch run : '
PRINT '-------------------------------------------------'
PRINT ''

SELECT   WORKFLOW_NAME 
,        latest_min
,        prev_run
,        wk_avg
,        month_avg
,        CASE WHEN ra.latest_min - ra.wk_avg     > 5 THEN convert(char(7),ra.latest_min - ra.wk_avg)    ELSE '' END as 'wk_dev'
,        CASE WHEN ra.latest_min - ra.month_avg  > 5 THEN convert(char(7),ra.latest_min - ra.month_avg) ELSE '' END as 'month_dev'
FROM #run_avg  ra
WHERE latest_min >= 10
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT '5) any idle time between workflows in previous batch run: '
PRINT '-------------------------------------------------'
PRINT ''

SELECT   convert(char(30),WORKFLOW_1)  as 'WORKFLOW_1'
,        convert(char(30),WORKFLOW_2)  as 'WORKFLOW_2'
--,        SUBJECT_AREA
--,        substring(convert(char(8),START_TIME_1, 108),1,5)   as  'START_TIME_1'
,        substring(convert(char(8),END_TIME_1, 108),1,5)     as  'END_TIME_1'
,        substring(convert(char(8),START_TIME_2, 108),1,5)   as  'START_TIME_2'
,        idle_minutes
FROM  #run_current
WHERE idle_minutes > 1
go


