/*********************************************************************************************
#  Name     : ~ukrr_pm/scripts/sql/monthly_maintenance.sql
#  Purpose  : .sql to set things up to get a second chance at archiving some data and also set things up for month end.
#  Usage    :  call_sql.sh monthly_maintenance "simon.osborne@rbccm.com"  
#           :  alias mm='call_sql.sh monthly_maintenance "simon.osborne@rbccm.com"'
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  07/18/2009   S Osborne       Created
#
#*********************************************************************************************/

--BEGIN
--SET NOCOUNT ON

--DECLARE @batch_start_date  datetime

-- Set the archive dates for the the two tables that have archiving exceptions - to get a second chance at archiving :
--   IF (@tab_name = 'bonddaily')  SELECT @sql_text = @sql_text + " AND dhis_valdat_l <= '" + convert (char(8), @last_data_date, 112) + "'"
--   IF (@tab_name = 'xfwd')       SELECT @sql_text = @sql_text + " AND value_date <= '"    + convert (char(8), @last_data_date, 112) + "'"
--   Perhaps run this monthly, then these dates should be picked up the next Wednesday that the archiving is run.
-- xfwd at around 2.5 GB and up to 1 GB of unused needs to be reorg rebuilt but at that size is not really an option, so bcp out / in is another way of doing this.


PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT 'Setting the archiving dates for the the two tables (bonddaily,xfwd) that have archiving exceptions - to get a second chance at archiving  : '
PRINT '-------------------------------------------------'
PRINT ''

UPDATE ukrr_ctrl..collect_table_archiving 
SET  last_archive_date = dateadd(dd,-360,getdate())
WHERE   ( db_name = 'ukrr_rims' AND    tab_name in ( 'xfwd' , 'inwk' ) )
OR      ( db_name = 'ukrr_mist' AND    tab_name = 'bonddaily' )
go

UPDATE ukrr_ctrl..collect_table_archiving 
SET  last_archive_date = dateadd(dd,-120,getdate())
WHERE   ( db_name = 'ukrr_rims' AND    tab_name in ( 'cnld_master' , 'cnfx_master' , 'sett_master' ) )
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT 'Setting the identification_str = US17275RAE27  in ukrr_igcp.dbo.gcp_infinity_trades_master - some have carriage returns in them : '
PRINT '-------------------------------------------------'
PRINT ''

SELECT T1.trade_id
,        T1.trade_leg_id
,        T1.trans_id
,        T1.identification_str
FROM ukrr_igcp.dbo.gcp_infinity_trades_master T1
WHERE T1.identification_str like 'US17275RAE27%'
go

UPDATE ukrr_igcp.dbo.gcp_infinity_trades_master 
SET identification_str  = 'US17275RAE27'
WHERE identification_str like 'US17275RAE27%'
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT 'truncating problem tempdb tables : '
PRINT '-------------------------------------------------'
PRINT ''

truncate table tempdb..tmpMDout
go




/*


quit 
