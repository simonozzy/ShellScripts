/*********************************************************************************************
#  Name     : ~ukrr_pm/scripts/sql/latest_development.sql
#  Purpose  : .sql report to ...
#  Usage    :  call_sql.sh latest_development ${SN} "simon.osborne@rbccm.com"  
#           :  alias rd='call_sql.sh latest_development ${SN}' # Recent Development
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  08/08/2008   S Osborne       Created
#
#*********************************************************************************************/

use pc_rep
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT 'Informatica mappings and sessions that have changed recently: '
PRINT '-------------------------------------------------'
PRINT ''

SELECT convert(char(60),OBJECT_NAME)  as "OBJECT_NAME"
--,       convert(char(9), a.LAST_SAVED , 112) + convert(char(8),  a.LAST_SAVED , 108)  as "LAST_SAVED"
,       convert(char, a.LAST_SAVED , 100) as "LAST_SAVED"
--,      a.LAST_SAVED
,      convert(char(10), b.USER_NAME)   as  "USER_NAME"
FROM  OPB_VERSION_PROPS a
,     OPB_USERS b
WHERE a.USER_ID=b.USER_ID
AND   a.LAST_SAVED > dateadd(dd,-20,getdate())
AND   ( OBJECT_NAME like 'm[_]%' OR  OBJECT_NAME like 's[_]%' OR  OBJECT_NAME like 'b[_]%' )
AND     OBJECT_NAME NOT LIKE 's_Check%'
ORDER BY a.LAST_SAVED DESC
go

PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT 'DDL objects that have been created in the last two months: '
PRINT '  - NB table alters won"t show here and I"m not sure if they can be tracked'
PRINT '-------------------------------------------------'
PRINT ''

SELECT db_name    = 'ukrr_acbs', type, name, crdate FROM ukrr_acbs..sysobjects WHERE type in ('U','V','P') AND  crdate  > dateadd(dd,-60,getdate()) UNION
SELECT db_name    = 'ukrr_anvl', type, name, crdate FROM ukrr_anvl..sysobjects WHERE type in ('U','V','P') AND  crdate  > dateadd(dd,-60,getdate()) UNION
SELECT db_name    = 'ukrr_ebs ', type, name, crdate FROM ukrr_ebs ..sysobjects WHERE type in ('U','V','P') AND  crdate  > dateadd(dd,-60,getdate()) UNION
SELECT db_name    = 'ukrr_ccms', type, name, crdate FROM ukrr_ccms..sysobjects WHERE type in ('U','V','P') AND  crdate  > dateadd(dd,-60,getdate()) UNION
SELECT db_name    = 'ukrr_gclt', type, name, crdate FROM ukrr_gclt..sysobjects WHERE type in ('U','V','P') AND  crdate  > dateadd(dd,-60,getdate()) UNION
SELECT db_name    = 'ukrr_geqd', type, name, crdate FROM ukrr_geqd..sysobjects WHERE type in ('U','V','P') AND  crdate  > dateadd(dd,-60,getdate()) UNION
SELECT db_name    = 'ukrr_igcp', type, name, crdate FROM ukrr_igcp..sysobjects WHERE type in ('U','V','P') AND  crdate  > dateadd(dd,-60,getdate()) UNION
SELECT db_name    = 'ukrr_inft', type, name, crdate FROM ukrr_inft..sysobjects WHERE type in ('U','V','P') AND  crdate  > dateadd(dd,-60,getdate()) UNION
SELECT db_name    = 'ukrr_mktd', type, name, crdate FROM ukrr_mktd..sysobjects WHERE type in ('U','V','P') AND  crdate  > dateadd(dd,-60,getdate()) UNION
SELECT db_name    = 'ukrr_obi ', type, name, crdate FROM ukrr_obi ..sysobjects WHERE type in ('U','V','P') AND  crdate  > dateadd(dd,-60,getdate()) UNION
SELECT db_name    = 'ukrr_offs', type, name, crdate FROM ukrr_offs..sysobjects WHERE type in ('U','V','P') AND  crdate  > dateadd(dd,-60,getdate()) UNION
SELECT db_name    = 'ukrr_ribs', type, name, crdate FROM ukrr_ribs..sysobjects WHERE type in ('U','V','P') AND  crdate  > dateadd(dd,-60,getdate()) UNION
SELECT db_name    = 'ukrr_rims', type, name, crdate FROM ukrr_rims..sysobjects WHERE type in ('U','V','P') AND  crdate  > dateadd(dd,-60,getdate()) UNION
SELECT db_name    = 'ukrr_slim', type, name, crdate FROM ukrr_slim..sysobjects WHERE type in ('U','V','P') AND  crdate  > dateadd(dd,-60,getdate()) UNION
SELECT db_name    = 'ukrr_mart', type, name, crdate FROM ukrr_mart..sysobjects WHERE type in ('U','V','P') AND  crdate  > dateadd(dd,-60,getdate()) 
AND name not like 'focus_proc%' 
ORDER BY crdate, name
go


         
