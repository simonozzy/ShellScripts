/*********************************************************************************************
#  Name     : ~ukrr_pm/scripts/sql/daily_db_maintenance.sql
#  Purpose  : .sql report to ...
#  Usage    :  ~ukrr_pm/scripts/call_sql.sh daily_db_maintenance.sql ${SN} "simon.osborne@rbccm.com"  
#           :  00 15 * * 1-5 ~ukrr_pm/scripts/call_sql.sh daily_db_maintenance.sql 
#           :  
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  08/08/2010   S Osborne       Created
#
#*********************************************************************************************/

use tempdb
go

PRINT '----------------------------------------------------------------------------------------------------'
PRINT '1) Size check on tempdb..tmpMDout : '
PRINT '-------------------------------------------------'
PRINT ''

exec sp_spaceused tmpMDout
go

PRINT '----------------------------------------------------------------------------------------------------'
PRINT '2) TRUNCATING TABLE tempdb..tmpMDout : '
PRINT '-------------------------------------------------'
PRINT ''

TRUNCATE TABLE tempdb..tmpMDout
go

PRINT '----------------------------------------------------------------------------------------------------'
PRINT '3) Size check on tempdb..tmpMDout : '
PRINT '-------------------------------------------------'
PRINT ''

exec sp_spaceused tmpMDout
go

