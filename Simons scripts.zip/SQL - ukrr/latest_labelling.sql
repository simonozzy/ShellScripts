/*********************************************************************************************
#  Name     : ~ukrr_pm/scripts/sql/latest_labelling.sql
#  Purpose  : .sql report to ...
#  Usage    :  report_master.sh latest_labelling.sql xls "simon.osborne@rbccm.com" 'Informatica latest labelling report' 
#           :  alias lbl='report_master.sh latest_labelling.sql csv "simon.osborne@rbccm.com" "Informatica latest labelling report"'
#
#  Modification History :
#  Date         User            Description
#  -------------------------------------------------------------------------------------------
#  08/08/2010   S Osborne       Created
#
#*********************************************************************************************/

use pc_rep
go

SET NOCOUNT ON

--PRINT ''
PRINT '----------------------------------------------------------------------------------------------------'
PRINT 'Informatica lables applied (or NOT) to all objects modified within the last 60 days : '
PRINT '-------------------------------------------------'
--PRINT ''

SELECT convert(char(20),rs.SUBJECT_AREA)   as "FOLDER_NAME"
,      convert(char(40),a.OBJECT_NAME)  as "OBJECT_NAME"
,      a.VERSION_NUMBER                 as "VERSION" 
,       convert(char(12), convert(datetime,a.LAST_SAVED), 111) + ' @ ' + convert(char(8), convert(datetime,a.LAST_SAVED), 8)  as "LAST_SAVED"
--,      a.LAST_SAVED 
,      convert(char(10), b.USER_NAME)   as  "USER_NAME"
,      convert(char(60),a.COMMENTS)     as "VERSION_COMMENTS"	
--,      rl.LABEL_ID	
,      convert(char(40),rl.LABEL_NAME)  as "LABEL_NAME"	
--,      rl.DESCRIPTION	 as 'label_desc' 
,       convert(char(12), convert(datetime,rlf.APPLY_TIME), 111) + ' @ ' + convert(char(8), convert(datetime,rlf.APPLY_TIME), 8)  as "label_apply_time"
,      convert(char(50),rlf.DESCRIPTION)   as 'label_apply_desc' 
,      a.OBJECT_ID
,      a.OBJECT_TYPE
FROM  pc_rep..REP_SUBJECT       rs
,     pc_rep..REP_VERSION_PROPS a 
,     pc_rep..OPB_USERS         b
,     pc_rep..REP_LABEL         rl
,     pc_rep..REP_LABEL_REF     rlf
WHERE b.USER_ID     =*  a.USER_ID 
AND   rl.LABEL_ID   =* rlf.LABEL_ID
AND   rlf.OBJECT_ID =* a.OBJECT_ID 
AND   rs.SUBJECT_ID = a.SUBJECT_ID    -- Folder ID
AND   rlf.VERSION_NUMBER =* a.VERSION_NUMBER
AND   a.LAST_SAVED > dateadd(dd,-60,getdate())
AND   ( OBJECT_NAME like 'm[_]%' OR  OBJECT_NAME like 's[_]%' OR  OBJECT_NAME like 'lkp[_]%' OR  OBJECT_NAME like 'b[_]%' OR  rs.SUBJECT_AREA like '%Common%' )
AND     OBJECT_NAME NOT LIKE '%NDD%' AND     OBJECT_NAME NOT LIKE '%CheckTaskEnded%'
--AND   OBJECT_NAME LIKE '%m_SLIM_AccountAssociations%' 
ORDER BY 1,2,3
go


